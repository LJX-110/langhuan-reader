package io.legado.app.utils

import io.legado.app.constant.AppLog
import io.legado.app.help.coroutine.printStackTraceOnDebug
import io.legado.app.utils.NetworkUtils.getAbsoluteURL
import io.legado.app.utils.NetworkUtils.getLocalIPAddress
import okhttp3.HttpUrl
import okhttp3.internal.publicsuffix.PublicSuffixDatabase
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketException
import java.net.URL
import java.util.BitSet
import java.util.Enumeration

/**
 * NetworkUtils 的 JVM 半区 actual (android + jvm 共用)。
 *
 * 详见 commonMain/utils/NetworkUtils.kt expect 注释。
 * 实现逻辑与原 jvmAndAndroidMain 直接实现一致, 行为不变。
 *
 * 附加成员 (仅 jvmAndAndroid 可见, common 无 JDK 类型):
 * - [getAbsoluteURL] (java.net.URL?, String) 重载
 * - [getLocalIPAddress] 返回 List<java.net.InetAddress>
 *
 * 仅 [isAvailable] 留 app (走 connectivityManager, 见 app 端 NetworkAvailability)。
 *
 * 包名/对象名不变, 消费方 import 零改动。
 */
actual object NetworkUtils {

    private val notNeedEncodingQuery: BitSet by lazy {
        val bitSet = BitSet(256)
        for (i in 'a'.code..'z'.code) {
            bitSet.set(i)
        }
        for (i in 'A'.code..'Z'.code) {
            bitSet.set(i)
        }
        for (i in '0'.code..'9'.code) {
            bitSet.set(i)
        }
        for (char in "!$&()*+,-./:;=?@[\\]^_`{|}~") {
            bitSet.set(char.code)
        }
        return@lazy bitSet
    }

    private val notNeedEncodingForm: BitSet by lazy {
        val bitSet = BitSet(256)
        for (i in 'a'.code..'z'.code) {
            bitSet.set(i)
        }
        for (i in 'A'.code..'Z'.code) {
            bitSet.set(i)
        }
        for (i in '0'.code..'9'.code) {
            bitSet.set(i)
        }
        for (char in "*-._") {
            bitSet.set(char.code)
        }
        return@lazy bitSet
    }

    /**
     * 支持JAVA的URLEncoder.encode出来的string做判断。 即: 将' '转成'+'
     * 0-9a-zA-Z保留 <br></br>
     * ! * ' ( ) ; : @ & = + $ , / ? # [ ] 保留
     * 其他字符转成%XX的格式，X是16进制的大写字符，范围是[0-9A-F]
     */
    actual fun encodedQuery(str: String): Boolean {
        var needEncode = false
        var i = 0
        while (i < str.length) {
            val c = str[i]
            if (notNeedEncodingQuery.get(c.code)) {
                i++
                continue
            }
            if (c == '%' && i + 2 < str.length) {
                // 判断是否符合urlEncode规范
                val c1 = str[++i]
                val c2 = str[++i]
                if (isDigit16Char(c1) && isDigit16Char(c2)) {
                    i++
                    continue
                }
            }
            // 其他字符，肯定需要urlEncode
            needEncode = true
            break
        }

        return !needEncode
    }

    actual fun encodedForm(str: String): Boolean {
        var needEncode = false
        var i = 0
        while (i < str.length) {
            val c = str[i]
            if (notNeedEncodingForm.get(c.code)) {
                i++
                continue
            }
            if (c == '%' && i + 2 < str.length) {
                // 判断是否符合urlEncode规范
                val c1 = str[++i]
                val c2 = str[++i]
                if (isDigit16Char(c1) && isDigit16Char(c2)) {
                    i++
                    continue
                }
            }
            // 其他字符，肯定需要urlEncode
            needEncode = true
            break
        }

        return !needEncode
    }

    /**
     * 判断c是否是16进制的字符
     */
    private fun isDigit16Char(c: Char): Boolean {
        return c in '0'..'9' || c in 'A'..'F' || c in 'a'..'f'
    }

    /**
     * 获取绝对地址
     *
     * baseURL 为 data url 时不做相对拼接 (JDK URL 不支持 data 协议, 且逗号截断会切掉 payload),
     * 直接返回 relativePath.trim()。
     *
     * 沿用已弃用的 URL 构造: 书源里大量未转义的中文/空格路径会让 URI 直接抛异常拼不出地址。
     */
    @Suppress("DEPRECATION")
    actual fun getAbsoluteURL(baseURL: String?, relativePath: String): String {
        if (baseURL.isNullOrEmpty() || baseURL.isDataUrl()) return relativePath.trim()
        var absoluteUrl: URL? = null
        try {
            absoluteUrl = URL(baseURL.substringBefore(","))
        } catch (e: Exception) {
            e.printStackTraceOnDebug()
        }
        return getAbsoluteURL(absoluteUrl, relativePath)
    }

    /**
     * 获取绝对地址
     *
     * 附加成员: 参数为 java.net.URL (原版 NetworkUtils.getAbsoluteURL(URL?, String) 重载,
     * 不经 String 门面, 避免 substringBefore(",") 截断含逗号的 URL)。
     */
    @Suppress("DEPRECATION")
    actual fun getAbsoluteURL(baseURL: URL?, relativePath: String): String {
        val relativePathTrim = relativePath.trim()
        if (baseURL == null) return relativePathTrim
        if (relativePathTrim.isAbsUrl()) return relativePathTrim
        if (relativePathTrim.isDataUrl()) return relativePathTrim
        if (relativePathTrim.startsWith("javascript")) return ""
        var relativeUrl = relativePathTrim
        try {
            val parseUrl = URL(baseURL, relativePath)
            relativeUrl = parseUrl.toString()
            return relativeUrl
        } catch (e: Exception) {
            AppLog.put("网址拼接出错\n${e.localizedMessage}", e)
        }
        return relativeUrl
    }

    actual fun getBaseUrl(url: String?): String? {
        url ?: return null
        if (url.startsWith("http://", true)
            || url.startsWith("https://", true)
        ) {
            val index = url.indexOf("/", 9)
            return if (index == -1) {
                url
            } else url.take(index)
        }
        return null
    }

    /**
     * 取公共后缀库要求的主机规范形: IDN 转 punycode (xn--)、大小写归一为小写、末尾点保留。
     *
     * 复用 okhttp 自家请求链同一实现 (`HttpUrl.Builder.host` 内部走 `toCanonicalHost`), 与
     * `HttpUrl.topPrivateDomain` / `Cookie.parse` 交给 `getEffectiveTldPlusOne` 的主机同形;
     * 主机无法规范化时返回 null。
     */
    private fun toCanonicalHost(host: String): String? = kotlin.runCatching {
        HttpUrl.Builder().scheme("http").host(host).build().host
    }.getOrNull()

    /**
     * 获取域名，供cookie保存和读取，处理失败返回传入的url
     * http://1.2.3.4 => 1.2.3.4
     * https://www.example.com =>  example.com
     * http://www.biquge.com.cn => biquge.com.cn
     * http://www.content.example.com => example.com
     */
    @Suppress("DEPRECATION")
    actual fun getSubDomain(url: String): String {
        val baseUrl = getBaseUrl(url) ?: return url
        return kotlin.runCatching {
            val mURL = URL(baseUrl)
            val host: String = mURL.host
            //mURL.scheme https/http
            //判断是否为ip
            if (isIPAddress(host)) return host
            //PublicSuffixDatabase处理域名
            val canonicalHost = toCanonicalHost(host) ?: return host
            PublicSuffixDatabase.get().getEffectiveTldPlusOne(canonicalHost) ?: canonicalHost
        }.getOrDefault(baseUrl)
    }

    @Suppress("DEPRECATION")
    actual fun getSubDomainOrNull(url: String): String? {
        val baseUrl = getBaseUrl(url) ?: return null
        return kotlin.runCatching {
            val mURL = URL(baseUrl)
            val host: String = mURL.host
            //mURL.scheme https/http
            //判断是否为ip
            if (isIPAddress(host)) return host
            //PublicSuffixDatabase处理域名
            val canonicalHost = toCanonicalHost(host) ?: return host
            PublicSuffixDatabase.get().getEffectiveTldPlusOne(canonicalHost) ?: canonicalHost
        }.getOrDefault(null)
    }

    @Suppress("DEPRECATION")
    actual fun getDomain(url: String): String {
        val baseUrl = getBaseUrl(url) ?: return url
        return kotlin.runCatching {
            URL(baseUrl).host
        }.getOrDefault(baseUrl)
    }

    /**
     * Get local Ip address.
     *
     * 附加成员: 返回 List<java.net.InetAddress>, common 无 InetAddress 类型, 仅 jvmAndAndroid 暴露。
     */
    fun getLocalIPAddress(): List<InetAddress> {
        val enumeration: Enumeration<NetworkInterface>
        try {
            enumeration = NetworkInterface.getNetworkInterfaces()
        } catch (e: SocketException) {
            e.printStackTraceOnDebug()
            return emptyList()
        }

        val addressList = mutableListOf<InetAddress>()

        while (enumeration.hasMoreElements()) {
            val nif = enumeration.nextElement()
            val addresses = nif.inetAddresses ?: continue
            while (addresses.hasMoreElements()) {
                val address = addresses.nextElement()
                if (!address.isLoopbackAddress && isIPv4Address(address.hostAddress)) {
                    addressList.add(address)
                }
            }
        }
        return addressList
    }

    // 与 hutool RegexPool.IPV4/IPV6 相同的正则，Validator.isIpv4/isIpv6 行为对齐
    private val ipv4Regex = Regex(
        "^(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)\\." +
            "(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)\\.(25[0-5]|2[0-4]\\d|[0-1]?\\d?\\d)$"
    )
    private val ipv6Regex = Regex(
        "(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|" +
            "([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|" +
            "([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|" +
            "([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|" +
            ":((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+|" +
            "::(ffff(:0{1,4})?:)?((25[0-5]|(2[0-4]|1?[0-9])?[0-9])\\.){3}(25[0-5]|(2[0-4]|1?[0-9])?[0-9])|" +
            "([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1?[0-9])?[0-9])\\.){3}(25[0-5]|(2[0-4]|1?[0-9])?[0-9]))"
    )

    /**
     * Check if valid IPV4 address.
     *
     * @param input the address string to check for validity.
     * @return True if the input parameter is a valid IPv4 address.
     */
    actual fun isIPv4Address(input: String?): Boolean {
        return !input.isNullOrEmpty()
                && input[0] in '1'..'9'
                && input.count { it == '.' } == 3
                && ipv4Regex.matches(input)
    }

    /**
     * Check if valid IPV6 address.
     */
    actual fun isIPv6Address(input: String?): Boolean {
        return input != null && input.contains(":") && ipv6Regex.matches(input)
    }

    /**
     * Check if valid IP address.
     */
    actual fun isIPAddress(input: String?): Boolean {
        return isIPv4Address(input) || isIPv6Address(input)
    }

}
