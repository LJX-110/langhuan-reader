package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.DictRule
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class DictRuleDao_Impl(
  __db: RoomDatabase,
) : DictRuleDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfDictRule: EntityInsertAdapter<DictRule>

  private val __deleteAdapterOfDictRule: EntityDeleteOrUpdateAdapter<DictRule>

  private val __updateAdapterOfDictRule: EntityDeleteOrUpdateAdapter<DictRule>
  init {
    this.__db = __db
    this.__insertAdapterOfDictRule = object : EntityInsertAdapter<DictRule>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `dictRules` (`name`,`urlRule`,`showRule`,`enabled`,`sortNumber`) VALUES (?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: DictRule) {
        statement.bindText(1, entity.name)
        statement.bindText(2, entity.urlRule)
        statement.bindText(3, entity.showRule)
        val _tmp: Int = if (entity.enabled) 1 else 0
        statement.bindLong(4, _tmp.toLong())
        statement.bindLong(5, entity.sortNumber.toLong())
      }
    }
    this.__deleteAdapterOfDictRule = object : EntityDeleteOrUpdateAdapter<DictRule>() {
      protected override fun createQuery(): String = "DELETE FROM `dictRules` WHERE `name` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: DictRule) {
        statement.bindText(1, entity.name)
      }
    }
    this.__updateAdapterOfDictRule = object : EntityDeleteOrUpdateAdapter<DictRule>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `dictRules` SET `name` = ?,`urlRule` = ?,`showRule` = ?,`enabled` = ?,`sortNumber` = ? WHERE `name` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: DictRule) {
        statement.bindText(1, entity.name)
        statement.bindText(2, entity.urlRule)
        statement.bindText(3, entity.showRule)
        val _tmp: Int = if (entity.enabled) 1 else 0
        statement.bindLong(4, _tmp.toLong())
        statement.bindLong(5, entity.sortNumber.toLong())
        statement.bindText(6, entity.name)
      }
    }
  }

  public override suspend fun insert(vararg dictRule: DictRule): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfDictRule.insert(_connection, dictRule)
  }

  public override suspend fun delete(vararg dictRule: DictRule): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfDictRule.handleMultiple(_connection, dictRule)
  }

  public override suspend fun update(vararg dictRule: DictRule): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfDictRule.handleMultiple(_connection, dictRule)
  }

  public override suspend fun all(): List<DictRule> {
    val _sql: String = "select * from dictRules order by sortNumber"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrlRule: Int = getColumnIndexOrThrow(_stmt, "urlRule")
        val _columnIndexOfShowRule: Int = getColumnIndexOrThrow(_stmt, "showRule")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfSortNumber: Int = getColumnIndexOrThrow(_stmt, "sortNumber")
        val _result: MutableList<DictRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: DictRule
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrlRule: String
          _tmpUrlRule = _stmt.getText(_columnIndexOfUrlRule)
          val _tmpShowRule: String
          _tmpShowRule = _stmt.getText(_columnIndexOfShowRule)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpSortNumber: Int
          _tmpSortNumber = _stmt.getLong(_columnIndexOfSortNumber).toInt()
          _item = DictRule(_tmpName,_tmpUrlRule,_tmpShowRule,_tmpEnabled,_tmpSortNumber)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enabled(): List<DictRule> {
    val _sql: String = "select * from dictRules where enabled = 1 order by sortNumber"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrlRule: Int = getColumnIndexOrThrow(_stmt, "urlRule")
        val _columnIndexOfShowRule: Int = getColumnIndexOrThrow(_stmt, "showRule")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfSortNumber: Int = getColumnIndexOrThrow(_stmt, "sortNumber")
        val _result: MutableList<DictRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: DictRule
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrlRule: String
          _tmpUrlRule = _stmt.getText(_columnIndexOfUrlRule)
          val _tmpShowRule: String
          _tmpShowRule = _stmt.getText(_columnIndexOfShowRule)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpSortNumber: Int
          _tmpSortNumber = _stmt.getLong(_columnIndexOfSortNumber).toInt()
          _item = DictRule(_tmpName,_tmpUrlRule,_tmpShowRule,_tmpEnabled,_tmpSortNumber)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<DictRule>> {
    val _sql: String = "select * from dictRules order by sortNumber"
    return createFlow(__db, false, arrayOf("dictRules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrlRule: Int = getColumnIndexOrThrow(_stmt, "urlRule")
        val _columnIndexOfShowRule: Int = getColumnIndexOrThrow(_stmt, "showRule")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfSortNumber: Int = getColumnIndexOrThrow(_stmt, "sortNumber")
        val _result: MutableList<DictRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: DictRule
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrlRule: String
          _tmpUrlRule = _stmt.getText(_columnIndexOfUrlRule)
          val _tmpShowRule: String
          _tmpShowRule = _stmt.getText(_columnIndexOfShowRule)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpSortNumber: Int
          _tmpSortNumber = _stmt.getLong(_columnIndexOfSortNumber).toInt()
          _item = DictRule(_tmpName,_tmpUrlRule,_tmpShowRule,_tmpEnabled,_tmpSortNumber)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getByName(name: String): DictRule? {
    val _sql: String = "select * from dictRules where name = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, name)
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrlRule: Int = getColumnIndexOrThrow(_stmt, "urlRule")
        val _columnIndexOfShowRule: Int = getColumnIndexOrThrow(_stmt, "showRule")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfSortNumber: Int = getColumnIndexOrThrow(_stmt, "sortNumber")
        val _result: DictRule?
        if (_stmt.step()) {
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrlRule: String
          _tmpUrlRule = _stmt.getText(_columnIndexOfUrlRule)
          val _tmpShowRule: String
          _tmpShowRule = _stmt.getText(_columnIndexOfShowRule)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpSortNumber: Int
          _tmpSortNumber = _stmt.getLong(_columnIndexOfSortNumber).toInt()
          _result = DictRule(_tmpName,_tmpUrlRule,_tmpShowRule,_tmpEnabled,_tmpSortNumber)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
