package io.legado.app.`data`.dao

import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.Cache
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class CacheDao_Impl(
  __db: RoomDatabase,
) : CacheDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfCache: EntityInsertAdapter<Cache>
  init {
    this.__db = __db
    this.__insertAdapterOfCache = object : EntityInsertAdapter<Cache>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `caches` (`key`,`value`,`deadline`) VALUES (?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Cache) {
        statement.bindText(1, entity.key)
        val _tmpValue: String? = entity.value
        if (_tmpValue == null) {
          statement.bindNull(2)
        } else {
          statement.bindText(2, _tmpValue)
        }
        statement.bindLong(3, entity.deadline)
      }
    }
  }

  public override suspend fun insert(vararg cache: Cache): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfCache.insert(_connection, cache)
  }

  public override suspend fun `get`(key: String): Cache? {
    val _sql: String = "select * from caches where `key` = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfKey: Int = getColumnIndexOrThrow(_stmt, "key")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfDeadline: Int = getColumnIndexOrThrow(_stmt, "deadline")
        val _result: Cache?
        if (_stmt.step()) {
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfKey)
          val _tmpValue: String?
          if (_stmt.isNull(_columnIndexOfValue)) {
            _tmpValue = null
          } else {
            _tmpValue = _stmt.getText(_columnIndexOfValue)
          }
          val _tmpDeadline: Long
          _tmpDeadline = _stmt.getLong(_columnIndexOfDeadline)
          _result = Cache(_tmpKey,_tmpValue,_tmpDeadline)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun delete(key: String) {
    val _sql: String = "delete from caches where `key` = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteSourceVariables(key: String) {
    val _sql: String = """
        |delete from caches where `key` like 'v_' || ? || '_%'
        |        or `key` = 'userInfo_' || ?
        |        or `key` = 'loginHeader_' || ?
        |        or `key` = 'sourceVariable_' || ?
        """.trimMargin()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _argIndex = 2
        _stmt.bindText(_argIndex, key)
        _argIndex = 3
        _stmt.bindText(_argIndex, key)
        _argIndex = 4
        _stmt.bindText(_argIndex, key)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clearDeadline(now: Long) {
    val _sql: String = "delete from caches where deadline > 0 and deadline < ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, now)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
