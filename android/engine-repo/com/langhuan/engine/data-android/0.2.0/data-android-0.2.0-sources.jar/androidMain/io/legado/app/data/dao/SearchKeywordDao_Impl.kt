package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.SearchKeyword
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class SearchKeywordDao_Impl(
  __db: RoomDatabase,
) : SearchKeywordDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfSearchKeyword: EntityInsertAdapter<SearchKeyword>

  private val __deleteAdapterOfSearchKeyword: EntityDeleteOrUpdateAdapter<SearchKeyword>

  private val __updateAdapterOfSearchKeyword: EntityDeleteOrUpdateAdapter<SearchKeyword>
  init {
    this.__db = __db
    this.__insertAdapterOfSearchKeyword = object : EntityInsertAdapter<SearchKeyword>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `search_keywords` (`word`,`usage`,`lastUseTime`) VALUES (?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SearchKeyword) {
        statement.bindText(1, entity.word)
        statement.bindLong(2, entity.usage.toLong())
        statement.bindLong(3, entity.lastUseTime)
      }
    }
    this.__deleteAdapterOfSearchKeyword = object : EntityDeleteOrUpdateAdapter<SearchKeyword>() {
      protected override fun createQuery(): String = "DELETE FROM `search_keywords` WHERE `word` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: SearchKeyword) {
        statement.bindText(1, entity.word)
      }
    }
    this.__updateAdapterOfSearchKeyword = object : EntityDeleteOrUpdateAdapter<SearchKeyword>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `search_keywords` SET `word` = ?,`usage` = ?,`lastUseTime` = ? WHERE `word` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: SearchKeyword) {
        statement.bindText(1, entity.word)
        statement.bindLong(2, entity.usage.toLong())
        statement.bindLong(3, entity.lastUseTime)
        statement.bindText(4, entity.word)
      }
    }
  }

  public override suspend fun insert(vararg keywords: SearchKeyword): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfSearchKeyword.insert(_connection, keywords)
  }

  public override suspend fun delete(vararg keywords: SearchKeyword): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfSearchKeyword.handleMultiple(_connection, keywords)
  }

  public override suspend fun update(vararg keywords: SearchKeyword): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfSearchKeyword.handleMultiple(_connection, keywords)
  }

  public override suspend fun all(): List<SearchKeyword> {
    val _sql: String = "SELECT * FROM search_keywords"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfUsage: Int = getColumnIndexOrThrow(_stmt, "usage")
        val _columnIndexOfLastUseTime: Int = getColumnIndexOrThrow(_stmt, "lastUseTime")
        val _result: MutableList<SearchKeyword> = mutableListOf()
        while (_stmt.step()) {
          val _item: SearchKeyword
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpUsage: Int
          _tmpUsage = _stmt.getLong(_columnIndexOfUsage).toInt()
          val _tmpLastUseTime: Long
          _tmpLastUseTime = _stmt.getLong(_columnIndexOfLastUseTime)
          _item = SearchKeyword(_tmpWord,_tmpUsage,_tmpLastUseTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowByTime(): Flow<List<SearchKeyword>> {
    val _sql: String = "SELECT * FROM search_keywords ORDER BY lastUseTime DESC"
    return createFlow(__db, false, arrayOf("search_keywords")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfUsage: Int = getColumnIndexOrThrow(_stmt, "usage")
        val _columnIndexOfLastUseTime: Int = getColumnIndexOrThrow(_stmt, "lastUseTime")
        val _result: MutableList<SearchKeyword> = mutableListOf()
        while (_stmt.step()) {
          val _item: SearchKeyword
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpUsage: Int
          _tmpUsage = _stmt.getLong(_columnIndexOfUsage).toInt()
          val _tmpLastUseTime: Long
          _tmpLastUseTime = _stmt.getLong(_columnIndexOfLastUseTime)
          _item = SearchKeyword(_tmpWord,_tmpUsage,_tmpLastUseTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowSearch(key: String): Flow<List<SearchKeyword>> {
    val _sql: String = "SELECT * FROM search_keywords where word like '%'||?||'%' ORDER BY usage DESC"
    return createFlow(__db, false, arrayOf("search_keywords")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfUsage: Int = getColumnIndexOrThrow(_stmt, "usage")
        val _columnIndexOfLastUseTime: Int = getColumnIndexOrThrow(_stmt, "lastUseTime")
        val _result: MutableList<SearchKeyword> = mutableListOf()
        while (_stmt.step()) {
          val _item: SearchKeyword
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpUsage: Int
          _tmpUsage = _stmt.getLong(_columnIndexOfUsage).toInt()
          val _tmpLastUseTime: Long
          _tmpLastUseTime = _stmt.getLong(_columnIndexOfLastUseTime)
          _item = SearchKeyword(_tmpWord,_tmpUsage,_tmpLastUseTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun `get`(key: String): SearchKeyword? {
    val _sql: String = "select * from search_keywords where word = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfUsage: Int = getColumnIndexOrThrow(_stmt, "usage")
        val _columnIndexOfLastUseTime: Int = getColumnIndexOrThrow(_stmt, "lastUseTime")
        val _result: SearchKeyword?
        if (_stmt.step()) {
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpUsage: Int
          _tmpUsage = _stmt.getLong(_columnIndexOfUsage).toInt()
          val _tmpLastUseTime: Long
          _tmpLastUseTime = _stmt.getLong(_columnIndexOfLastUseTime)
          _result = SearchKeyword(_tmpWord,_tmpUsage,_tmpLastUseTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteAll() {
    val _sql: String = "DELETE FROM search_keywords"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
