package io.legado.app.`data`

import androidx.room3.RoomDatabaseConstructor

public actual object AppDatabaseConstructor : RoomDatabaseConstructor<AppDatabase> {
  actual override fun initialize(): AppDatabase = io.legado.app.`data`.AppDatabase_Impl()
}
