package io.legado.app.help.book

import io.legado.app.data.entities.Book
import io.legado.app.data.entities.BookChapter
import io.legado.app.data.entities.BookSource
import io.legado.app.utils.File
import kotlin.concurrent.Volatile

/**
 * BookHelp 跨模块只读访问接口。
 *
 * BookHelp 重 Android 依赖 (BitmapFactory/ParcelFileDescriptor/DocumentFile/appCtx),
 * 留 app 端。本接口仅暴露 webBook 编排层 (BookContent) 及下沉的 CacheBook 调度
 * (CacheBookShared) 用到的方法, 由 app 端 WebBookProvidersImpl 包装 BookHelp 实现,
 * 在 App.onCreate 经 [BookHelpProviders.register] 注册。
 *
 * 桌面端 DesktopBookHelpAccessor 与 iOS/鸿蒙 NativeBookHelpAccessor 的图片编排走共享
 * [io.legado.app.help.book.BookImageDownloadShared] (与 app 端同链路, 落盘走
 * BookImageStorageProviders)。
 *
 * 模式参考 BookInfoRefreshers / SourceDebugLoggers。
 */
interface BookHelpAccessor {

    /**
     * 保存章节正文 (对应 BookHelp.saveContent)。
     *
     * 实现内部由 app 端 BookHelp.saveContent 落盘 + 发 EventBus 事件,
     * 行为与原 app 端直接调用完全一致。
     */
    fun saveContent(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter,
        content: String
    )

    /**
     * 保存章节内图片 (漫画/插画, 对应 BookHelp.saveImages)。
     *
     * 四端实现均委托共享编排 [io.legado.app.help.book.BookImageDownloadShared]
     * (并发 + per-src 去重 + 插件源分流 + 解密, 同一链路); 默认空实现留给无图片缓存能力的实现。
     *
     * suspend 因图片下载为挂起调用。
     */
    suspend fun saveImages(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter,
        content: String,
        concurrency: Int
    ) {
        // 默认空实现: 无图片缓存能力的实现可不覆写
    }

    /**
     * 获取图片缓存文件路径 (对应 BookHelp.getImage)。
     *
     * 返回 images 目录下按 src 派生文件名的 File, 不保证文件存在。
     * 供 [io.legado.app.model.ImageProvider] 下沉后调用 (原 app 端直接 BookHelp.getImage)。
     *
     * 默认抛出: 桌面/iOS/鸿蒙端 ImageProvider 为 stub 不会调用本方法
     * (与 [saveImages] 默认实现同一约定, 此处返回 File 故用 error)。
     */
    fun getImage(book: Book, src: String): File =
        error("BookHelpAccessor.getImage not implemented; desktop/native/ohos use ReaderImageResolver")

    /**
     * 判断图片是否已缓存 (对应 BookHelp.isImageExist)。
     *
     * 供 [io.legado.app.model.ImageProvider] 下沉后调用。
     * 默认 false: 桌面/iOS/鸿蒙端图片管线走
     * [io.legado.app.help.image.ReaderImageResolver], 不经 ImageProvider, 不会调用本方法
     * (Android 端 ImageProvider.cacheImage 经本方法查缓存)。
     */
    fun isImageExist(book: Book, src: String): Boolean = false

    /**
     * 下载并保存单张图片 (对应 BookHelp.saveImage)。
     *
     * 带书源防盗链 header / cookie / charset / JS, 加密图片走 ImageUtils.decode 解密。
     * 失败只记日志不抛出 (与 app 端一致)。chapter 仅用于日志。
     * 供 [io.legado.app.model.ImageProvider] 下沉后调用。
     *
     * 默认空实现: 图片缓存能力由各端实现覆写提供 (与 [saveImages] 默认实现同一约定)。
     */
    suspend fun saveImage(
        bookSource: BookSource?,
        book: Book,
        src: String,
        chapter: BookChapter? = null
    ) {
        // 默认空实现: 无图片缓存能力的实现可不覆写
    }

    /**
     * 检测图片是否已完整下载 (对应 BookHelp.hasImageContent)。
     *
     * Android 端 WebBookProvidersImpl 按章节校验图片完整性 (正文全部图片解码成功);
     * 桌面/iOS/鸿蒙端按整本 images 缓存目录是否有内容判定 (图片未按章组织, 见
     * [io.legado.app.help.book.BookImageStorage.hasImageContent]); 默认 false。
     */
    fun hasImageContent(book: Book, bookChapter: BookChapter): Boolean = false

    /**
     * 读取章节缓存或解析本地书原文件 (对应 BookHelp.getContent)。
     *
     * 默认委托 [BookHelpShared.getContent]，让阅读、朗读和导出使用同一读取链路。
     * app 端 WebBookProvidersImpl override 委托 BookHelp.getContent。
     *
     * 返回 null 表示没有可用内容。
     */
    fun getContent(book: Book, bookChapter: BookChapter): String? =
        BookHelpShared.getContent(book, bookChapter)

    /**
     * 书籍缓存目录路径 (对应 app 端 `BookHelp.cachePath`)。
     *
     * 用于 [io.legado.app.model.fileBook.CbzFile] 存放 `cbz_images.json` 等
     * 书籍级缓存文件。Android: `appCtx.externalFiles/book_cache`; 桌面:
     * `~/.legado/book_cache` (与 [io.legado.app.help.book.BookStorage.rootPath] 同源)。
     *
     * 默认委托 [io.legado.app.help.book.BookStorageProviders.get().rootPath],
     * app 端 WebBookProvidersImpl override 返回 `BookHelp.cachePath` (行为一致)。
     */
    val cachePath: String
        get() = BookStorageProviders.get().rootPath

    /**
     * 获取书籍封面文件路径 (对应 app 端 `FileBook.getCoverPath(bookUrl)`)。
     *
     * 用于 [io.legado.app.model.fileBook.CbzFile.upBookInfo] 在 `book.coverUrl`
     * 为空时设置封面落盘路径。路径派生: `{externalFiles/covers}/{md5(bookUrl)}.jpg`
     * (Android) 或 `{desktopAppRootDir}/covers/{md5(bookUrl)}.jpg` (桌面)。
     *
     * app 端 WebBookProvidersImpl override 委托 `FileBook.getCoverPath(bookUrl)`
     * (行为一致); 桌面端 DesktopBookHelpAccessor 自行构造路径。
     *
     * @param bookUrl 书籍唯一标识 (book.bookUrl)
     * @return 封面 JPEG 文件绝对路径
     */
    fun getCoverPath(bookUrl: String): String

    /**
     * 清理平台专属临时文件 (对应 app 端 `BookHelp.clearInvalidCache` 末段)。
     *
     * app 端 override 清理 `ArchiveUtils.TEMP_PATH` + `filesDir/share*.json` + `books.json`;
     * 其他端无此类临时文件, 默认 no-op (与 [saveImages] 默认实现同一约定)。
     */
    suspend fun clearCacheExtra()
}

/**
 * BookHelp provider 容器。宿主启动早期注册一次。
 *
 * shared 内访问点用
 * `BookHelpProviders.get().saveContent(...)` 替代
 * 原 `BookHelp.saveContent(...)`, 行为完全一致, 仅多一层 provider 间接。
 */
object BookHelpProviders {
    @Volatile
    private var impl: BookHelpAccessor? = null

    /** 宿主启动早期注册一次(任何 webBook 调用之前)。 */
    fun register(impl: BookHelpAccessor) {
        this.impl = impl
    }

    /** 获取已注册实现, 未注册抛出 IllegalStateException。 */
    fun get(): BookHelpAccessor = impl ?: error("BookHelpProviders not registered")
}
