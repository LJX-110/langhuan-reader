package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.Bookmark
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class BookmarkDao_Impl(
  __db: RoomDatabase,
) : BookmarkDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfBookmark: EntityInsertAdapter<Bookmark>

  private val __deleteAdapterOfBookmark: EntityDeleteOrUpdateAdapter<Bookmark>

  private val __updateAdapterOfBookmark: EntityDeleteOrUpdateAdapter<Bookmark>
  init {
    this.__db = __db
    this.__insertAdapterOfBookmark = object : EntityInsertAdapter<Bookmark>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `bookmarks` (`time`,`bookName`,`bookAuthor`,`chapterIndex`,`chapterPos`,`chapterName`,`bookText`,`content`,`type`,`endPos`,`color`,`lineStyle`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Bookmark) {
        statement.bindLong(1, entity.time)
        statement.bindText(2, entity.bookName)
        statement.bindText(3, entity.bookAuthor)
        statement.bindLong(4, entity.chapterIndex.toLong())
        statement.bindLong(5, entity.chapterPos.toLong())
        statement.bindText(6, entity.chapterName)
        statement.bindText(7, entity.bookText)
        statement.bindText(8, entity.content)
        statement.bindLong(9, entity.type.toLong())
        statement.bindLong(10, entity.endPos.toLong())
        val _tmpColor: Int? = entity.color
        if (_tmpColor == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmpColor.toLong())
        }
        statement.bindLong(12, entity.lineStyle.toLong())
      }
    }
    this.__deleteAdapterOfBookmark = object : EntityDeleteOrUpdateAdapter<Bookmark>() {
      protected override fun createQuery(): String = "DELETE FROM `bookmarks` WHERE `time` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: Bookmark) {
        statement.bindLong(1, entity.time)
      }
    }
    this.__updateAdapterOfBookmark = object : EntityDeleteOrUpdateAdapter<Bookmark>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `bookmarks` SET `time` = ?,`bookName` = ?,`bookAuthor` = ?,`chapterIndex` = ?,`chapterPos` = ?,`chapterName` = ?,`bookText` = ?,`content` = ?,`type` = ?,`endPos` = ?,`color` = ?,`lineStyle` = ? WHERE `time` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: Bookmark) {
        statement.bindLong(1, entity.time)
        statement.bindText(2, entity.bookName)
        statement.bindText(3, entity.bookAuthor)
        statement.bindLong(4, entity.chapterIndex.toLong())
        statement.bindLong(5, entity.chapterPos.toLong())
        statement.bindText(6, entity.chapterName)
        statement.bindText(7, entity.bookText)
        statement.bindText(8, entity.content)
        statement.bindLong(9, entity.type.toLong())
        statement.bindLong(10, entity.endPos.toLong())
        val _tmpColor: Int? = entity.color
        if (_tmpColor == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmpColor.toLong())
        }
        statement.bindLong(12, entity.lineStyle.toLong())
        statement.bindLong(13, entity.time)
      }
    }
  }

  public override suspend fun insert(vararg bookmark: Bookmark): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfBookmark.insert(_connection, bookmark)
  }

  public override suspend fun delete(vararg bookmark: Bookmark): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfBookmark.handleMultiple(_connection, bookmark)
  }

  public override suspend fun update(bookmark: Bookmark): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfBookmark.handle(_connection, bookmark)
  }

  public override suspend fun all(): List<Bookmark> {
    val _sql: String = """
        |
        |        select * from bookmarks order by bookName, bookAuthor, chapterIndex, chapterPos
        |    
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfTime: Int = getColumnIndexOrThrow(_stmt, "time")
        val _columnIndexOfBookName: Int = getColumnIndexOrThrow(_stmt, "bookName")
        val _columnIndexOfBookAuthor: Int = getColumnIndexOrThrow(_stmt, "bookAuthor")
        val _columnIndexOfChapterIndex: Int = getColumnIndexOrThrow(_stmt, "chapterIndex")
        val _columnIndexOfChapterPos: Int = getColumnIndexOrThrow(_stmt, "chapterPos")
        val _columnIndexOfChapterName: Int = getColumnIndexOrThrow(_stmt, "chapterName")
        val _columnIndexOfBookText: Int = getColumnIndexOrThrow(_stmt, "bookText")
        val _columnIndexOfContent: Int = getColumnIndexOrThrow(_stmt, "content")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfEndPos: Int = getColumnIndexOrThrow(_stmt, "endPos")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _result: MutableList<Bookmark> = mutableListOf()
        while (_stmt.step()) {
          val _item: Bookmark
          val _tmpTime: Long
          _tmpTime = _stmt.getLong(_columnIndexOfTime)
          val _tmpBookName: String
          _tmpBookName = _stmt.getText(_columnIndexOfBookName)
          val _tmpBookAuthor: String
          _tmpBookAuthor = _stmt.getText(_columnIndexOfBookAuthor)
          val _tmpChapterIndex: Int
          _tmpChapterIndex = _stmt.getLong(_columnIndexOfChapterIndex).toInt()
          val _tmpChapterPos: Int
          _tmpChapterPos = _stmt.getLong(_columnIndexOfChapterPos).toInt()
          val _tmpChapterName: String
          _tmpChapterName = _stmt.getText(_columnIndexOfChapterName)
          val _tmpBookText: String
          _tmpBookText = _stmt.getText(_columnIndexOfBookText)
          val _tmpContent: String
          _tmpContent = _stmt.getText(_columnIndexOfContent)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpEndPos: Int
          _tmpEndPos = _stmt.getLong(_columnIndexOfEndPos).toInt()
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          _item = Bookmark(_tmpTime,_tmpBookName,_tmpBookAuthor,_tmpChapterIndex,_tmpChapterPos,_tmpChapterName,_tmpBookText,_tmpContent,_tmpType,_tmpEndPos,_tmpColor,_tmpLineStyle)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<Bookmark>> {
    val _sql: String = "select * from bookmarks order by bookName, bookAuthor, chapterIndex, chapterPos"
    return createFlow(__db, false, arrayOf("bookmarks")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfTime: Int = getColumnIndexOrThrow(_stmt, "time")
        val _columnIndexOfBookName: Int = getColumnIndexOrThrow(_stmt, "bookName")
        val _columnIndexOfBookAuthor: Int = getColumnIndexOrThrow(_stmt, "bookAuthor")
        val _columnIndexOfChapterIndex: Int = getColumnIndexOrThrow(_stmt, "chapterIndex")
        val _columnIndexOfChapterPos: Int = getColumnIndexOrThrow(_stmt, "chapterPos")
        val _columnIndexOfChapterName: Int = getColumnIndexOrThrow(_stmt, "chapterName")
        val _columnIndexOfBookText: Int = getColumnIndexOrThrow(_stmt, "bookText")
        val _columnIndexOfContent: Int = getColumnIndexOrThrow(_stmt, "content")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfEndPos: Int = getColumnIndexOrThrow(_stmt, "endPos")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _result: MutableList<Bookmark> = mutableListOf()
        while (_stmt.step()) {
          val _item: Bookmark
          val _tmpTime: Long
          _tmpTime = _stmt.getLong(_columnIndexOfTime)
          val _tmpBookName: String
          _tmpBookName = _stmt.getText(_columnIndexOfBookName)
          val _tmpBookAuthor: String
          _tmpBookAuthor = _stmt.getText(_columnIndexOfBookAuthor)
          val _tmpChapterIndex: Int
          _tmpChapterIndex = _stmt.getLong(_columnIndexOfChapterIndex).toInt()
          val _tmpChapterPos: Int
          _tmpChapterPos = _stmt.getLong(_columnIndexOfChapterPos).toInt()
          val _tmpChapterName: String
          _tmpChapterName = _stmt.getText(_columnIndexOfChapterName)
          val _tmpBookText: String
          _tmpBookText = _stmt.getText(_columnIndexOfBookText)
          val _tmpContent: String
          _tmpContent = _stmt.getText(_columnIndexOfContent)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpEndPos: Int
          _tmpEndPos = _stmt.getLong(_columnIndexOfEndPos).toInt()
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          _item = Bookmark(_tmpTime,_tmpBookName,_tmpBookAuthor,_tmpChapterIndex,_tmpChapterPos,_tmpChapterName,_tmpBookText,_tmpContent,_tmpType,_tmpEndPos,_tmpColor,_tmpLineStyle)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowByBook(bookName: String, bookAuthor: String): Flow<List<Bookmark>> {
    val _sql: String = """
        |select * from bookmarks 
        |        where bookName = ? and bookAuthor = ? 
        |        order by chapterIndex
        """.trimMargin()
    return createFlow(__db, false, arrayOf("bookmarks")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookName)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookAuthor)
        val _columnIndexOfTime: Int = getColumnIndexOrThrow(_stmt, "time")
        val _columnIndexOfBookName: Int = getColumnIndexOrThrow(_stmt, "bookName")
        val _columnIndexOfBookAuthor: Int = getColumnIndexOrThrow(_stmt, "bookAuthor")
        val _columnIndexOfChapterIndex: Int = getColumnIndexOrThrow(_stmt, "chapterIndex")
        val _columnIndexOfChapterPos: Int = getColumnIndexOrThrow(_stmt, "chapterPos")
        val _columnIndexOfChapterName: Int = getColumnIndexOrThrow(_stmt, "chapterName")
        val _columnIndexOfBookText: Int = getColumnIndexOrThrow(_stmt, "bookText")
        val _columnIndexOfContent: Int = getColumnIndexOrThrow(_stmt, "content")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfEndPos: Int = getColumnIndexOrThrow(_stmt, "endPos")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _result: MutableList<Bookmark> = mutableListOf()
        while (_stmt.step()) {
          val _item: Bookmark
          val _tmpTime: Long
          _tmpTime = _stmt.getLong(_columnIndexOfTime)
          val _tmpBookName: String
          _tmpBookName = _stmt.getText(_columnIndexOfBookName)
          val _tmpBookAuthor: String
          _tmpBookAuthor = _stmt.getText(_columnIndexOfBookAuthor)
          val _tmpChapterIndex: Int
          _tmpChapterIndex = _stmt.getLong(_columnIndexOfChapterIndex).toInt()
          val _tmpChapterPos: Int
          _tmpChapterPos = _stmt.getLong(_columnIndexOfChapterPos).toInt()
          val _tmpChapterName: String
          _tmpChapterName = _stmt.getText(_columnIndexOfChapterName)
          val _tmpBookText: String
          _tmpBookText = _stmt.getText(_columnIndexOfBookText)
          val _tmpContent: String
          _tmpContent = _stmt.getText(_columnIndexOfContent)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpEndPos: Int
          _tmpEndPos = _stmt.getLong(_columnIndexOfEndPos).toInt()
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          _item = Bookmark(_tmpTime,_tmpBookName,_tmpBookAuthor,_tmpChapterIndex,_tmpChapterPos,_tmpChapterName,_tmpBookText,_tmpContent,_tmpType,_tmpEndPos,_tmpColor,_tmpLineStyle)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowSearch(
    bookName: String,
    bookAuthor: String,
    key: String,
  ): Flow<List<Bookmark>> {
    val _sql: String = """
        |SELECT * FROM bookmarks 
        |        where bookName = ? and bookAuthor = ? 
        |        and (chapterName like '%'||?||'%' or content like '%'||?||'%')
        |        order by chapterIndex
        """.trimMargin()
    return createFlow(__db, false, arrayOf("bookmarks")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookName)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookAuthor)
        _argIndex = 3
        _stmt.bindText(_argIndex, key)
        _argIndex = 4
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfTime: Int = getColumnIndexOrThrow(_stmt, "time")
        val _columnIndexOfBookName: Int = getColumnIndexOrThrow(_stmt, "bookName")
        val _columnIndexOfBookAuthor: Int = getColumnIndexOrThrow(_stmt, "bookAuthor")
        val _columnIndexOfChapterIndex: Int = getColumnIndexOrThrow(_stmt, "chapterIndex")
        val _columnIndexOfChapterPos: Int = getColumnIndexOrThrow(_stmt, "chapterPos")
        val _columnIndexOfChapterName: Int = getColumnIndexOrThrow(_stmt, "chapterName")
        val _columnIndexOfBookText: Int = getColumnIndexOrThrow(_stmt, "bookText")
        val _columnIndexOfContent: Int = getColumnIndexOrThrow(_stmt, "content")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfEndPos: Int = getColumnIndexOrThrow(_stmt, "endPos")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _result: MutableList<Bookmark> = mutableListOf()
        while (_stmt.step()) {
          val _item: Bookmark
          val _tmpTime: Long
          _tmpTime = _stmt.getLong(_columnIndexOfTime)
          val _tmpBookName: String
          _tmpBookName = _stmt.getText(_columnIndexOfBookName)
          val _tmpBookAuthor: String
          _tmpBookAuthor = _stmt.getText(_columnIndexOfBookAuthor)
          val _tmpChapterIndex: Int
          _tmpChapterIndex = _stmt.getLong(_columnIndexOfChapterIndex).toInt()
          val _tmpChapterPos: Int
          _tmpChapterPos = _stmt.getLong(_columnIndexOfChapterPos).toInt()
          val _tmpChapterName: String
          _tmpChapterName = _stmt.getText(_columnIndexOfChapterName)
          val _tmpBookText: String
          _tmpBookText = _stmt.getText(_columnIndexOfBookText)
          val _tmpContent: String
          _tmpContent = _stmt.getText(_columnIndexOfContent)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpEndPos: Int
          _tmpEndPos = _stmt.getLong(_columnIndexOfEndPos).toInt()
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          _item = Bookmark(_tmpTime,_tmpBookName,_tmpBookAuthor,_tmpChapterIndex,_tmpChapterPos,_tmpChapterName,_tmpBookText,_tmpContent,_tmpType,_tmpEndPos,_tmpColor,_tmpLineStyle)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getByBook(bookName: String, bookAuthor: String): List<Bookmark> {
    val _sql: String = """
        |select * from bookmarks 
        |        where bookName = ? and bookAuthor = ? 
        |        order by chapterIndex, chapterPos
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookName)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookAuthor)
        val _columnIndexOfTime: Int = getColumnIndexOrThrow(_stmt, "time")
        val _columnIndexOfBookName: Int = getColumnIndexOrThrow(_stmt, "bookName")
        val _columnIndexOfBookAuthor: Int = getColumnIndexOrThrow(_stmt, "bookAuthor")
        val _columnIndexOfChapterIndex: Int = getColumnIndexOrThrow(_stmt, "chapterIndex")
        val _columnIndexOfChapterPos: Int = getColumnIndexOrThrow(_stmt, "chapterPos")
        val _columnIndexOfChapterName: Int = getColumnIndexOrThrow(_stmt, "chapterName")
        val _columnIndexOfBookText: Int = getColumnIndexOrThrow(_stmt, "bookText")
        val _columnIndexOfContent: Int = getColumnIndexOrThrow(_stmt, "content")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfEndPos: Int = getColumnIndexOrThrow(_stmt, "endPos")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _result: MutableList<Bookmark> = mutableListOf()
        while (_stmt.step()) {
          val _item: Bookmark
          val _tmpTime: Long
          _tmpTime = _stmt.getLong(_columnIndexOfTime)
          val _tmpBookName: String
          _tmpBookName = _stmt.getText(_columnIndexOfBookName)
          val _tmpBookAuthor: String
          _tmpBookAuthor = _stmt.getText(_columnIndexOfBookAuthor)
          val _tmpChapterIndex: Int
          _tmpChapterIndex = _stmt.getLong(_columnIndexOfChapterIndex).toInt()
          val _tmpChapterPos: Int
          _tmpChapterPos = _stmt.getLong(_columnIndexOfChapterPos).toInt()
          val _tmpChapterName: String
          _tmpChapterName = _stmt.getText(_columnIndexOfChapterName)
          val _tmpBookText: String
          _tmpBookText = _stmt.getText(_columnIndexOfBookText)
          val _tmpContent: String
          _tmpContent = _stmt.getText(_columnIndexOfContent)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpEndPos: Int
          _tmpEndPos = _stmt.getLong(_columnIndexOfEndPos).toInt()
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          _item = Bookmark(_tmpTime,_tmpBookName,_tmpBookAuthor,_tmpChapterIndex,_tmpChapterPos,_tmpChapterName,_tmpBookText,_tmpContent,_tmpType,_tmpEndPos,_tmpColor,_tmpLineStyle)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowUnderlinesByBook(bookName: String, bookAuthor: String): Flow<List<Bookmark>> {
    val _sql: String = """
        |select * from bookmarks 
        |        where bookName = ? and bookAuthor = ? and type = 1 
        |        order by chapterIndex, chapterPos
        """.trimMargin()
    return createFlow(__db, false, arrayOf("bookmarks")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookName)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookAuthor)
        val _columnIndexOfTime: Int = getColumnIndexOrThrow(_stmt, "time")
        val _columnIndexOfBookName: Int = getColumnIndexOrThrow(_stmt, "bookName")
        val _columnIndexOfBookAuthor: Int = getColumnIndexOrThrow(_stmt, "bookAuthor")
        val _columnIndexOfChapterIndex: Int = getColumnIndexOrThrow(_stmt, "chapterIndex")
        val _columnIndexOfChapterPos: Int = getColumnIndexOrThrow(_stmt, "chapterPos")
        val _columnIndexOfChapterName: Int = getColumnIndexOrThrow(_stmt, "chapterName")
        val _columnIndexOfBookText: Int = getColumnIndexOrThrow(_stmt, "bookText")
        val _columnIndexOfContent: Int = getColumnIndexOrThrow(_stmt, "content")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfEndPos: Int = getColumnIndexOrThrow(_stmt, "endPos")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _result: MutableList<Bookmark> = mutableListOf()
        while (_stmt.step()) {
          val _item: Bookmark
          val _tmpTime: Long
          _tmpTime = _stmt.getLong(_columnIndexOfTime)
          val _tmpBookName: String
          _tmpBookName = _stmt.getText(_columnIndexOfBookName)
          val _tmpBookAuthor: String
          _tmpBookAuthor = _stmt.getText(_columnIndexOfBookAuthor)
          val _tmpChapterIndex: Int
          _tmpChapterIndex = _stmt.getLong(_columnIndexOfChapterIndex).toInt()
          val _tmpChapterPos: Int
          _tmpChapterPos = _stmt.getLong(_columnIndexOfChapterPos).toInt()
          val _tmpChapterName: String
          _tmpChapterName = _stmt.getText(_columnIndexOfChapterName)
          val _tmpBookText: String
          _tmpBookText = _stmt.getText(_columnIndexOfBookText)
          val _tmpContent: String
          _tmpContent = _stmt.getText(_columnIndexOfContent)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpEndPos: Int
          _tmpEndPos = _stmt.getLong(_columnIndexOfEndPos).toInt()
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          _item = Bookmark(_tmpTime,_tmpBookName,_tmpBookAuthor,_tmpChapterIndex,_tmpChapterPos,_tmpChapterName,_tmpBookText,_tmpContent,_tmpType,_tmpEndPos,_tmpColor,_tmpLineStyle)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateColor(time: Long, color: Int?) {
    val _sql: String = "update bookmarks set color = ? where time = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (color == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, color.toLong())
        }
        _argIndex = 2
        _stmt.bindLong(_argIndex, time)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateLineStyle(time: Long, lineStyle: Int) {
    val _sql: String = "update bookmarks set lineStyle = ? where time = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, lineStyle.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, time)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateContent(time: Long, content: String) {
    val _sql: String = "update bookmarks set content = ? where time = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, content)
        _argIndex = 2
        _stmt.bindLong(_argIndex, time)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
