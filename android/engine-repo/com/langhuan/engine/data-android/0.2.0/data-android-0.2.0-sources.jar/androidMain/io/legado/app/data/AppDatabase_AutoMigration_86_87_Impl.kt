package io.legado.app.`data`

import androidx.room3.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class AppDatabase_AutoMigration_86_87_Impl : Migration {
  public constructor() : super(86, 87)

  public override suspend fun migrate(connection: SQLiteConnection) {
    connection.execSQL("DROP VIEW book_sources_part")
    connection.execSQL("CREATE TABLE IF NOT EXISTS `_new_book_sources` (`bookSourceUrl` TEXT NOT NULL, `bookSourceName` TEXT NOT NULL, `bookSourceGroup` TEXT, `bookSourceType` INTEGER NOT NULL, `bookUrlPattern` TEXT, `customOrder` INTEGER NOT NULL DEFAULT 0, `enabled` INTEGER NOT NULL DEFAULT 1, `enabledExplore` INTEGER NOT NULL DEFAULT 1, `enabledReview` INTEGER NOT NULL DEFAULT 1, `jsLib` TEXT, `enabledCookieJar` INTEGER DEFAULT 0, `enableDangerousApi` INTEGER DEFAULT 0, `concurrentRate` TEXT, `header` TEXT, `loginUrl` TEXT, `loginUi` TEXT, `loginCheckJs` TEXT, `coverDecodeJs` TEXT, `bookSourceComment` TEXT, `variableComment` TEXT, `lastUpdateTime` INTEGER NOT NULL, `respondTime` INTEGER NOT NULL, `weight` INTEGER NOT NULL, `exploreUrl` TEXT, `exploreScreen` TEXT, `exploreStyle` INTEGER NOT NULL DEFAULT 0, `ruleExplore` TEXT, `searchUrl` TEXT, `ruleSearch` TEXT, `ruleBookInfo` TEXT, `ruleToc` TEXT, `ruleContent` TEXT, `ruleReview` TEXT, PRIMARY KEY(`bookSourceUrl`))")
    connection.execSQL("INSERT INTO `_new_book_sources` (`bookSourceUrl`,`bookSourceName`,`bookSourceGroup`,`bookSourceType`,`bookUrlPattern`,`customOrder`,`enabled`,`enabledExplore`,`enabledReview`,`jsLib`,`enabledCookieJar`,`enableDangerousApi`,`concurrentRate`,`header`,`loginUrl`,`loginUi`,`loginCheckJs`,`coverDecodeJs`,`bookSourceComment`,`variableComment`,`lastUpdateTime`,`respondTime`,`weight`,`exploreUrl`,`exploreScreen`,`exploreStyle`,`ruleExplore`,`searchUrl`,`ruleSearch`,`ruleBookInfo`,`ruleToc`,`ruleContent`,`ruleReview`) SELECT `bookSourceUrl`,`bookSourceName`,`bookSourceGroup`,`bookSourceType`,`bookUrlPattern`,`customOrder`,`enabled`,`enabledExplore`,`enabledReview`,`jsLib`,`enabledCookieJar`,`enableDangerousApi`,`concurrentRate`,`header`,`loginUrl`,`loginUi`,`loginCheckJs`,`coverDecodeJs`,`bookSourceComment`,`variableComment`,`lastUpdateTime`,`respondTime`,`weight`,`exploreUrl`,`exploreScreen`,`exploreStyle`,`ruleExplore`,`searchUrl`,`ruleSearch`,`ruleBookInfo`,`ruleToc`,`ruleContent`,`ruleReview` FROM `book_sources`")
    connection.execSQL("DROP TABLE `book_sources`")
    connection.execSQL("ALTER TABLE `_new_book_sources` RENAME TO `book_sources`")
    connection.execSQL("CREATE TABLE IF NOT EXISTS `_new_replace_rules` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL DEFAULT '', `group` TEXT, `pattern` TEXT NOT NULL DEFAULT '', `replacement` TEXT NOT NULL DEFAULT '', `scope` TEXT, `scopeTitle` INTEGER NOT NULL DEFAULT 0, `scopeContent` INTEGER NOT NULL DEFAULT 1, `excludeScope` TEXT, `isEnabled` INTEGER NOT NULL DEFAULT 1, `isRegex` INTEGER NOT NULL DEFAULT 1, `timeoutMillisecond` INTEGER NOT NULL DEFAULT 3000, `sortOrder` INTEGER NOT NULL DEFAULT 0)")
    connection.execSQL("INSERT INTO `_new_replace_rules` (`id`,`name`,`group`,`pattern`,`replacement`,`scope`,`scopeTitle`,`scopeContent`,`excludeScope`,`isEnabled`,`isRegex`,`timeoutMillisecond`,`sortOrder`) SELECT `id`,`name`,`group`,`pattern`,`replacement`,`scope`,`scopeTitle`,`scopeContent`,`excludeScope`,`isEnabled`,`isRegex`,`timeoutMillisecond`,`sortOrder` FROM `replace_rules`")
    connection.execSQL("DROP TABLE `replace_rules`")
    connection.execSQL("ALTER TABLE `_new_replace_rules` RENAME TO `replace_rules`")
    connection.execSQL("CREATE TABLE IF NOT EXISTS `_new_search_keywords` (`word` TEXT NOT NULL, `usage` INTEGER NOT NULL, `lastUseTime` INTEGER NOT NULL, PRIMARY KEY(`word`)) WITHOUT ROWID")
    connection.execSQL("INSERT INTO `_new_search_keywords` (`word`,`usage`,`lastUseTime`) SELECT `word`,`usage`,`lastUseTime` FROM `search_keywords`")
    connection.execSQL("DROP TABLE `search_keywords`")
    connection.execSQL("ALTER TABLE `_new_search_keywords` RENAME TO `search_keywords`")
    connection.execSQL("CREATE TABLE IF NOT EXISTS `_new_cookies` (`url` TEXT NOT NULL, `cookie` TEXT NOT NULL, PRIMARY KEY(`url`)) WITHOUT ROWID")
    connection.execSQL("INSERT INTO `_new_cookies` (`url`,`cookie`) SELECT `url`,`cookie` FROM `cookies`")
    connection.execSQL("DROP TABLE `cookies`")
    connection.execSQL("ALTER TABLE `_new_cookies` RENAME TO `cookies`")
    connection.execSQL("CREATE TABLE IF NOT EXISTS `_new_caches` (`key` TEXT NOT NULL, `value` TEXT, `deadline` INTEGER NOT NULL, PRIMARY KEY(`key`)) WITHOUT ROWID")
    connection.execSQL("INSERT INTO `_new_caches` (`key`,`value`,`deadline`) SELECT `key`,`value`,`deadline` FROM `caches`")
    connection.execSQL("DROP TABLE `caches`")
    connection.execSQL("ALTER TABLE `_new_caches` RENAME TO `caches`")
    connection.execSQL("""
        |CREATE VIEW `book_sources_part` AS select bookSourceUrl, bookSourceName, bookSourceGroup, customOrder, enabled, enabledExplore,
        |    (ifnull(trim(loginUrl), '') <> '' or ifnull(trim(loginUi), '') <> '') hasLoginUrl, lastUpdateTime, respondTime, weight,
        |    (ifnull(trim(exploreUrl), '') <> '') hasExploreUrl
        |    from book_sources
        """.trimMargin())
  }
}
