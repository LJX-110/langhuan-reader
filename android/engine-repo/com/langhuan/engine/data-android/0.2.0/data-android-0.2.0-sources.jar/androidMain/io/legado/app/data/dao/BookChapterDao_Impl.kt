package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.BookChapter
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class BookChapterDao_Impl(
  __db: RoomDatabase,
) : BookChapterDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfBookChapter: EntityInsertAdapter<BookChapter>

  private val __updateAdapterOfBookChapter: EntityDeleteOrUpdateAdapter<BookChapter>
  init {
    this.__db = __db
    this.__insertAdapterOfBookChapter = object : EntityInsertAdapter<BookChapter>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `chapters` (`url`,`title`,`isVolume`,`bookUrl`,`index`,`isVip`,`isPay`,`resourceUrl`,`tag`,`wordCount`,`start`,`end`,`startFragmentId`,`endFragmentId`,`variable`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: BookChapter) {
        statement.bindText(1, entity.url)
        statement.bindText(2, entity.title)
        val _tmp: Int = if (entity.isVolume) 1 else 0
        statement.bindLong(3, _tmp.toLong())
        statement.bindText(4, entity.bookUrl)
        statement.bindLong(5, entity.index.toLong())
        val _tmp_1: Int = if (entity.isVip) 1 else 0
        statement.bindLong(6, _tmp_1.toLong())
        val _tmp_2: Int = if (entity.isPay) 1 else 0
        statement.bindLong(7, _tmp_2.toLong())
        val _tmpResourceUrl: String? = entity.resourceUrl
        if (_tmpResourceUrl == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpResourceUrl)
        }
        val _tmpTag: String? = entity.tag
        if (_tmpTag == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpTag)
        }
        val _tmpWordCount: String? = entity.wordCount
        if (_tmpWordCount == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpWordCount)
        }
        val _tmpStart: Long? = entity.start
        if (_tmpStart == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmpStart)
        }
        val _tmpEnd: Long? = entity.end
        if (_tmpEnd == null) {
          statement.bindNull(12)
        } else {
          statement.bindLong(12, _tmpEnd)
        }
        val _tmpStartFragmentId: String? = entity.startFragmentId
        if (_tmpStartFragmentId == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpStartFragmentId)
        }
        val _tmpEndFragmentId: String? = entity.endFragmentId
        if (_tmpEndFragmentId == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpEndFragmentId)
        }
        val _tmpVariable: String? = entity.variable
        if (_tmpVariable == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpVariable)
        }
      }
    }
    this.__updateAdapterOfBookChapter = object : EntityDeleteOrUpdateAdapter<BookChapter>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `chapters` SET `url` = ?,`title` = ?,`isVolume` = ?,`bookUrl` = ?,`index` = ?,`isVip` = ?,`isPay` = ?,`resourceUrl` = ?,`tag` = ?,`wordCount` = ?,`start` = ?,`end` = ?,`startFragmentId` = ?,`endFragmentId` = ?,`variable` = ? WHERE `bookUrl` = ? AND `url` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: BookChapter) {
        statement.bindText(1, entity.url)
        statement.bindText(2, entity.title)
        val _tmp: Int = if (entity.isVolume) 1 else 0
        statement.bindLong(3, _tmp.toLong())
        statement.bindText(4, entity.bookUrl)
        statement.bindLong(5, entity.index.toLong())
        val _tmp_1: Int = if (entity.isVip) 1 else 0
        statement.bindLong(6, _tmp_1.toLong())
        val _tmp_2: Int = if (entity.isPay) 1 else 0
        statement.bindLong(7, _tmp_2.toLong())
        val _tmpResourceUrl: String? = entity.resourceUrl
        if (_tmpResourceUrl == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpResourceUrl)
        }
        val _tmpTag: String? = entity.tag
        if (_tmpTag == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpTag)
        }
        val _tmpWordCount: String? = entity.wordCount
        if (_tmpWordCount == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpWordCount)
        }
        val _tmpStart: Long? = entity.start
        if (_tmpStart == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmpStart)
        }
        val _tmpEnd: Long? = entity.end
        if (_tmpEnd == null) {
          statement.bindNull(12)
        } else {
          statement.bindLong(12, _tmpEnd)
        }
        val _tmpStartFragmentId: String? = entity.startFragmentId
        if (_tmpStartFragmentId == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpStartFragmentId)
        }
        val _tmpEndFragmentId: String? = entity.endFragmentId
        if (_tmpEndFragmentId == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpEndFragmentId)
        }
        val _tmpVariable: String? = entity.variable
        if (_tmpVariable == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpVariable)
        }
        statement.bindText(16, entity.bookUrl)
        statement.bindText(17, entity.url)
      }
    }
  }

  public override suspend fun insert(vararg bookChapter: BookChapter): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfBookChapter.insert(_connection, bookChapter)
  }

  public override suspend fun update(vararg bookChapter: BookChapter): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfBookChapter.handleMultiple(_connection, bookChapter)
  }

  public override suspend fun search(
    bookUrl: String,
    key: String,
    start: Int,
    end: Int,
  ): List<BookChapter> {
    val _sql: String = "SELECT * FROM chapters where bookUrl = ? and `index` >= ? and `index` <= ? and title like '%'||?||'%' order by `index`"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 2
        _stmt.bindLong(_argIndex, start.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, end.toLong())
        _argIndex = 4
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfIsVolume: Int = getColumnIndexOrThrow(_stmt, "isVolume")
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfIndex: Int = getColumnIndexOrThrow(_stmt, "index")
        val _columnIndexOfIsVip: Int = getColumnIndexOrThrow(_stmt, "isVip")
        val _columnIndexOfIsPay: Int = getColumnIndexOrThrow(_stmt, "isPay")
        val _columnIndexOfResourceUrl: Int = getColumnIndexOrThrow(_stmt, "resourceUrl")
        val _columnIndexOfTag: Int = getColumnIndexOrThrow(_stmt, "tag")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfStart: Int = getColumnIndexOrThrow(_stmt, "start")
        val _columnIndexOfEnd: Int = getColumnIndexOrThrow(_stmt, "end")
        val _columnIndexOfStartFragmentId: Int = getColumnIndexOrThrow(_stmt, "startFragmentId")
        val _columnIndexOfEndFragmentId: Int = getColumnIndexOrThrow(_stmt, "endFragmentId")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _result: MutableList<BookChapter> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookChapter
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpIsVolume: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsVolume).toInt()
          _tmpIsVolume = _tmp != 0
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpIndex: Int
          _tmpIndex = _stmt.getLong(_columnIndexOfIndex).toInt()
          val _tmpIsVip: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsVip).toInt()
          _tmpIsVip = _tmp_1 != 0
          val _tmpIsPay: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsPay).toInt()
          _tmpIsPay = _tmp_2 != 0
          val _tmpResourceUrl: String?
          if (_stmt.isNull(_columnIndexOfResourceUrl)) {
            _tmpResourceUrl = null
          } else {
            _tmpResourceUrl = _stmt.getText(_columnIndexOfResourceUrl)
          }
          val _tmpTag: String?
          if (_stmt.isNull(_columnIndexOfTag)) {
            _tmpTag = null
          } else {
            _tmpTag = _stmt.getText(_columnIndexOfTag)
          }
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpStart: Long?
          if (_stmt.isNull(_columnIndexOfStart)) {
            _tmpStart = null
          } else {
            _tmpStart = _stmt.getLong(_columnIndexOfStart)
          }
          val _tmpEnd: Long?
          if (_stmt.isNull(_columnIndexOfEnd)) {
            _tmpEnd = null
          } else {
            _tmpEnd = _stmt.getLong(_columnIndexOfEnd)
          }
          val _tmpStartFragmentId: String?
          if (_stmt.isNull(_columnIndexOfStartFragmentId)) {
            _tmpStartFragmentId = null
          } else {
            _tmpStartFragmentId = _stmt.getText(_columnIndexOfStartFragmentId)
          }
          val _tmpEndFragmentId: String?
          if (_stmt.isNull(_columnIndexOfEndFragmentId)) {
            _tmpEndFragmentId = null
          } else {
            _tmpEndFragmentId = _stmt.getText(_columnIndexOfEndFragmentId)
          }
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          _item = BookChapter(_tmpUrl,_tmpTitle,_tmpIsVolume,_tmpBookUrl,_tmpIndex,_tmpIsVip,_tmpIsPay,_tmpResourceUrl,_tmpTag,_tmpWordCount,_tmpStart,_tmpEnd,_tmpStartFragmentId,_tmpEndFragmentId,_tmpVariable)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getChapterList(bookUrl: String): List<BookChapter> {
    val _sql: String = "select * from chapters where bookUrl = ? order by `index`"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfIsVolume: Int = getColumnIndexOrThrow(_stmt, "isVolume")
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfIndex: Int = getColumnIndexOrThrow(_stmt, "index")
        val _columnIndexOfIsVip: Int = getColumnIndexOrThrow(_stmt, "isVip")
        val _columnIndexOfIsPay: Int = getColumnIndexOrThrow(_stmt, "isPay")
        val _columnIndexOfResourceUrl: Int = getColumnIndexOrThrow(_stmt, "resourceUrl")
        val _columnIndexOfTag: Int = getColumnIndexOrThrow(_stmt, "tag")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfStart: Int = getColumnIndexOrThrow(_stmt, "start")
        val _columnIndexOfEnd: Int = getColumnIndexOrThrow(_stmt, "end")
        val _columnIndexOfStartFragmentId: Int = getColumnIndexOrThrow(_stmt, "startFragmentId")
        val _columnIndexOfEndFragmentId: Int = getColumnIndexOrThrow(_stmt, "endFragmentId")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _result: MutableList<BookChapter> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookChapter
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpIsVolume: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsVolume).toInt()
          _tmpIsVolume = _tmp != 0
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpIndex: Int
          _tmpIndex = _stmt.getLong(_columnIndexOfIndex).toInt()
          val _tmpIsVip: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsVip).toInt()
          _tmpIsVip = _tmp_1 != 0
          val _tmpIsPay: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsPay).toInt()
          _tmpIsPay = _tmp_2 != 0
          val _tmpResourceUrl: String?
          if (_stmt.isNull(_columnIndexOfResourceUrl)) {
            _tmpResourceUrl = null
          } else {
            _tmpResourceUrl = _stmt.getText(_columnIndexOfResourceUrl)
          }
          val _tmpTag: String?
          if (_stmt.isNull(_columnIndexOfTag)) {
            _tmpTag = null
          } else {
            _tmpTag = _stmt.getText(_columnIndexOfTag)
          }
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpStart: Long?
          if (_stmt.isNull(_columnIndexOfStart)) {
            _tmpStart = null
          } else {
            _tmpStart = _stmt.getLong(_columnIndexOfStart)
          }
          val _tmpEnd: Long?
          if (_stmt.isNull(_columnIndexOfEnd)) {
            _tmpEnd = null
          } else {
            _tmpEnd = _stmt.getLong(_columnIndexOfEnd)
          }
          val _tmpStartFragmentId: String?
          if (_stmt.isNull(_columnIndexOfStartFragmentId)) {
            _tmpStartFragmentId = null
          } else {
            _tmpStartFragmentId = _stmt.getText(_columnIndexOfStartFragmentId)
          }
          val _tmpEndFragmentId: String?
          if (_stmt.isNull(_columnIndexOfEndFragmentId)) {
            _tmpEndFragmentId = null
          } else {
            _tmpEndFragmentId = _stmt.getText(_columnIndexOfEndFragmentId)
          }
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          _item = BookChapter(_tmpUrl,_tmpTitle,_tmpIsVolume,_tmpBookUrl,_tmpIndex,_tmpIsVip,_tmpIsPay,_tmpResourceUrl,_tmpTag,_tmpWordCount,_tmpStart,_tmpEnd,_tmpStartFragmentId,_tmpEndFragmentId,_tmpVariable)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getChapterList(
    bookUrl: String,
    start: Int,
    end: Int,
  ): List<BookChapter> {
    val _sql: String = "select * from chapters where bookUrl = ? and `index` >= ? and `index` <= ? order by `index`"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 2
        _stmt.bindLong(_argIndex, start.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, end.toLong())
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfIsVolume: Int = getColumnIndexOrThrow(_stmt, "isVolume")
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfIndex: Int = getColumnIndexOrThrow(_stmt, "index")
        val _columnIndexOfIsVip: Int = getColumnIndexOrThrow(_stmt, "isVip")
        val _columnIndexOfIsPay: Int = getColumnIndexOrThrow(_stmt, "isPay")
        val _columnIndexOfResourceUrl: Int = getColumnIndexOrThrow(_stmt, "resourceUrl")
        val _columnIndexOfTag: Int = getColumnIndexOrThrow(_stmt, "tag")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfStart: Int = getColumnIndexOrThrow(_stmt, "start")
        val _columnIndexOfEnd: Int = getColumnIndexOrThrow(_stmt, "end")
        val _columnIndexOfStartFragmentId: Int = getColumnIndexOrThrow(_stmt, "startFragmentId")
        val _columnIndexOfEndFragmentId: Int = getColumnIndexOrThrow(_stmt, "endFragmentId")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _result: MutableList<BookChapter> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookChapter
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpIsVolume: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsVolume).toInt()
          _tmpIsVolume = _tmp != 0
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpIndex: Int
          _tmpIndex = _stmt.getLong(_columnIndexOfIndex).toInt()
          val _tmpIsVip: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsVip).toInt()
          _tmpIsVip = _tmp_1 != 0
          val _tmpIsPay: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsPay).toInt()
          _tmpIsPay = _tmp_2 != 0
          val _tmpResourceUrl: String?
          if (_stmt.isNull(_columnIndexOfResourceUrl)) {
            _tmpResourceUrl = null
          } else {
            _tmpResourceUrl = _stmt.getText(_columnIndexOfResourceUrl)
          }
          val _tmpTag: String?
          if (_stmt.isNull(_columnIndexOfTag)) {
            _tmpTag = null
          } else {
            _tmpTag = _stmt.getText(_columnIndexOfTag)
          }
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpStart: Long?
          if (_stmt.isNull(_columnIndexOfStart)) {
            _tmpStart = null
          } else {
            _tmpStart = _stmt.getLong(_columnIndexOfStart)
          }
          val _tmpEnd: Long?
          if (_stmt.isNull(_columnIndexOfEnd)) {
            _tmpEnd = null
          } else {
            _tmpEnd = _stmt.getLong(_columnIndexOfEnd)
          }
          val _tmpStartFragmentId: String?
          if (_stmt.isNull(_columnIndexOfStartFragmentId)) {
            _tmpStartFragmentId = null
          } else {
            _tmpStartFragmentId = _stmt.getText(_columnIndexOfStartFragmentId)
          }
          val _tmpEndFragmentId: String?
          if (_stmt.isNull(_columnIndexOfEndFragmentId)) {
            _tmpEndFragmentId = null
          } else {
            _tmpEndFragmentId = _stmt.getText(_columnIndexOfEndFragmentId)
          }
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          _item = BookChapter(_tmpUrl,_tmpTitle,_tmpIsVolume,_tmpBookUrl,_tmpIndex,_tmpIsVip,_tmpIsPay,_tmpResourceUrl,_tmpTag,_tmpWordCount,_tmpStart,_tmpEnd,_tmpStartFragmentId,_tmpEndFragmentId,_tmpVariable)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getChapter(bookUrl: String, index: Int): BookChapter? {
    val _sql: String = "select * from chapters where bookUrl = ? and `index` = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 2
        _stmt.bindLong(_argIndex, index.toLong())
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfIsVolume: Int = getColumnIndexOrThrow(_stmt, "isVolume")
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfIndex: Int = getColumnIndexOrThrow(_stmt, "index")
        val _columnIndexOfIsVip: Int = getColumnIndexOrThrow(_stmt, "isVip")
        val _columnIndexOfIsPay: Int = getColumnIndexOrThrow(_stmt, "isPay")
        val _columnIndexOfResourceUrl: Int = getColumnIndexOrThrow(_stmt, "resourceUrl")
        val _columnIndexOfTag: Int = getColumnIndexOrThrow(_stmt, "tag")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfStart: Int = getColumnIndexOrThrow(_stmt, "start")
        val _columnIndexOfEnd: Int = getColumnIndexOrThrow(_stmt, "end")
        val _columnIndexOfStartFragmentId: Int = getColumnIndexOrThrow(_stmt, "startFragmentId")
        val _columnIndexOfEndFragmentId: Int = getColumnIndexOrThrow(_stmt, "endFragmentId")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _result: BookChapter?
        if (_stmt.step()) {
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpIsVolume: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsVolume).toInt()
          _tmpIsVolume = _tmp != 0
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpIndex: Int
          _tmpIndex = _stmt.getLong(_columnIndexOfIndex).toInt()
          val _tmpIsVip: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsVip).toInt()
          _tmpIsVip = _tmp_1 != 0
          val _tmpIsPay: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsPay).toInt()
          _tmpIsPay = _tmp_2 != 0
          val _tmpResourceUrl: String?
          if (_stmt.isNull(_columnIndexOfResourceUrl)) {
            _tmpResourceUrl = null
          } else {
            _tmpResourceUrl = _stmt.getText(_columnIndexOfResourceUrl)
          }
          val _tmpTag: String?
          if (_stmt.isNull(_columnIndexOfTag)) {
            _tmpTag = null
          } else {
            _tmpTag = _stmt.getText(_columnIndexOfTag)
          }
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpStart: Long?
          if (_stmt.isNull(_columnIndexOfStart)) {
            _tmpStart = null
          } else {
            _tmpStart = _stmt.getLong(_columnIndexOfStart)
          }
          val _tmpEnd: Long?
          if (_stmt.isNull(_columnIndexOfEnd)) {
            _tmpEnd = null
          } else {
            _tmpEnd = _stmt.getLong(_columnIndexOfEnd)
          }
          val _tmpStartFragmentId: String?
          if (_stmt.isNull(_columnIndexOfStartFragmentId)) {
            _tmpStartFragmentId = null
          } else {
            _tmpStartFragmentId = _stmt.getText(_columnIndexOfStartFragmentId)
          }
          val _tmpEndFragmentId: String?
          if (_stmt.isNull(_columnIndexOfEndFragmentId)) {
            _tmpEndFragmentId = null
          } else {
            _tmpEndFragmentId = _stmt.getText(_columnIndexOfEndFragmentId)
          }
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          _result = BookChapter(_tmpUrl,_tmpTitle,_tmpIsVolume,_tmpBookUrl,_tmpIndex,_tmpIsVip,_tmpIsPay,_tmpResourceUrl,_tmpTag,_tmpWordCount,_tmpStart,_tmpEnd,_tmpStartFragmentId,_tmpEndFragmentId,_tmpVariable)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowChapter(bookUrl: String, index: Int): Flow<BookChapter?> {
    val _sql: String = "select * from chapters where bookUrl = ? and `index` = ?"
    return createFlow(__db, false, arrayOf("chapters")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 2
        _stmt.bindLong(_argIndex, index.toLong())
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfTitle: Int = getColumnIndexOrThrow(_stmt, "title")
        val _columnIndexOfIsVolume: Int = getColumnIndexOrThrow(_stmt, "isVolume")
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfIndex: Int = getColumnIndexOrThrow(_stmt, "index")
        val _columnIndexOfIsVip: Int = getColumnIndexOrThrow(_stmt, "isVip")
        val _columnIndexOfIsPay: Int = getColumnIndexOrThrow(_stmt, "isPay")
        val _columnIndexOfResourceUrl: Int = getColumnIndexOrThrow(_stmt, "resourceUrl")
        val _columnIndexOfTag: Int = getColumnIndexOrThrow(_stmt, "tag")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfStart: Int = getColumnIndexOrThrow(_stmt, "start")
        val _columnIndexOfEnd: Int = getColumnIndexOrThrow(_stmt, "end")
        val _columnIndexOfStartFragmentId: Int = getColumnIndexOrThrow(_stmt, "startFragmentId")
        val _columnIndexOfEndFragmentId: Int = getColumnIndexOrThrow(_stmt, "endFragmentId")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _result: BookChapter?
        if (_stmt.step()) {
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpTitle: String
          _tmpTitle = _stmt.getText(_columnIndexOfTitle)
          val _tmpIsVolume: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsVolume).toInt()
          _tmpIsVolume = _tmp != 0
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpIndex: Int
          _tmpIndex = _stmt.getLong(_columnIndexOfIndex).toInt()
          val _tmpIsVip: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsVip).toInt()
          _tmpIsVip = _tmp_1 != 0
          val _tmpIsPay: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsPay).toInt()
          _tmpIsPay = _tmp_2 != 0
          val _tmpResourceUrl: String?
          if (_stmt.isNull(_columnIndexOfResourceUrl)) {
            _tmpResourceUrl = null
          } else {
            _tmpResourceUrl = _stmt.getText(_columnIndexOfResourceUrl)
          }
          val _tmpTag: String?
          if (_stmt.isNull(_columnIndexOfTag)) {
            _tmpTag = null
          } else {
            _tmpTag = _stmt.getText(_columnIndexOfTag)
          }
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpStart: Long?
          if (_stmt.isNull(_columnIndexOfStart)) {
            _tmpStart = null
          } else {
            _tmpStart = _stmt.getLong(_columnIndexOfStart)
          }
          val _tmpEnd: Long?
          if (_stmt.isNull(_columnIndexOfEnd)) {
            _tmpEnd = null
          } else {
            _tmpEnd = _stmt.getLong(_columnIndexOfEnd)
          }
          val _tmpStartFragmentId: String?
          if (_stmt.isNull(_columnIndexOfStartFragmentId)) {
            _tmpStartFragmentId = null
          } else {
            _tmpStartFragmentId = _stmt.getText(_columnIndexOfStartFragmentId)
          }
          val _tmpEndFragmentId: String?
          if (_stmt.isNull(_columnIndexOfEndFragmentId)) {
            _tmpEndFragmentId = null
          } else {
            _tmpEndFragmentId = _stmt.getText(_columnIndexOfEndFragmentId)
          }
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          _result = BookChapter(_tmpUrl,_tmpTitle,_tmpIsVolume,_tmpBookUrl,_tmpIndex,_tmpIsVip,_tmpIsPay,_tmpResourceUrl,_tmpTag,_tmpWordCount,_tmpStart,_tmpEnd,_tmpStartFragmentId,_tmpEndFragmentId,_tmpVariable)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getChapterCount(bookUrl: String): Int {
    val _sql: String = "select count(url) from chapters where bookUrl = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun delByBook(bookUrl: String) {
    val _sql: String = "delete from chapters where bookUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upWordCount(
    bookUrl: String,
    url: String,
    wordCount: String,
  ) {
    val _sql: String = "update chapters set wordCount = ? where bookUrl = ? and url = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, wordCount)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 3
        _stmt.bindText(_argIndex, url)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upEnd(
    bookUrl: String,
    url: String,
    end: Long?,
  ) {
    val _sql: String = "update chapters set end = ? where bookUrl = ? and url = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (end == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, end)
        }
        _argIndex = 2
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 3
        _stmt.bindText(_argIndex, url)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upResourceUrl(
    bookUrl: String,
    url: String,
    resourceUrl: String?,
  ) {
    val _sql: String = "update chapters set resourceUrl = ? where bookUrl = ? and url = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        if (resourceUrl == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, resourceUrl)
        }
        _argIndex = 2
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 3
        _stmt.bindText(_argIndex, url)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upTitle(
    bookUrl: String,
    url: String,
    title: String,
  ) {
    val _sql: String = "update chapters set title = ? where bookUrl = ? and url = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, title)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookUrl)
        _argIndex = 3
        _stmt.bindText(_argIndex, url)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteNotShelfBookChapters() {
    val _sql: String = "delete from chapters where bookUrl not in (select bookUrl from books where (type & 1024) == 0)"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
