package io.legado.app.model.analyzeRule

import com.fleeksoft.ksoup.nodes.Node
import io.legado.app.constant.AppConst
import io.legado.app.constant.AppPattern.JS_PATTERN
import io.legado.app.data.entities.BaseSource
import io.legado.app.data.entities.BookChapterLike
import io.legado.app.data.entities.BookLike
import io.legado.app.help.JsExtensionsCommon
import io.legado.app.help.coroutine.printStackTraceOnDebug
import io.legado.app.help.source.SourceCacheProviders
import io.legado.app.help.source.SourceDebugLoggers
import io.legado.app.help.source.SourceNetworkProviders
import io.legado.app.help.source.getShareScope
import io.legado.app.model.script.JsBindings
import io.legado.app.model.script.JsEngines
import io.legado.app.model.script.JsScope
import io.legado.app.model.script.buildScriptBindings
import io.legado.app.model.script.evalUserScript
import io.legado.app.utils.Closeable
import io.legado.app.utils.EscapeUtils
import io.legado.app.utils.KS_JSON_STRICT
import io.legado.app.utils.NetworkUtils
import io.legado.app.utils.RuleRegexes
import io.legado.app.utils.URL
import io.legado.app.utils.decodeStringMapOrNull
import io.legado.app.utils.formatDoubleNoDecimal
import io.legado.app.utils.getOrPutLimit
import io.legado.app.utils.isDataUrl
import io.legado.app.utils.isJson
import io.legado.app.utils.splitNotBlank
import io.legado.app.utils.stackTraceStr
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.ContinuationInterceptor
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.EmptyCoroutineContext

/**
 * AnalyzeRule 主体: 纯 JVM 逻辑, 无 android-only 依赖。
 * app 端 [AnalyzeRule] 继承本类,
 * 添加 android-only 方法 (refreshTocUrl override)。
 *
 * KSP @JsApi 分派表由 app 端 AnalyzeRule 生成, 通过 getAllFunctions() 继承链
 * 自动包含本类的 public 方法, 方法名集合与原 AnalyzeRule 完全一致 (零 diff)。
 *
 * P3-3b: 参考 P3-3a AnalyzeUrlCore/AnalyzeUrl 继承拆分方案。
 *
 * **commonMain 下沉说明**:
 * - JVM 专属类型 (URL/Closeable) 经 expect/actual 包装, 详见 commonMain/utils/JvmPlatformTypes.kt。
 * - Pattern → kotlin.text.Regex (commonMain 原生), matcher 循环改 findAll/find, 行为等价。
 * - String.format(Locale.ROOT, "%.0f", value) → formatDoubleNoDecimal (expect/actual 包装)。
 */
// 原 @Keep (androidx.annotation.Keep 无 common 变体), 改由 app/proguard-rules.pro 按类名 keep
@Suppress("unused", "RegExpRedundantEscape")
open class AnalyzeRuleCore(
    var ruleData: RuleDataInterface? = null,
    private val source: BaseSource? = null,
    @Suppress("unused") private val preUpdateJs: Boolean = false
) : JsExtensionsCommon, Closeable {

    var chapter: BookChapterLike? = null
    var nextChapterUrl: String? = null
    private var content: Any? = null
    private var baseUrl: String? = null
    private var redirectUrl: URL? = null
    private var isJSON: Boolean = false
    private var isRegex: Boolean = false

    var variables: Map<AppConst.JsVarName, Any>? = null

    private var analyzeByXPath: AnalyzeByXPath? = null
    private var analyzeByJSoup: AnalyzeByJSoup? = null
    private var analyzeByJSonPath: AnalyzeByJSonPath? = null

    private val stringRuleCache = hashMapOf<String, List<SourceRule>>()
    private val regexCache = hashMapOf<String, Boolean>()
    private var topScopeRef: JsScope? = null

    var coroutineContext: CoroutineContext = EmptyCoroutineContext
        set(value) {
            field = value.minusKey(ContinuationInterceptor)
        }

    private var loggedNonStandardJSON = false

    // 下述短参显式重载: 补回原 @JvmOverloads 生成的 JVM 签名 (commonMain 无该注解),
    // 书源 JS 经 KSP 分派表/反射按 arity 匹配, 缺短签名会报"找不到 setContent(String) 方法"
    fun setContent(content: Any?): AnalyzeRuleCore = setContent(content, null)

    fun setContent(content: Any?, baseUrl: String? = null): AnalyzeRuleCore {
        if (content == null) throw AssertionError("内容不可空（Content cannot be null）")
        this.content = content
        isJSON = when (content) {
            is Node -> false
            else -> content.toString().isJson()
        }
        setBaseUrl(baseUrl)
        analyzeByXPath = null
        analyzeByJSoup = null
        analyzeByJSonPath = null
        return this
    }

    fun setBaseUrl(baseUrl: String?): AnalyzeRuleCore {
        baseUrl?.let {
            this.baseUrl = baseUrl
        }
        return this
    }

    // java.net.URL(String) 自 JDK 20 弃用 (建议改用 URI#toURL), 但二者不等价:
    // URI 会按 RFC2396 转义, 对含空格/|/{}/^ 的地址直接抛 IllegalArgumentException,
    // 而书源地址含这些字符是真实场景 (URL(String) 全部接受)。故保留 URL(String) 语义。
    // 抑制键是 TYPEALIAS_EXPANSION_DEPRECATION: URL 是 foundation 的 expect 类,
    // jvm actual 经 typealias 展开到 java.net.URL, 该路径不走 DEPRECATION 键。
    @Suppress("TYPEALIAS_EXPANSION_DEPRECATION")
    fun setRedirectUrl(url: String): URL? {
        if (url.isDataUrl()) {
            return redirectUrl
        }
        try {
            redirectUrl = URL(url)
        } catch (e: Exception) {
            SourceDebugLoggers.impl?.log("URL($url) error\n${e.message}")
        }
        return redirectUrl
    }

    /**
     * redirectUrl 转绝对地址。直接走 [NetworkUtils.getAbsoluteURL] 的 URL 重载
     * (与原版 AnalyzeRule 行为一致), 不经 String 门面, 避免 substringBefore(",")
     * 截断含逗号的 redirectUrl。该重载已提升为 expect/actual 默认实现,
     * JVM 端子类不再需要 override。
     */
    protected open fun getAbsoluteURL(redirectUrl: URL?, relativePath: String): String {
        return NetworkUtils.getAbsoluteURL(redirectUrl, relativePath)
    }

    /**
     * 获取XPath解析类
     */
    private fun getAnalyzeByXPath(o: Any): AnalyzeByXPath {
        return if (o != content) {
            AnalyzeByXPath(o)
        } else {
            if (analyzeByXPath == null) {
                analyzeByXPath = AnalyzeByXPath(content!!)
            }
            analyzeByXPath!!
        }
    }

    /**
     * 获取JSOUP解析类
     */
    private fun getAnalyzeByJSoup(o: Any): AnalyzeByJSoup {
        return if (o != content) {
            AnalyzeByJSoup(o)
        } else {
            if (analyzeByJSoup == null) {
                analyzeByJSoup = AnalyzeByJSoup(content!!)
            }
            analyzeByJSoup!!
        }
    }

    /**
     * 获取JSON解析类
     */
    private fun getAnalyzeByJSonPath(o: Any): AnalyzeByJSonPath {
        return if (o != content) {
            AnalyzeByJSonPath(o)
        } else {
            if (analyzeByJSonPath == null) {
                analyzeByJSonPath = AnalyzeByJSonPath(content!!)
            }
            analyzeByJSonPath!!
        }
    }

    /**
     * 获取文本列表
     */
    fun getStringList(rule: String?): List<String>? = getStringList(rule, null, false)

    fun getStringList(rule: String?, mContent: Any?): List<String>? =
        getStringList(rule, mContent, false)

    fun getStringList(rule: String?, mContent: Any? = null, isUrl: Boolean = false): List<String>? {
        if (rule.isNullOrEmpty()) return null
        val ruleList = splitSourceRuleCacheString(rule)
        return getStringList(ruleList, mContent, isUrl)
    }

    fun getStringList(ruleList: List<SourceRule>): List<String>? =
        getStringList(ruleList, null, false)

    fun getStringList(ruleList: List<SourceRule>, mContent: Any?): List<String>? =
        getStringList(ruleList, mContent, false)

    fun getStringList(
        ruleList: List<SourceRule>,
        mContent: Any? = null,
        isUrl: Boolean = false
    ): List<String>? {
        var result: Any? = null
        val content = mContent ?: this.content
        if (content != null && ruleList.isNotEmpty()) {
            result = content
            // JS 返回的对象在 Kotlin 侧是 NativeObject (对齐 rhino NativeObject)
            // JsonPath 返回的普通 Map 走 else 分支, 执行后续 JS/JsonPath 等
            val jsObj = JsEngines.asJsObject(result)
            if (jsObj != null) {
                val sourceRule = ruleList.first()
                putRule(sourceRule.putMap)
                sourceRule.makeUpRule(jsObj)
                result = if (sourceRule.getParamSize() > 1) {
                    // get {{}}
                    sourceRule.rule
                } else {
                    // 键值直接访问
                    jsObj[sourceRule.rule]
                }
                result?.let {
                    if (sourceRule.replaceRegex.isNotEmpty() && it is List<*>) {
                        result = it.map { o ->
                            replaceRegex(o.toString(), sourceRule)
                        }
                    } else if (sourceRule.replaceRegex.isNotEmpty()) {
                        result = replaceRegex(result.toString(), sourceRule)
                    }
                }
            } else {
                for (sourceRule in ruleList) {
                    putRule(sourceRule.putMap)
                    sourceRule.makeUpRule(result)
                    result ?: continue
                    val rule = sourceRule.rule
                    if (rule.isNotEmpty()) {
                        result = when (sourceRule.mode) {
                            Mode.Js -> evalJS(rule, result)
                            Mode.Json -> getAnalyzeByJSonPath(result).getStringList(rule)
                            Mode.XPath -> getAnalyzeByXPath(result).getStringList(rule)
                            Mode.Default -> getAnalyzeByJSoup(result).getStringList(rule)
                            else -> rule
                        }
                    }
                    if (sourceRule.replaceRegex.isNotEmpty() && result is List<*>) {
                        val newList = ArrayList<String>()
                        for (item in result) {
                            newList.add(replaceRegex(item.toString(), sourceRule))
                        }
                        result = newList
                    } else if (sourceRule.replaceRegex.isNotEmpty()) {
                        result = replaceRegex(result.toString(), sourceRule)
                    }
                }
            }
        }
        if (result == null) return null
        if (result is String) {
            result = result.split("\n")
        }
        if (isUrl) {
            val urlList = ArrayList<String>()
            if (result is List<*>) {
                for (url in result) {
                    val absoluteURL = getAbsoluteURL(redirectUrl, url.toString())
                    if (absoluteURL.isNotEmpty() && !urlList.contains(absoluteURL)) {
                        urlList.add(absoluteURL)
                    }
                }
            }
            return urlList
        }
        @Suppress("UNCHECKED_CAST")
        return result as? List<String>
    }

    /**
     * 获取文本
     */
    fun getString(ruleStr: String?): String = getString(ruleStr, null, false)

    fun getString(ruleStr: String?, mContent: Any?): String = getString(ruleStr, mContent, false)

    fun getString(ruleStr: String?, mContent: Any? = null, isUrl: Boolean = false): String {
        if (ruleStr.isNullOrEmpty()) return ""
        val ruleList = splitSourceRuleCacheString(ruleStr)
        return getString(ruleList, mContent, isUrl)
    }

    fun getString(ruleStr: String?, unescape: Boolean): String {
        if (ruleStr.isNullOrEmpty()) return ""
        val ruleList = splitSourceRuleCacheString(ruleStr)
        return getString(ruleList, unescape = unescape)
    }

    fun getString(ruleList: List<SourceRule>): String = getString(
        ruleList, null, isUrl = false,
        unescape = true
    )

    fun getString(ruleList: List<SourceRule>, mContent: Any?): String =
        getString(ruleList, mContent, isUrl = false, unescape = true)

    fun getString(ruleList: List<SourceRule>, mContent: Any?, isUrl: Boolean): String =
        getString(ruleList, mContent, isUrl, true)

    fun getString(
        ruleList: List<SourceRule>,
        mContent: Any? = null,
        isUrl: Boolean = false,
        unescape: Boolean = true
    ): String {
        var result: Any? = null
        val content = mContent ?: this.content
        if (content != null && ruleList.isNotEmpty()) {
            result = content
            // JS 返回的对象在 Kotlin 侧是 NativeObject (对齐 rhino NativeObject)
            // JsonPath 返回的普通 Map 走 else 分支, 执行后续 JS/JsonPath 等
            // 否则 `$.postTime<js>格式化</js>` 这类规则只取到原始时间戳,JS 被跳过。
            val jsObj = JsEngines.asJsObject(result)
            if (jsObj != null) {
                val sourceRule = ruleList.first()
                putRule(sourceRule.putMap)
                sourceRule.makeUpRule(jsObj)
                result = if (sourceRule.getParamSize() > 1) {
                    // get {{}}
                    sourceRule.rule
                } else {
                    // 键值直接访问
                    jsObj[sourceRule.rule]?.toString()
                }?.let {
                    replaceRegex(it, sourceRule)
                }
            } else {
                for (sourceRule in ruleList) {
                    putRule(sourceRule.putMap)
                    sourceRule.makeUpRule(result)
                    result ?: continue
                    val rule = sourceRule.rule
                    if (rule.isNotBlank() || sourceRule.replaceRegex.isEmpty()) {
                        result = when (sourceRule.mode) {
                            Mode.Js -> evalJS(rule, result)
                            Mode.Json -> getAnalyzeByJSonPath(result).getString(rule)
                            Mode.XPath -> getAnalyzeByXPath(result).getString(rule)
                            Mode.Default -> if (isUrl) {
                                getAnalyzeByJSoup(result).getString0(rule)
                            } else {
                                getAnalyzeByJSoup(result).getString(rule)
                            }

                            else -> rule
                        }
                    }
                    if (result != null && sourceRule.replaceRegex.isNotEmpty()) {
                        result = replaceRegex(result.toString(), sourceRule)
                    }
                }
            }
        }
        if (result == null) result = ""
        val resultStr = result.toString()
        val str = if (unescape && resultStr.indexOf('&') > -1) {
            EscapeUtils.unescapeHtml(resultStr)
        } else {
            resultStr
        }
        if (str.indexOf("::") > -1) {
            return str
        }
        if (isUrl) {
            return if (str.isBlank()) {
                baseUrl ?: ""
            } else {
                if (str.isDataUrl()) str
                else getAbsoluteURL(redirectUrl, str)
            }
        }
        return str
    }

    /**
     * 获取Element
     */
    fun getElement(ruleStr: String): Any? {
        if (ruleStr.isEmpty()) return null
        var result: Any? = null
        val content = this.content
        val ruleList = splitSourceRule(ruleStr, true)
        if (content != null && ruleList.isNotEmpty()) {
            result = content
            for (sourceRule in ruleList) {
                putRule(sourceRule.putMap)
                sourceRule.makeUpRule(result)
                result ?: continue
                val rule = sourceRule.rule
                result = when (sourceRule.mode) {
                    Mode.Regex -> AnalyzeByRegex.getElement(
                        result.toString(),
                        rule.splitNotBlank("&&")
                    )

                    Mode.Js -> evalJS(rule, result)
                    Mode.Json -> getAnalyzeByJSonPath(result).getObject(rule)
                    Mode.XPath -> getAnalyzeByXPath(result).getElements(rule)
                    else -> getAnalyzeByJSoup(result).getElements(rule)
                }
                if (sourceRule.replaceRegex.isNotEmpty()) {
                    result = replaceRegex(result.toString(), sourceRule)
                }
            }
        }
        return result
    }

    /**
     * 获取列表
     */
    @Suppress("UNCHECKED_CAST")
    fun getElements(ruleStr: String): List<Any> {
        var result: Any? = null
        val content = this.content
        val ruleList = splitSourceRule(ruleStr, true)
        if (content != null && ruleList.isNotEmpty()) {
            result = content
            for (sourceRule in ruleList) {
                putRule(sourceRule.putMap)
                result ?: continue
                val rule = sourceRule.rule
                result = when (sourceRule.mode) {
                    Mode.Regex -> AnalyzeByRegex.getElements(
                        result.toString(),
                        rule.splitNotBlank("&&")
                    )

                    Mode.Js -> evalJS(rule, result)
                    Mode.Json -> getAnalyzeByJSonPath(result).getList(rule)
                    Mode.XPath -> getAnalyzeByXPath(result).getElements(rule)
                    else -> getAnalyzeByJSoup(result).getElements(rule)
                }
            }
        }
        result?.let {
            return it as List<Any>
        }
        return ArrayList()
    }

    /**
     * 保存变量
     */
    private fun putRule(map: Map<String, String>) {
        for ((key, value) in map) {
            put(key, getString(value))
        }
    }

    /**
     * 分离put规则
     */
    private fun splitPutRule(ruleStr: String, putMap: HashMap<String, String>): String {
        var vRuleStr = ruleStr
        // Pattern.matcher → Regex.findAll: match.value 对应 matcher.group(), groupValues[1] 对应 matcher.group(1)
        for (match in putPattern.findAll(vRuleStr)) {
            vRuleStr = vRuleStr.replace(match.value, "")
            val putJsonStr = match.groupValues[1]
            // 复刻原 GSONStrict.fromJsonObject<Map<String, String>>(putJsonStr).getOrNull() ?: GSON.fromJsonObject<...>.getOrNull() 双栈
            // KS_JSON_STRICT 严格解析失败时降级到 KS_JSON 宽松解析 (并触发一次 log 提示 JSON 格式不规范)
            val strictMap = try {
                KS_JSON_STRICT.decodeFromString<Map<String, String>>(putJsonStr)
            } catch (_: Exception) {
                null
            }
            if (strictMap != null) {
                putMap.putAll(strictMap)
                continue
            }
            val lenientMap = decodeStringMapOrNull(putJsonStr)
            if (lenientMap != null) {
                if (!loggedNonStandardJSON) {
                    SourceDebugLoggers.impl?.log("≡@put 规则 JSON 格式不规范，请改为规范格式")
                    loggedNonStandardJSON = true
                }
                putMap.putAll(lenientMap)
            }
        }
        return vRuleStr
    }

    /**
     * 正则替换 (`##匹配##替换` 的匹配与替换段)。
     *
     * 经 [RuleRegexes] 以**模式串**执行: 调用方不得自行 `Regex(...)` —— native 端
     * `kotlin.text.Regex` 的编译与匹配都会递归 (编译无栈保护, 匹配按迭代次数递归),
     * 书源规则可把线程栈写穿直接闪退且不响应协程取消。详见 [RuleRegex]。
     */
    private fun replaceRegex(result: String, rule: SourceRule): String {
        if (rule.replaceRegex.isEmpty()) return result
        val replaceRegex = rule.replaceRegex
        val replacement = rule.replacement
        if (!isValidRegexCache(replaceRegex)) {
            // 模式串无法编译: 与原实现 `compileRegexCache` 返回 null 的降级路径一致
            return if (rule.replaceFirst) replacement else result.replace(replaceRegex, replacement)
        }
        return kotlin.runCatching {
            if (rule.replaceFirst) {
                // 原实现语义: 只取首个匹配的文本, 再在其中做一次替换 —— 返回值是**该匹配文本**
                // 的替换结果 (不是整串); 编译成功但无匹配时返回空串 (对齐原版 `else { "" }`)
                val match = RuleRegexes.get().find(
                    result, replaceRegex, multiline = false, timeout = RULE_REGEX_TIMEOUT
                )
                val matched = match?.value(result)
                if (matched == null) {
                    ""
                } else {
                    RuleRegexes.get().replace(
                        source = matched,
                        pattern = replaceRegex,
                        multiline = false,
                        replacement = replacement,
                        replaceFirst = true,
                        timeout = RULE_REGEX_TIMEOUT
                    )
                }
            } else {
                RuleRegexes.get().replace(
                    source = result,
                    pattern = replaceRegex,
                    multiline = false,
                    replacement = replacement,
                    replaceFirst = false,
                    timeout = RULE_REGEX_TIMEOUT
                )
            }
        }.getOrElse {
            // 超时或引擎拒绝: 与原实现 runCatching 失败时的降级一致
            if (rule.replaceFirst) replacement else result
        }
    }

    /**
     * 模式串可编译性缓存 (对应原 `compileRegexCache`)。
     *
     * 经 [RuleRegexes.validate] 判定, 不自行 `pattern.toRegex()` —— native 端的
     * `kotlin.text.Regex` 编译是递归下降且无栈保护, 畸形规则在这一步就会爆栈。
     */
    private fun isValidRegexCache(pattern: String): Boolean =
        regexCache.getOrPutLimit(pattern, 16) {
            RuleRegexes.get().validate(pattern, multiline = false) == null
        }

    /**
     * 规则正则的单次执行时间上限 (毫秒)。
     *
     * 书源规则里 `##匹配##替换` 没有用户可配的超时 (只有替换规则 [io.legado.app.data.entities.ReplaceRule]
     * 有), 而它正是崩溃点所在路径, 故取与替换规则默认值同口径的 3000ms 作为硬上限。
     */
    private val RULE_REGEX_TIMEOUT = 3000L

    /**
     * getString 类规则缓存
     */
    private fun splitSourceRuleCacheString(ruleStr: String?): List<SourceRule> {
        if (ruleStr.isNullOrEmpty()) return emptyList()
        return stringRuleCache.getOrPut(ruleStr) {
            splitSourceRule(ruleStr)
        }
    }

    /**
     * 分解规则生成规则列表
     */
    fun splitSourceRule(ruleStr: String?, allInOne: Boolean = false): List<SourceRule> {
        if (ruleStr.isNullOrEmpty()) return emptyList()
        val ruleList = ArrayList<SourceRule>()
        var mMode: Mode = Mode.Default
        var start = 0
        //仅首字符为:时为AllInOne，其实:与伪类选择器冲突，建议改成?更合理
        if (allInOne && ruleStr.startsWith(":")) {
            mMode = Mode.Regex
            isRegex = true
            start = 1
        } else if (isRegex) {
            mMode = Mode.Regex
        }
        var tmp: String
        // Pattern.matcher → Regex.findAll: groups[n]?.value 对应 matcher.group(n) (null 若组未参与匹配)
        for (match in JS_PATTERN.findAll(ruleStr)) {
            if (match.range.first > start) {
                tmp = ruleStr.substring(start, match.range.first).trim()
                if (tmp.isNotEmpty()) {
                    ruleList.add(SourceRule(tmp, mMode))
                }
            }
            ruleList.add(SourceRule(match.groups[2]?.value ?: match.groups[1]?.value ?: "", Mode.Js))
            start = match.range.last + 1
        }

        if (ruleStr.length > start) {
            tmp = ruleStr.substring(start).trim()
            if (tmp.isNotEmpty()) {
                ruleList.add(SourceRule(tmp, mMode))
            }
        }

        return ruleList
    }

    private fun getOrCreateSingleSourceRule(rule: String): List<SourceRule> {
        return stringRuleCache.getOrPutLimit(rule, 16) {
            listOf(SourceRule(rule))
        }
    }

    /**
     * 规则类
     */
    inner class SourceRule internal constructor(
        ruleStr: String,
        internal var mode: Mode = Mode.Default
    ) {
        internal var rule: String
        internal var replaceRegex = ""
        internal var replacement = ""
        internal var replaceFirst = false
        internal val putMap = HashMap<String, String>()
        private val ruleParam = ArrayList<String>()
        private val ruleType = ArrayList<Int>()
        private val getRuleType = -2
        private val jsRuleType = -1
        private val defaultRuleType = 0

        init {
            rule = when {
                mode == Mode.Js || mode == Mode.Regex -> ruleStr
                ruleStr.startsWith("@CSS:", true) -> {
                    mode = Mode.Default
                    ruleStr
                }

                ruleStr.startsWith("@@") -> {
                    mode = Mode.Default
                    ruleStr.substring(2)
                }

                ruleStr.startsWith("@XPath:", true) -> {
                    mode = Mode.XPath
                    ruleStr.substring(7)
                }

                ruleStr.startsWith("@Json:", true) -> {
                    mode = Mode.Json
                    ruleStr.substring(6)
                }

                isJSON || ruleStr.startsWith("$.") || ruleStr.startsWith("$[") -> {
                    mode = Mode.Json
                    ruleStr
                }

                ruleStr.startsWith("/") -> {//XPath特征很明显,无需配置单独的识别标头
                    mode = Mode.XPath
                    ruleStr
                }

                else -> ruleStr
            }
            //分离put
            rule = splitPutRule(rule, putMap)
            //@get,{{ }}, 拆分
            var start = 0
            var tmp: String
            // Pattern.matcher → Regex.findAll: 先收集所有匹配, 替代 while(find)+do-while(find) 语义;
            // match.range.first 对应 matcher.start(), match.range.last + 1 对应 matcher.end()
            val evalMatches = evalPattern.findAll(rule).toList()
            if (evalMatches.isNotEmpty()) {
                val firstMatch = evalMatches.first()
                tmp = rule.substring(start, firstMatch.range.first)
                if (mode != Mode.Js && mode != Mode.Regex &&
                    (firstMatch.range.first == 0 || !tmp.contains("##"))
                ) {
                    mode = Mode.Regex
                }
                for (match in evalMatches) {
                    if (match.range.first > start) {
                        tmp = rule.substring(start, match.range.first)
                        splitRegex(tmp)
                    }
                    tmp = match.value
                    when {
                        tmp.startsWith("@get:", true) -> {
                            ruleType.add(getRuleType)
                            ruleParam.add(tmp.substring(6, tmp.lastIndex))
                        }

                        tmp.startsWith("{{") -> {
                            ruleType.add(jsRuleType)
                            ruleParam.add(tmp.substring(2, tmp.length - 2))
                        }

                        else -> {
                            splitRegex(tmp)
                        }
                    }
                    start = match.range.last + 1
                }
            }
            if (rule.length > start) {
                tmp = rule.substring(start)
                splitRegex(tmp)
            }
        }

        /**
         * 拆分\$\d{1,2}
         */
        private fun splitRegex(ruleStr: String) {
            var start = 0
            var tmp: String
            val ruleStrArray = ruleStr.split("##")
            // Pattern.matcher → Regex.findAll: 先收集所有匹配, 替代 while(find)+do-while(find) 语义
            val regexMatches = regexPattern.findAll(ruleStrArray[0]).toList()
            if (regexMatches.isNotEmpty()) {
                if (mode != Mode.Js && mode != Mode.Regex) {
                    mode = Mode.Regex
                }
                for (match in regexMatches) {
                    if (match.range.first > start) {
                        tmp = ruleStr.substring(start, match.range.first)
                        ruleType.add(defaultRuleType)
                        ruleParam.add(tmp)
                    }
                    tmp = match.value
                    ruleType.add(tmp.substring(1).toInt())
                    ruleParam.add(tmp)
                    start = match.range.last + 1
                }
            }
            if (ruleStr.length > start) {
                tmp = ruleStr.substring(start)
                ruleType.add(defaultRuleType)
                ruleParam.add(tmp)
            }
        }

        /**
         * 替换@get,{{ }}
         */
        fun makeUpRule(result: Any?) {
            val infoVal = StringBuilder()
            if (ruleParam.isNotEmpty()) {
                var index = ruleParam.size
                while (index-- > 0) {
                    val regType = ruleType[index]
                    when {
                        regType > defaultRuleType -> {
                            @Suppress("UNCHECKED_CAST")
                            (result as? List<String?>)?.run {
                                if (this.size > regType) {
                                    this[regType]?.let {
                                        infoVal.insert(0, it)
                                    }
                                }
                            } ?: infoVal.insert(0, ruleParam[index])
                        }

                        regType == jsRuleType -> {
                            if (isRule(ruleParam[index])) {
                                val ruleList = getOrCreateSingleSourceRule(ruleParam[index])
                                getString(ruleList).let {
                                    infoVal.insert(0, it)
                                }
                            } else {
                                when (val jsEval: Any? = evalJS(ruleParam[index], result)) {
                                    null -> Unit
                                    is String -> infoVal.insert(0, jsEval)
                                    is Double if jsEval % 1.0 == 0.0 -> infoVal.insert(
                                        0,
                                        formatDoubleNoDecimal(jsEval)
                                    )

                                    else -> infoVal.insert(0, jsEval.toString())
                                }
                            }
                        }

                        regType == getRuleType -> {
                            infoVal.insert(0, get(ruleParam[index]))
                        }

                        else -> infoVal.insert(0, ruleParam[index])
                    }
                }
                rule = infoVal.toString()
            }
            //分离正则表达式
            val ruleStrS = rule.split("##")
            rule = ruleStrS[0].trim()
            if (ruleStrS.size > 1) {
                replaceRegex = ruleStrS[1]
            }
            if (ruleStrS.size > 2) {
                replacement = ruleStrS[2]
            }
            if (ruleStrS.size > 3) {
                replaceFirst = true
            }
        }

        private fun isRule(ruleStr: String): Boolean {
            return ruleStr.startsWith('@') //js首个字符不可能是@，除非是装饰器，所以@开头规定为规则
                    || ruleStr.startsWith("$.")
                    || ruleStr.startsWith("$[")
                    || ruleStr.startsWith("//")
        }

        fun getParamSize(): Int {
            return ruleParam.size
        }
    }

    enum class Mode {
        XPath, Json, Default, Js, Regex
    }

    /**
     * 保存数据
     */
    fun put(key: String, value: String): String {
        if (key == "bookName" || key == "title") {
            SourceDebugLoggers.impl?.log("≡变量 $key 在特定情况下会被覆盖，建议使用其他键名")
        }
        chapter?.putVariable(key, value)
            ?: ruleData?.putVariable(key, value)
            ?: source?.put(key, value)
        return value
    }

    /**
     * 获取保存的数据
     */
    fun get(key: String): String {
        when (key) {
            "bookName" -> (ruleData as? BookLike)?.let {
                return it.name
            }

            "title" -> chapter?.let {
                return it.title
            }
        }
        return chapter?.getVariable(key)?.takeIf { it.isNotEmpty() }
            ?: ruleData?.getVariable(key)?.takeIf { it.isNotEmpty() }
            ?: source?.get(key)?.takeIf { it.isNotEmpty() }
            ?: ""
    }

    /**
     * 执行JS
     *
     * quickjs 没有 rhino 的 prototype 继承链, 不能直接 `bindings.prototype = topScope`,
     * 这里把 bindings 注入子作用域 (同时写 globalThis), 用户脚本交给引擎固定执行器求值:
     * - let/const 留在 eval 词法环境, 不污染 topScope (避免重复执行报 "redeclaration of 'xxx'")
     * - eval 返回末尾表达式值 (对齐 rhino script.exec 返回最后一个表达式;
     *   完成值是 eval/script 目标特有语义, 函数调用只认显式 return, 求值离不开 eval)
     * - 已知限制: 顶层 return 落在 eval 里报 "Illegal return statement",
     *   书源请用末尾表达式或自带 IIFE
     * - bindings 同时写入 globalThis, jsLib 里定义在 topScope 上的自由函数 (如 `lk`)
     *   内部访问 `cache` 等 binding 也能命中, 执行后由 evalInSubScope 清理, 避免残留。
     *
     * 注: jsLib 在 topScope(SharedJsScope)上执行,是共享的,不需要包裹。
     */
    fun evalJS(jsStr: String, result: Any? = null): Any? {
        // 空字符串早返回，避免不必要的编译执行开销
        if (jsStr.isBlank()) return null
        val bindings = buildScriptBindings { bindings ->
            variables?.forEach { (k, v) -> bindings[k.key] = v }
            bindings["java"] = this
            bindings["cookie"] = SourceNetworkProviders.impl?.asBinding()
            bindings["cache"] = SourceCacheProviders.impl?.asBinding()
            bindings["source"] = source
            bindings["book"] = ruleData as? BookLike
            bindings["result"] = result
            bindings["baseUrl"] = baseUrl
            bindings["chapter"] = chapter
            bindings["title"] = chapter?.title
            bindings["src"] = content
            bindings["nextChapterUrl"] = nextChapterUrl
            bindings.dangerousApi = source?.enableDangerousApi == true
        }
        // 无共享作用域时自建一个并长期持有: 后续调用复用同一作用域, jsLib 定义的自由函数才可见。
        val topScope = source?.getShareScope(coroutineContext) ?: topScopeRef
            ?: JsEngines.get().getRuntimeScope(JsBindings()).also { topScopeRef = it }
        return try {
            evalUserScript(jsStr, topScope, bindings, coroutineContext)
        } catch (e: Exception) {
            throw RuntimeException("JS执行出错\n${e.message}", e)
        }
    }

    override fun getSource(): BaseSource? {
        return source
    }

    /**
     * js实现跨域访问,不能删
     *
     * 注: 本方法 override [JsExtensionsCommon.ajax] 默认实现, 传递 ruleData (行为更完整,
     * commonMain 默认实现只传 source)。app 端 [AnalyzeRule] 可继续 override 转发到
     * super<AnalyzeRuleCore>.ajax 选择本方法。
     * 此处用 [AnalyzeUrlCore] (shared 同包) 替代 app 端 AnalyzeUrl, 行为等价 (ajax 只用 getStrResponse)。
     */
    override fun ajax(url: Any): String? {
        val urlStr = if (url is List<*>) {
            url.firstOrNull().toString()
        } else {
            url.toString()
        }
        val analyzeUrl = AnalyzeUrlFactories.create(
            urlStr,
            source = source,
            ruleData = ruleData,
            coroutineContext = coroutineContext
        )
        return kotlin.runCatching {
            analyzeUrl.getStrResponse().body
        }.onFailure {
            coroutineContext.ensureActive()
            SourceDebugLoggers.impl?.log("ajax(${urlStr}) error\n${it.stackTraceToString()}")
            it.printStackTraceOnDebug()
        }.getOrElse {
            it.stackTraceStr
        }
    }

    /**
     * 更新tocUrl,有些书源目录url定期更新,可以在js调用更新
     *
     * P2 Step 2: 经 [io.legado.app.model.webBook.BookInfoRefreshers] provider 反向调用 app 端 WebBook.getBookInfoAwait,
     * 解除 AnalyzeRule→WebBook 直接依赖, 为 AnalyzeRule 主体下沉 shared 做前置。
     *
     * 本方法依赖 app 端 BookSource/Book 类型, 无法在 shared 中实现, 留作 open fun
     * 由 app 端 [AnalyzeRule] override 实现原逻辑。
     * KSP @JsApi 分派表通过继承链自动包含本方法名, 零 diff。
     */
    open fun refreshTocUrl() {
        // app 端 AnalyzeRule 实现
    }

    /**
     * 释放 AnalyzeRule 持有的 native 资源。
     *
     * 仅 [topScopeRef] 需显式 close: 当 source 为 null (DictRule/DirectLinkUpload 等无书源构造) 时,
     * evalJS 会走 [JsEngines.get().getRuntimeScope] 自建 scope 并缓存到 [topScopeRef],
     * 该 scope 不在 SharedJsScope 的 LruCache 中, 无显式释放路径会泄漏 native QuickJs 实例。
     *
     * 有 source 路径走 SharedJsScope 共享 scope, 由其 LruCache 淘汰时 close, 此处 topScopeRef 为 null, close 是空操作。
     */
    override fun close() {
        topScopeRef?.let {
            topScopeRef = null
            it.close()
        }
    }

    companion object {
        // Pattern.compile → Regex: setOf(RegexOption.IGNORE_CASE) 对应 Pattern.CASE_INSENSITIVE
        private val putPattern = Regex("@put:(\\{[^}]+?\\})", setOf(RegexOption.IGNORE_CASE))
        private val evalPattern =
            Regex("@get:\\{[^}]+?\\}|\\{\\{[\\w\\W]*?\\}\\}", setOf(RegexOption.IGNORE_CASE))
        private val regexPattern = Regex("\\$\\d{1,2}")
    }

}
