package io.legado.app.`data`

import androidx.room3.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class AppDatabase_AutoMigration_87_88_Impl : Migration {
  public constructor() : super(87, 88)

  public override suspend fun migrate(connection: SQLiteConnection) {
    connection.execSQL("DROP VIEW book_sources_part")
    connection.execSQL("ALTER TABLE `bookmarks` ADD COLUMN `type` INTEGER NOT NULL DEFAULT 0")
    connection.execSQL("ALTER TABLE `bookmarks` ADD COLUMN `endPos` INTEGER NOT NULL DEFAULT 0")
    connection.execSQL("ALTER TABLE `bookmarks` ADD COLUMN `color` INTEGER DEFAULT 0")
    connection.execSQL("ALTER TABLE `bookmarks` ADD COLUMN `lineStyle` INTEGER NOT NULL DEFAULT 0")
    connection.execSQL("CREATE TABLE IF NOT EXISTS `keywordHighlights` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `word` TEXT NOT NULL, `color` INTEGER, `lineStyle` INTEGER NOT NULL, `isEnabled` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL, `pattern` TEXT NOT NULL, `isRegex` INTEGER NOT NULL, `scope` TEXT, `excludeScope` TEXT)")
    connection.execSQL("""
        |CREATE VIEW `book_sources_part` AS select bookSourceUrl, bookSourceName, bookSourceGroup, customOrder, enabled, enabledExplore,
        |    (ifnull(trim(loginUrl), '') <> '' or ifnull(trim(loginUi), '') <> '') hasLoginUrl, lastUpdateTime, respondTime, weight,
        |    (ifnull(trim(exploreUrl), '') <> '') hasExploreUrl
        |    from book_sources
        """.trimMargin())
  }
}
