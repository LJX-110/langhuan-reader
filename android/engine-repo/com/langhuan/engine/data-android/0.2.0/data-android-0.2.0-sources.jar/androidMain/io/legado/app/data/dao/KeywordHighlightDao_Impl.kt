package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.KeywordHighlight
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class KeywordHighlightDao_Impl(
  __db: RoomDatabase,
) : KeywordHighlightDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfKeywordHighlight: EntityInsertAdapter<KeywordHighlight>

  private val __deleteAdapterOfKeywordHighlight: EntityDeleteOrUpdateAdapter<KeywordHighlight>

  private val __updateAdapterOfKeywordHighlight: EntityDeleteOrUpdateAdapter<KeywordHighlight>
  init {
    this.__db = __db
    this.__insertAdapterOfKeywordHighlight = object : EntityInsertAdapter<KeywordHighlight>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `keywordHighlights` (`id`,`word`,`color`,`lineStyle`,`isEnabled`,`sortOrder`,`pattern`,`isRegex`,`scope`,`excludeScope`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: KeywordHighlight) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.word)
        val _tmpColor: Int? = entity.color
        if (_tmpColor == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpColor.toLong())
        }
        statement.bindLong(4, entity.lineStyle.toLong())
        val _tmp: Int = if (entity.isEnabled) 1 else 0
        statement.bindLong(5, _tmp.toLong())
        statement.bindLong(6, entity.sortOrder.toLong())
        statement.bindText(7, entity.pattern)
        val _tmp_1: Int = if (entity.isRegex) 1 else 0
        statement.bindLong(8, _tmp_1.toLong())
        val _tmpScope: String? = entity.scope
        if (_tmpScope == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpScope)
        }
        val _tmpExcludeScope: String? = entity.excludeScope
        if (_tmpExcludeScope == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpExcludeScope)
        }
      }
    }
    this.__deleteAdapterOfKeywordHighlight = object : EntityDeleteOrUpdateAdapter<KeywordHighlight>() {
      protected override fun createQuery(): String = "DELETE FROM `keywordHighlights` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: KeywordHighlight) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__updateAdapterOfKeywordHighlight = object : EntityDeleteOrUpdateAdapter<KeywordHighlight>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `keywordHighlights` SET `id` = ?,`word` = ?,`color` = ?,`lineStyle` = ?,`isEnabled` = ?,`sortOrder` = ?,`pattern` = ?,`isRegex` = ?,`scope` = ?,`excludeScope` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: KeywordHighlight) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.word)
        val _tmpColor: Int? = entity.color
        if (_tmpColor == null) {
          statement.bindNull(3)
        } else {
          statement.bindLong(3, _tmpColor.toLong())
        }
        statement.bindLong(4, entity.lineStyle.toLong())
        val _tmp: Int = if (entity.isEnabled) 1 else 0
        statement.bindLong(5, _tmp.toLong())
        statement.bindLong(6, entity.sortOrder.toLong())
        statement.bindText(7, entity.pattern)
        val _tmp_1: Int = if (entity.isRegex) 1 else 0
        statement.bindLong(8, _tmp_1.toLong())
        val _tmpScope: String? = entity.scope
        if (_tmpScope == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpScope)
        }
        val _tmpExcludeScope: String? = entity.excludeScope
        if (_tmpExcludeScope == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpExcludeScope)
        }
        statement.bindLong(11, entity.id)
      }
    }
  }

  public override suspend fun insert(vararg rule: KeywordHighlight): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfKeywordHighlight.insert(_connection, rule)
  }

  public override suspend fun delete(vararg rule: KeywordHighlight): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfKeywordHighlight.handleMultiple(_connection, rule)
  }

  public override suspend fun update(vararg rule: KeywordHighlight): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfKeywordHighlight.handleMultiple(_connection, rule)
  }

  public override suspend fun all(): List<KeywordHighlight> {
    val _sql: String = "select * from keywordHighlights order by sortOrder, id"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _result: MutableList<KeywordHighlight> = mutableListOf()
        while (_stmt.step()) {
          val _item: KeywordHighlight
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          val _tmpIsEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp != 0
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpIsRegex: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_1 != 0
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          _item = KeywordHighlight(_tmpId,_tmpWord,_tmpColor,_tmpLineStyle,_tmpIsEnabled,_tmpSortOrder,_tmpPattern,_tmpIsRegex,_tmpScope,_tmpExcludeScope)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enabled(): List<KeywordHighlight> {
    val _sql: String = "select * from keywordHighlights where isEnabled = 1 order by sortOrder, id"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _result: MutableList<KeywordHighlight> = mutableListOf()
        while (_stmt.step()) {
          val _item: KeywordHighlight
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          val _tmpIsEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp != 0
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpIsRegex: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_1 != 0
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          _item = KeywordHighlight(_tmpId,_tmpWord,_tmpColor,_tmpLineStyle,_tmpIsEnabled,_tmpSortOrder,_tmpPattern,_tmpIsRegex,_tmpScope,_tmpExcludeScope)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<KeywordHighlight>> {
    val _sql: String = "select * from keywordHighlights order by sortOrder, id"
    return createFlow(__db, false, arrayOf("keywordHighlights")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _result: MutableList<KeywordHighlight> = mutableListOf()
        while (_stmt.step()) {
          val _item: KeywordHighlight
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          val _tmpIsEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp != 0
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpIsRegex: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_1 != 0
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          _item = KeywordHighlight(_tmpId,_tmpWord,_tmpColor,_tmpLineStyle,_tmpIsEnabled,_tmpSortOrder,_tmpPattern,_tmpIsRegex,_tmpScope,_tmpExcludeScope)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowEnabled(): Flow<List<KeywordHighlight>> {
    val _sql: String = "select * from keywordHighlights where isEnabled = 1 order by sortOrder, id"
    return createFlow(__db, false, arrayOf("keywordHighlights")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _result: MutableList<KeywordHighlight> = mutableListOf()
        while (_stmt.step()) {
          val _item: KeywordHighlight
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          val _tmpIsEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp != 0
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpIsRegex: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_1 != 0
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          _item = KeywordHighlight(_tmpId,_tmpWord,_tmpColor,_tmpLineStyle,_tmpIsEnabled,_tmpSortOrder,_tmpPattern,_tmpIsRegex,_tmpScope,_tmpExcludeScope)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findById(id: Long): KeywordHighlight? {
    val _sql: String = "select * from keywordHighlights where id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfWord: Int = getColumnIndexOrThrow(_stmt, "word")
        val _columnIndexOfColor: Int = getColumnIndexOrThrow(_stmt, "color")
        val _columnIndexOfLineStyle: Int = getColumnIndexOrThrow(_stmt, "lineStyle")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfSortOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _result: KeywordHighlight?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpWord: String
          _tmpWord = _stmt.getText(_columnIndexOfWord)
          val _tmpColor: Int?
          if (_stmt.isNull(_columnIndexOfColor)) {
            _tmpColor = null
          } else {
            _tmpColor = _stmt.getLong(_columnIndexOfColor).toInt()
          }
          val _tmpLineStyle: Int
          _tmpLineStyle = _stmt.getLong(_columnIndexOfLineStyle).toInt()
          val _tmpIsEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp != 0
          val _tmpSortOrder: Int
          _tmpSortOrder = _stmt.getLong(_columnIndexOfSortOrder).toInt()
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpIsRegex: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_1 != 0
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          _result = KeywordHighlight(_tmpId,_tmpWord,_tmpColor,_tmpLineStyle,_tmpIsEnabled,_tmpSortOrder,_tmpPattern,_tmpIsRegex,_tmpScope,_tmpExcludeScope)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxOrder(): Int {
    val _sql: String = "select IFNULL(MAX(sortOrder), 0) from keywordHighlights"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteAll() {
    val _sql: String = "delete from keywordHighlights"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
