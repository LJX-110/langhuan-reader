package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.KeyboardAssist
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.jvm.JvmName
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class KeyboardAssistsDao_Impl(
  __db: RoomDatabase,
) : KeyboardAssistsDao {
  private val __db: RoomDatabase

  public override val flowAll: Flow<List<KeyboardAssist>>
    get() = getFlowAll()

  private val __insertAdapterOfKeyboardAssist: EntityInsertAdapter<KeyboardAssist>

  private val __deleteAdapterOfKeyboardAssist: EntityDeleteOrUpdateAdapter<KeyboardAssist>

  private val __updateAdapterOfKeyboardAssist: EntityDeleteOrUpdateAdapter<KeyboardAssist>
  init {
    this.__db = __db
    this.__insertAdapterOfKeyboardAssist = object : EntityInsertAdapter<KeyboardAssist>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `keyboardAssists` (`type`,`key`,`value`,`serialNo`) VALUES (?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: KeyboardAssist) {
        statement.bindLong(1, entity.type.toLong())
        statement.bindText(2, entity.key)
        statement.bindText(3, entity.value)
        statement.bindLong(4, entity.serialNo.toLong())
      }
    }
    this.__deleteAdapterOfKeyboardAssist = object : EntityDeleteOrUpdateAdapter<KeyboardAssist>() {
      protected override fun createQuery(): String = "DELETE FROM `keyboardAssists` WHERE `type` = ? AND `key` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: KeyboardAssist) {
        statement.bindLong(1, entity.type.toLong())
        statement.bindText(2, entity.key)
      }
    }
    this.__updateAdapterOfKeyboardAssist = object : EntityDeleteOrUpdateAdapter<KeyboardAssist>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `keyboardAssists` SET `type` = ?,`key` = ?,`value` = ?,`serialNo` = ? WHERE `type` = ? AND `key` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: KeyboardAssist) {
        statement.bindLong(1, entity.type.toLong())
        statement.bindText(2, entity.key)
        statement.bindText(3, entity.value)
        statement.bindLong(4, entity.serialNo.toLong())
        statement.bindLong(5, entity.type.toLong())
        statement.bindText(6, entity.key)
      }
    }
  }

  public override suspend fun insert(vararg keyboardAssist: KeyboardAssist): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfKeyboardAssist.insert(_connection, keyboardAssist)
  }

  public override suspend fun delete(vararg keyboardAssist: KeyboardAssist): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfKeyboardAssist.handleMultiple(_connection, keyboardAssist)
  }

  public override suspend fun update(vararg keyboardAssist: KeyboardAssist): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfKeyboardAssist.handleMultiple(_connection, keyboardAssist)
  }

  public override suspend fun all(): List<KeyboardAssist> {
    val _sql: String = "select * from keyboardAssists order by serialNo"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfKey: Int = getColumnIndexOrThrow(_stmt, "key")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfSerialNo: Int = getColumnIndexOrThrow(_stmt, "serialNo")
        val _result: MutableList<KeyboardAssist> = mutableListOf()
        while (_stmt.step()) {
          val _item: KeyboardAssist
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfKey)
          val _tmpValue: String
          _tmpValue = _stmt.getText(_columnIndexOfValue)
          val _tmpSerialNo: Int
          _tmpSerialNo = _stmt.getLong(_columnIndexOfSerialNo).toInt()
          _item = KeyboardAssist(_tmpType,_tmpKey,_tmpValue,_tmpSerialNo)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  @JvmName("_privateGetFlowAll")
  private fun getFlowAll(): Flow<List<KeyboardAssist>> {
    val _sql: String = "select * from keyboardAssists order by serialNo"
    return createFlow(__db, false, arrayOf("keyboardAssists")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfKey: Int = getColumnIndexOrThrow(_stmt, "key")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfSerialNo: Int = getColumnIndexOrThrow(_stmt, "serialNo")
        val _result: MutableList<KeyboardAssist> = mutableListOf()
        while (_stmt.step()) {
          val _item: KeyboardAssist
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfKey)
          val _tmpValue: String
          _tmpValue = _stmt.getText(_columnIndexOfValue)
          val _tmpSerialNo: Int
          _tmpSerialNo = _stmt.getLong(_columnIndexOfSerialNo).toInt()
          _item = KeyboardAssist(_tmpType,_tmpKey,_tmpValue,_tmpSerialNo)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowByType(type: Int): Flow<List<KeyboardAssist>> {
    val _sql: String = "select * from keyboardAssists where type = ? order by serialNo"
    return createFlow(__db, false, arrayOf("keyboardAssists")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, type.toLong())
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfKey: Int = getColumnIndexOrThrow(_stmt, "key")
        val _columnIndexOfValue: Int = getColumnIndexOrThrow(_stmt, "value")
        val _columnIndexOfSerialNo: Int = getColumnIndexOrThrow(_stmt, "serialNo")
        val _result: MutableList<KeyboardAssist> = mutableListOf()
        while (_stmt.step()) {
          val _item: KeyboardAssist
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpKey: String
          _tmpKey = _stmt.getText(_columnIndexOfKey)
          val _tmpValue: String
          _tmpValue = _stmt.getText(_columnIndexOfValue)
          val _tmpSerialNo: Int
          _tmpSerialNo = _stmt.getLong(_columnIndexOfSerialNo).toInt()
          _item = KeyboardAssist(_tmpType,_tmpKey,_tmpValue,_tmpSerialNo)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxSerialNo(): Int {
    val _sql: String = "select max(serialNo) from keyboardAssists"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
