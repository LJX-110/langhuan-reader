package io.legado.app.help.source

import io.legado.app.constant.AppPattern
import io.legado.app.data.AppDbProviders
import io.legado.app.data.entities.SearchBook
import io.legado.app.data.entities.SourceFilterRule
import io.legado.app.exception.RegexTimeoutException
import io.legado.app.utils.RuleRegexes
import io.legado.app.utils.splitNotBlank
import kotlin.concurrent.Volatile
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/**
 * 搜索 / 发现共用的结果过滤器：
 * - 任一规则命中即丢弃；
 * - 规则内部 fields 是 OR：任一字段被正则命中即视为规则命中；
 * - scope 沿用 SearchScope 字符串协议：
 *   空 → 对全部书源生效；
 *   含 `::` → 视为单源（`name::url`），按 origin 命中判断；
 *   否则视为分组 CSV，按书源所属分组与 scope 求交。
 *
 * 规则编辑保存后、书源增删改后须调 [reload]。
 *
 * 下沉说明: 原 app 端 `appDb.sourceFilterRuleDao` / `appDb.bookSourceDao` 改走
 * [AppDbProviders.get()] provider 间接, 行为完全一致。
 */
object SearchBookFilter {

    private data class CompiledRule(
        val pattern: String,
        val fields: Set<SourceFilterRule.Field>,
        val scope: SourceFilterRule.Scope,
    )

    private data class Snapshot(
        val rules: List<CompiledRule>,
        val originToGroups: Map<String, Set<String>>,
    ) {
        val isEmpty get() = rules.isEmpty()
    }

    @Volatile
    private var snapshot: Snapshot? = null
    private val EMPTY = Snapshot(emptyList(), emptyMap())

    // 改 suspend 后, synchronized (非 suspend lambda) 无法容纳 suspend 调用, 改用 Mutex
    private val mutex = Mutex()

    fun reload() {
        snapshot = null
    }

    /**
     * 持久化规则并刷新缓存；调用方负责切到 IO 线程。
     */
    suspend fun save(rule: SourceFilterRule, isNew: Boolean) {
        if (isNew) AppDbProviders.get().sourceFilterRuleDao.insert(rule)
        else AppDbProviders.get().sourceFilterRuleDao.update(rule)
        reload()
    }

    /**
     * 删除规则并刷新缓存；调用方负责切到 IO 线程。
     */
    suspend fun delete(rule: SourceFilterRule) {
        AppDbProviders.get().sourceFilterRuleDao.delete(rule)
        reload()
    }

    suspend fun apply(books: List<SearchBook>): Pair<List<SearchBook>, Int> {
        val snap = ensure()
        if (snap.isEmpty) return books to 0
        val result = books.filterNot { it.matchesAnyRule(snap) }
        return result to (books.size - result.size)
    }

    /**
     * 列出在指定 scope 下会生效的启用规则。
     * scope 字符串协议同 [io.legado.app.ui.book.search.SearchScope]：空 → 全部；含 `::` → 单源；否则 → 分组 CSV。
     * 单源场景按 origin 命中；分组场景按规则范围与目标分组是否相交。
     */
    suspend fun rulesInScope(scope: String?): List<SourceFilterRule> {
        val raw = runCatching { AppDbProviders.get().sourceFilterRuleDao.enabled() }.getOrNull().orEmpty()
        if (raw.isEmpty()) return emptyList()
        val target = SourceFilterRule.parseScope(scope.orEmpty())
        if (target is SourceFilterRule.Scope.None) return emptyList()
        // appliesTo 为 suspend, List.filter 的 lambda 非 suspend, 改用等价手写循环
        val result = ArrayList<SourceFilterRule>(raw.size)
        for (rule in raw) {
            if (rule.appliesTo(target)) result.add(rule)
        }
        return result
    }

    private suspend fun SourceFilterRule.appliesTo(target: SourceFilterRule.Scope): Boolean {
        val ruleScope = SourceFilterRule.parseScope(scope)
        return when (ruleScope) {
            SourceFilterRule.Scope.All -> true
            SourceFilterRule.Scope.None -> false
            is SourceFilterRule.Scope.Source -> when (target) {
                SourceFilterRule.Scope.All -> true
                is SourceFilterRule.Scope.Source -> target.url == ruleScope.url
                else -> false
            }

            is SourceFilterRule.Scope.Groups -> when (target) {
                SourceFilterRule.Scope.All -> true
                is SourceFilterRule.Scope.Groups -> target.names.any { it in ruleScope.names }
                is SourceFilterRule.Scope.Source -> {
                    val tokens = ensure().originToGroups[target.url] ?: emptySet()
                    tokens.any { it in ruleScope.names }
                }

                else -> false
            }
        }
    }

    private fun SearchBook.matchesAnyRule(snap: Snapshot): Boolean {
        val bookGroups = snap.originToGroups[origin] ?: emptySet()
        for (rule in snap.rules) {
            if (!rule.inScope(origin, bookGroups)) continue
            if (rule.matchesAnyField(this)) return true
        }
        return false
    }

    private fun CompiledRule.inScope(origin: String, bookGroups: Set<String>): Boolean =
        when (scope) {
            SourceFilterRule.Scope.All -> true
            SourceFilterRule.Scope.None -> false
            is SourceFilterRule.Scope.Source -> origin == scope.url
            is SourceFilterRule.Scope.Groups -> bookGroups.any { it in scope.names }
        }

    private fun CompiledRule.matchesAnyField(book: SearchBook): Boolean {
        for (field in fields) {
            val text = field.extract(book) ?: continue
            if (text.isEmpty()) continue
            // 经 [RuleRegexes]: 筛选规则模式串来自用户, native 端 `kotlin.text.Regex` 的编译与
            // 匹配都会递归, 病态规则可把线程栈写穿直接闪退且无法中止。
            // 只把超时当“未命中”: 编译失败意味着规则写错, 不可与“不匹配”混为一谈
            val matched = try {
                RuleRegexes.get().find(text, pattern, multiline = false, timeout = FILTER_TIMEOUT) != null
            } catch (_: RegexTimeoutException) {
                false
            }
            if (matched) return true
        }
        return false
    }

    private fun SourceFilterRule.Field.extract(book: SearchBook): String? = when (this) {
        SourceFilterRule.Field.NAME -> book.name
        SourceFilterRule.Field.AUTHOR -> book.author
        SourceFilterRule.Field.INTRO -> book.intro
        SourceFilterRule.Field.KIND -> book.kind
        SourceFilterRule.Field.WORD_COUNT -> book.wordCount
    }

    private suspend fun ensure(): Snapshot {
        snapshot?.let { return it }
        return mutex.withLock {
            snapshot?.let { return@withLock it }
            val rules = compileEnabled()
            if (rules.isEmpty()) {
                return@withLock EMPTY.also { snapshot = it }
            }
            val originToGroups = buildOriginToGroups()
            Snapshot(rules, originToGroups).also { snapshot = it }
        }
    }

    private suspend fun compileEnabled(): List<CompiledRule> {
        val raw =
            runCatching { AppDbProviders.get().sourceFilterRuleDao.enabled() }.getOrNull() ?: return emptyList()
        return raw.mapNotNull { rule ->
            if (rule.pattern.isEmpty()) return@mapNotNull null
            // 编译校验经 [RuleRegexes] (平台实现): native 端 `Regex(pattern)` 编译是递归下降
            // 且无栈保护, 畸形模式串会直接爆栈闪退
            if (RuleRegexes.get().validate(rule.pattern, multiline = false) != null) return@mapNotNull null
            val fields = SourceFilterRule.parseFields(rule.fields)
            if (fields.isEmpty()) return@mapNotNull null
            CompiledRule(
                pattern = rule.pattern,
                fields = fields,
                scope = SourceFilterRule.parseScope(rule.scope),
            )
        }
    }

    private suspend fun buildOriginToGroups(): Map<String, Set<String>> {
        val all = runCatching { AppDbProviders.get().bookSourceDao.allPart() }.getOrNull() ?: return emptyMap()
        val map = HashMap<String, Set<String>>(all.size)
        for (source in all) {
            val raw = source.bookSourceGroup ?: continue
            val tokens = raw.splitNotBlank(AppPattern.splitGroupRegex)
            if (tokens.isEmpty()) continue
            map[source.bookSourceUrl] = tokens.toHashSet()
        }
        return map
    }

    /** 筛选规则的单次匹配上限 (毫秒), 与替换规则默认超时同口径。 */
    private const val FILTER_TIMEOUT = 3000L
}
