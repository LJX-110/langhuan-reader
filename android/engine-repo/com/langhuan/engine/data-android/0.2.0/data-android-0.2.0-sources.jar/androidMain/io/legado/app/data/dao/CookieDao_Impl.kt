package io.legado.app.`data`.dao

import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.Cookie
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.reflect.KClass

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class CookieDao_Impl(
  __db: RoomDatabase,
) : CookieDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfCookie: EntityInsertAdapter<Cookie>
  init {
    this.__db = __db
    this.__insertAdapterOfCookie = object : EntityInsertAdapter<Cookie>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `cookies` (`url`,`cookie`) VALUES (?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Cookie) {
        statement.bindText(1, entity.url)
        statement.bindText(2, entity.cookie)
      }
    }
  }

  public override suspend fun insert(vararg cookie: Cookie): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfCookie.insert(_connection, cookie)
  }

  public override suspend fun `get`(url: String): Cookie? {
    val _sql: String = "SELECT * FROM cookies Where url = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, url)
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfCookie: Int = getColumnIndexOrThrow(_stmt, "cookie")
        val _result: Cookie?
        if (_stmt.step()) {
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpCookie: String
          _tmpCookie = _stmt.getText(_columnIndexOfCookie)
          _result = Cookie(_tmpUrl,_tmpCookie)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun delete(url: String) {
    val _sql: String = "delete from cookies where url = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, url)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteOkHttp() {
    val _sql: String = "delete from cookies where url like '%|%'"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
