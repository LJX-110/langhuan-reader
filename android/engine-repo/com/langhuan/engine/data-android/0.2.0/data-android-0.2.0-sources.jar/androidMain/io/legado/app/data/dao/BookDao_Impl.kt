package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.appendPlaceholders
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performInTransactionSuspending
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.Book
import io.legado.app.`data`.entities.BookSource
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class BookDao_Impl(
  __db: RoomDatabase,
) : BookDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfBook: EntityInsertAdapter<Book>

  private val __converters: Book.Converters = Book.Converters()

  private val __deleteAdapterOfBook: EntityDeleteOrUpdateAdapter<Book>

  private val __updateAdapterOfBook: EntityDeleteOrUpdateAdapter<Book>
  init {
    this.__db = __db
    this.__insertAdapterOfBook = object : EntityInsertAdapter<Book>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `books` (`bookUrl`,`tocUrl`,`origin`,`originName`,`name`,`author`,`kind`,`customTag`,`coverUrl`,`customCoverUrl`,`intro`,`customIntro`,`charset`,`type`,`group`,`latestChapterTitle`,`latestChapterTime`,`lastCheckTime`,`lastCheckCount`,`totalChapterNum`,`durChapterTitle`,`durChapterIndex`,`durChapterPos`,`durChapterTime`,`wordCount`,`canUpdate`,`order`,`originOrder`,`variable`,`readConfig`,`syncTime`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Book) {
        statement.bindText(1, entity.bookUrl)
        statement.bindText(2, entity.tocUrl)
        statement.bindText(3, entity.origin)
        statement.bindText(4, entity.originName)
        statement.bindText(5, entity.name)
        statement.bindText(6, entity.author)
        val _tmpKind: String? = entity.kind
        if (_tmpKind == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpKind)
        }
        val _tmpCustomTag: String? = entity.customTag
        if (_tmpCustomTag == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpCustomTag)
        }
        val _tmpCoverUrl: String? = entity.coverUrl
        if (_tmpCoverUrl == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpCoverUrl)
        }
        val _tmpCustomCoverUrl: String? = entity.customCoverUrl
        if (_tmpCustomCoverUrl == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpCustomCoverUrl)
        }
        val _tmpIntro: String? = entity.intro
        if (_tmpIntro == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpIntro)
        }
        val _tmpCustomIntro: String? = entity.customIntro
        if (_tmpCustomIntro == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpCustomIntro)
        }
        val _tmpCharset: String? = entity.charset
        if (_tmpCharset == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpCharset)
        }
        statement.bindLong(14, entity.type.toLong())
        statement.bindLong(15, entity.group)
        val _tmpLatestChapterTitle: String? = entity.latestChapterTitle
        if (_tmpLatestChapterTitle == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpLatestChapterTitle)
        }
        statement.bindLong(17, entity.latestChapterTime)
        statement.bindLong(18, entity.lastCheckTime)
        statement.bindLong(19, entity.lastCheckCount.toLong())
        statement.bindLong(20, entity.totalChapterNum.toLong())
        val _tmpDurChapterTitle: String? = entity.durChapterTitle
        if (_tmpDurChapterTitle == null) {
          statement.bindNull(21)
        } else {
          statement.bindText(21, _tmpDurChapterTitle)
        }
        statement.bindLong(22, entity.durChapterIndex.toLong())
        statement.bindLong(23, entity.durChapterPos.toLong())
        statement.bindLong(24, entity.durChapterTime)
        val _tmpWordCount: String? = entity.wordCount
        if (_tmpWordCount == null) {
          statement.bindNull(25)
        } else {
          statement.bindText(25, _tmpWordCount)
        }
        val _tmp: Int = if (entity.canUpdate) 1 else 0
        statement.bindLong(26, _tmp.toLong())
        statement.bindLong(27, entity.order.toLong())
        statement.bindLong(28, entity.originOrder.toLong())
        val _tmpVariable: String? = entity.variable
        if (_tmpVariable == null) {
          statement.bindNull(29)
        } else {
          statement.bindText(29, _tmpVariable)
        }
        val _tmpReadConfig: Book.ReadConfig? = entity.readConfig
        val _tmp_1: String? = __converters.readConfigToString(_tmpReadConfig)
        if (_tmp_1 == null) {
          statement.bindNull(30)
        } else {
          statement.bindText(30, _tmp_1)
        }
        statement.bindLong(31, entity.syncTime)
      }
    }
    this.__deleteAdapterOfBook = object : EntityDeleteOrUpdateAdapter<Book>() {
      protected override fun createQuery(): String = "DELETE FROM `books` WHERE `bookUrl` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: Book) {
        statement.bindText(1, entity.bookUrl)
      }
    }
    this.__updateAdapterOfBook = object : EntityDeleteOrUpdateAdapter<Book>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `books` SET `bookUrl` = ?,`tocUrl` = ?,`origin` = ?,`originName` = ?,`name` = ?,`author` = ?,`kind` = ?,`customTag` = ?,`coverUrl` = ?,`customCoverUrl` = ?,`intro` = ?,`customIntro` = ?,`charset` = ?,`type` = ?,`group` = ?,`latestChapterTitle` = ?,`latestChapterTime` = ?,`lastCheckTime` = ?,`lastCheckCount` = ?,`totalChapterNum` = ?,`durChapterTitle` = ?,`durChapterIndex` = ?,`durChapterPos` = ?,`durChapterTime` = ?,`wordCount` = ?,`canUpdate` = ?,`order` = ?,`originOrder` = ?,`variable` = ?,`readConfig` = ?,`syncTime` = ? WHERE `bookUrl` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: Book) {
        statement.bindText(1, entity.bookUrl)
        statement.bindText(2, entity.tocUrl)
        statement.bindText(3, entity.origin)
        statement.bindText(4, entity.originName)
        statement.bindText(5, entity.name)
        statement.bindText(6, entity.author)
        val _tmpKind: String? = entity.kind
        if (_tmpKind == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpKind)
        }
        val _tmpCustomTag: String? = entity.customTag
        if (_tmpCustomTag == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpCustomTag)
        }
        val _tmpCoverUrl: String? = entity.coverUrl
        if (_tmpCoverUrl == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpCoverUrl)
        }
        val _tmpCustomCoverUrl: String? = entity.customCoverUrl
        if (_tmpCustomCoverUrl == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpCustomCoverUrl)
        }
        val _tmpIntro: String? = entity.intro
        if (_tmpIntro == null) {
          statement.bindNull(11)
        } else {
          statement.bindText(11, _tmpIntro)
        }
        val _tmpCustomIntro: String? = entity.customIntro
        if (_tmpCustomIntro == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpCustomIntro)
        }
        val _tmpCharset: String? = entity.charset
        if (_tmpCharset == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpCharset)
        }
        statement.bindLong(14, entity.type.toLong())
        statement.bindLong(15, entity.group)
        val _tmpLatestChapterTitle: String? = entity.latestChapterTitle
        if (_tmpLatestChapterTitle == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpLatestChapterTitle)
        }
        statement.bindLong(17, entity.latestChapterTime)
        statement.bindLong(18, entity.lastCheckTime)
        statement.bindLong(19, entity.lastCheckCount.toLong())
        statement.bindLong(20, entity.totalChapterNum.toLong())
        val _tmpDurChapterTitle: String? = entity.durChapterTitle
        if (_tmpDurChapterTitle == null) {
          statement.bindNull(21)
        } else {
          statement.bindText(21, _tmpDurChapterTitle)
        }
        statement.bindLong(22, entity.durChapterIndex.toLong())
        statement.bindLong(23, entity.durChapterPos.toLong())
        statement.bindLong(24, entity.durChapterTime)
        val _tmpWordCount: String? = entity.wordCount
        if (_tmpWordCount == null) {
          statement.bindNull(25)
        } else {
          statement.bindText(25, _tmpWordCount)
        }
        val _tmp: Int = if (entity.canUpdate) 1 else 0
        statement.bindLong(26, _tmp.toLong())
        statement.bindLong(27, entity.order.toLong())
        statement.bindLong(28, entity.originOrder.toLong())
        val _tmpVariable: String? = entity.variable
        if (_tmpVariable == null) {
          statement.bindNull(29)
        } else {
          statement.bindText(29, _tmpVariable)
        }
        val _tmpReadConfig: Book.ReadConfig? = entity.readConfig
        val _tmp_1: String? = __converters.readConfigToString(_tmpReadConfig)
        if (_tmp_1 == null) {
          statement.bindNull(30)
        } else {
          statement.bindText(30, _tmp_1)
        }
        statement.bindLong(31, entity.syncTime)
        statement.bindText(32, entity.bookUrl)
      }
    }
  }

  public override suspend fun insert(vararg book: Book): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfBook.insert(_connection, book)
  }

  public override suspend fun delete(vararg book: Book): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfBook.handleMultiple(_connection, book)
  }

  public override suspend fun update(vararg book: Book): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfBook.handleMultiple(_connection, book)
  }

  public override suspend fun replace(oldBook: Book, newBook: Book): Unit = performInTransactionSuspending(__db) {
    super@BookDao_Impl.replace(oldBook, newBook)
  }

  public override fun flowRoot(): Flow<List<Book>> {
    val _sql: String = """
        |
        |        select * from books where type & 8 > 0
        |        and type & 256 = 0
        |        and ((SELECT sum(groupId) FROM book_groups where groupId > 0) & `group`) = 0
        |        and (select show from book_groups where groupId = -4) != 1
        |        
        """.trimMargin()
    return createFlow(__db, false, arrayOf("books", "book_groups")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<Book>> {
    val _sql: String = "SELECT * FROM books"
    return createFlow(__db, false, arrayOf("books")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowLocal(): Flow<List<Book>> {
    val _sql: String = "SELECT * FROM books WHERE type & 256 > 0"
    return createFlow(__db, false, arrayOf("books")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowNoGroup(): Flow<List<Book>> {
    val _sql: String = """
        |
        |        select * from books
        |        where ((SELECT sum(groupId) FROM book_groups where groupId > 0) & `group`) = 0
        |        
        """.trimMargin()
    return createFlow(__db, false, arrayOf("books", "book_groups")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowByUserGroup(group: Long): Flow<List<Book>> {
    val _sql: String = "SELECT * FROM books WHERE (`group` & ?) > 0"
    return createFlow(__db, false, arrayOf("books")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, group)
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowUpdateError(): Flow<List<Book>> {
    val _sql: String = "SELECT * FROM books WHERE type & 16 > 0"
    return createFlow(__db, false, arrayOf("books")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findByName(vararg names: String): List<Book> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("SELECT * FROM books WHERE `name` in (")
    val _inputSize: Int = names.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in names) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item_1 = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBookByFileName(fileName: String): Book? {
    val _sql: String = "select * from books where originName = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, fileName)
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: Book?
        if (_stmt.step()) {
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _result = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBook(bookUrl: String): Book? {
    val _sql: String = "SELECT * FROM books WHERE bookUrl = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: Book?
        if (_stmt.step()) {
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _result = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBook(name: String, author: String): Book? {
    val _sql: String = "SELECT * FROM books WHERE name = ? and author = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, name)
        _argIndex = 2
        _stmt.bindText(_argIndex, author)
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: Book?
        if (_stmt.step()) {
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _result = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getAllUseBookSource(): List<BookSource> {
    val _sql: String = """
        |select distinct bs.* from books, book_sources bs 
        |        where origin == bookSourceUrl and origin not like 'loc_book%' 
        |        and origin not like 'webDav::%'
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBookByOrigin(name: String, origin: String): Book? {
    val _sql: String = "SELECT * FROM books WHERE name = ? and origin = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, name)
        _argIndex = 2
        _stmt.bindText(_argIndex, origin)
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: Book?
        if (_stmt.step()) {
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _result = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowShelfBookKeys(): Flow<List<ShelfBookKey>> {
    val _sql: String = "SELECT name, author, bookUrl FROM books"
    return createFlow(__db, false, arrayOf("books")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfName: Int = 0
        val _columnIndexOfAuthor: Int = 1
        val _columnIndexOfBookUrl: Int = 2
        val _result: MutableList<ShelfBookKey> = mutableListOf()
        while (_stmt.step()) {
          val _item: ShelfBookKey
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          _item = ShelfBookKey(_tmpName,_tmpAuthor,_tmpBookUrl)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun searchShelfBooks(key: String): Flow<List<Book>> {
    val _sql: String = """
        |
        |        SELECT * FROM books 
        |        WHERE name LIKE '%' || ? || '%' COLLATE NOCASE
        |        OR author LIKE '%' || ? || '%' COLLATE NOCASE
        |        OR originName LIKE '%' || ? || '%' COLLATE NOCASE
        |        OR kind LIKE '%' || ? || '%' COLLATE NOCASE
        |        OR intro LIKE '%' || ? || '%' COLLATE NOCASE
        |        ORDER BY durChapterTime DESC
        |        
        """.trimMargin()
    return createFlow(__db, false, arrayOf("books")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _argIndex = 2
        _stmt.bindText(_argIndex, key)
        _argIndex = 3
        _stmt.bindText(_argIndex, key)
        _argIndex = 4
        _stmt.bindText(_argIndex, key)
        _argIndex = 5
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(): List<Book> {
    val _sql: String = "SELECT * FROM books"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: MutableList<Book> = mutableListOf()
        while (_stmt.step()) {
          val _item: Book
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _item = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun lastReadBook(): Book? {
    val _sql: String = "SELECT * FROM books where type & 8 > 0 ORDER BY durChapterTime DESC limit 1"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookUrl: Int = getColumnIndexOrThrow(_stmt, "bookUrl")
        val _columnIndexOfTocUrl: Int = getColumnIndexOrThrow(_stmt, "tocUrl")
        val _columnIndexOfOrigin: Int = getColumnIndexOrThrow(_stmt, "origin")
        val _columnIndexOfOriginName: Int = getColumnIndexOrThrow(_stmt, "originName")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfAuthor: Int = getColumnIndexOrThrow(_stmt, "author")
        val _columnIndexOfKind: Int = getColumnIndexOrThrow(_stmt, "kind")
        val _columnIndexOfCustomTag: Int = getColumnIndexOrThrow(_stmt, "customTag")
        val _columnIndexOfCoverUrl: Int = getColumnIndexOrThrow(_stmt, "coverUrl")
        val _columnIndexOfCustomCoverUrl: Int = getColumnIndexOrThrow(_stmt, "customCoverUrl")
        val _columnIndexOfIntro: Int = getColumnIndexOrThrow(_stmt, "intro")
        val _columnIndexOfCustomIntro: Int = getColumnIndexOrThrow(_stmt, "customIntro")
        val _columnIndexOfCharset: Int = getColumnIndexOrThrow(_stmt, "charset")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfLatestChapterTitle: Int = getColumnIndexOrThrow(_stmt, "latestChapterTitle")
        val _columnIndexOfLatestChapterTime: Int = getColumnIndexOrThrow(_stmt, "latestChapterTime")
        val _columnIndexOfLastCheckTime: Int = getColumnIndexOrThrow(_stmt, "lastCheckTime")
        val _columnIndexOfLastCheckCount: Int = getColumnIndexOrThrow(_stmt, "lastCheckCount")
        val _columnIndexOfTotalChapterNum: Int = getColumnIndexOrThrow(_stmt, "totalChapterNum")
        val _columnIndexOfDurChapterTitle: Int = getColumnIndexOrThrow(_stmt, "durChapterTitle")
        val _columnIndexOfDurChapterIndex: Int = getColumnIndexOrThrow(_stmt, "durChapterIndex")
        val _columnIndexOfDurChapterPos: Int = getColumnIndexOrThrow(_stmt, "durChapterPos")
        val _columnIndexOfDurChapterTime: Int = getColumnIndexOrThrow(_stmt, "durChapterTime")
        val _columnIndexOfWordCount: Int = getColumnIndexOrThrow(_stmt, "wordCount")
        val _columnIndexOfCanUpdate: Int = getColumnIndexOrThrow(_stmt, "canUpdate")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfOriginOrder: Int = getColumnIndexOrThrow(_stmt, "originOrder")
        val _columnIndexOfVariable: Int = getColumnIndexOrThrow(_stmt, "variable")
        val _columnIndexOfReadConfig: Int = getColumnIndexOrThrow(_stmt, "readConfig")
        val _columnIndexOfSyncTime: Int = getColumnIndexOrThrow(_stmt, "syncTime")
        val _result: Book?
        if (_stmt.step()) {
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          val _tmpTocUrl: String
          _tmpTocUrl = _stmt.getText(_columnIndexOfTocUrl)
          val _tmpOrigin: String
          _tmpOrigin = _stmt.getText(_columnIndexOfOrigin)
          val _tmpOriginName: String
          _tmpOriginName = _stmt.getText(_columnIndexOfOriginName)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpAuthor: String
          _tmpAuthor = _stmt.getText(_columnIndexOfAuthor)
          val _tmpKind: String?
          if (_stmt.isNull(_columnIndexOfKind)) {
            _tmpKind = null
          } else {
            _tmpKind = _stmt.getText(_columnIndexOfKind)
          }
          val _tmpCustomTag: String?
          if (_stmt.isNull(_columnIndexOfCustomTag)) {
            _tmpCustomTag = null
          } else {
            _tmpCustomTag = _stmt.getText(_columnIndexOfCustomTag)
          }
          val _tmpCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCoverUrl)) {
            _tmpCoverUrl = null
          } else {
            _tmpCoverUrl = _stmt.getText(_columnIndexOfCoverUrl)
          }
          val _tmpCustomCoverUrl: String?
          if (_stmt.isNull(_columnIndexOfCustomCoverUrl)) {
            _tmpCustomCoverUrl = null
          } else {
            _tmpCustomCoverUrl = _stmt.getText(_columnIndexOfCustomCoverUrl)
          }
          val _tmpIntro: String?
          if (_stmt.isNull(_columnIndexOfIntro)) {
            _tmpIntro = null
          } else {
            _tmpIntro = _stmt.getText(_columnIndexOfIntro)
          }
          val _tmpCustomIntro: String?
          if (_stmt.isNull(_columnIndexOfCustomIntro)) {
            _tmpCustomIntro = null
          } else {
            _tmpCustomIntro = _stmt.getText(_columnIndexOfCustomIntro)
          }
          val _tmpCharset: String?
          if (_stmt.isNull(_columnIndexOfCharset)) {
            _tmpCharset = null
          } else {
            _tmpCharset = _stmt.getText(_columnIndexOfCharset)
          }
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpGroup: Long
          _tmpGroup = _stmt.getLong(_columnIndexOfGroup)
          val _tmpLatestChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfLatestChapterTitle)) {
            _tmpLatestChapterTitle = null
          } else {
            _tmpLatestChapterTitle = _stmt.getText(_columnIndexOfLatestChapterTitle)
          }
          val _tmpLatestChapterTime: Long
          _tmpLatestChapterTime = _stmt.getLong(_columnIndexOfLatestChapterTime)
          val _tmpLastCheckTime: Long
          _tmpLastCheckTime = _stmt.getLong(_columnIndexOfLastCheckTime)
          val _tmpLastCheckCount: Int
          _tmpLastCheckCount = _stmt.getLong(_columnIndexOfLastCheckCount).toInt()
          val _tmpTotalChapterNum: Int
          _tmpTotalChapterNum = _stmt.getLong(_columnIndexOfTotalChapterNum).toInt()
          val _tmpDurChapterTitle: String?
          if (_stmt.isNull(_columnIndexOfDurChapterTitle)) {
            _tmpDurChapterTitle = null
          } else {
            _tmpDurChapterTitle = _stmt.getText(_columnIndexOfDurChapterTitle)
          }
          val _tmpDurChapterIndex: Int
          _tmpDurChapterIndex = _stmt.getLong(_columnIndexOfDurChapterIndex).toInt()
          val _tmpDurChapterPos: Int
          _tmpDurChapterPos = _stmt.getLong(_columnIndexOfDurChapterPos).toInt()
          val _tmpDurChapterTime: Long
          _tmpDurChapterTime = _stmt.getLong(_columnIndexOfDurChapterTime)
          val _tmpWordCount: String?
          if (_stmt.isNull(_columnIndexOfWordCount)) {
            _tmpWordCount = null
          } else {
            _tmpWordCount = _stmt.getText(_columnIndexOfWordCount)
          }
          val _tmpCanUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfCanUpdate).toInt()
          _tmpCanUpdate = _tmp != 0
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpOriginOrder: Int
          _tmpOriginOrder = _stmt.getLong(_columnIndexOfOriginOrder).toInt()
          val _tmpVariable: String?
          if (_stmt.isNull(_columnIndexOfVariable)) {
            _tmpVariable = null
          } else {
            _tmpVariable = _stmt.getText(_columnIndexOfVariable)
          }
          val _tmpReadConfig: Book.ReadConfig?
          val _tmp_1: String?
          if (_stmt.isNull(_columnIndexOfReadConfig)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getText(_columnIndexOfReadConfig)
          }
          _tmpReadConfig = __converters.stringToReadConfig(_tmp_1)
          val _tmpSyncTime: Long
          _tmpSyncTime = _stmt.getLong(_columnIndexOfSyncTime)
          _result = Book(_tmpBookUrl,_tmpTocUrl,_tmpOrigin,_tmpOriginName,_tmpName,_tmpAuthor,_tmpKind,_tmpCustomTag,_tmpCoverUrl,_tmpCustomCoverUrl,_tmpIntro,_tmpCustomIntro,_tmpCharset,_tmpType,_tmpGroup,_tmpLatestChapterTitle,_tmpLatestChapterTime,_tmpLastCheckTime,_tmpLastCheckCount,_tmpTotalChapterNum,_tmpDurChapterTitle,_tmpDurChapterIndex,_tmpDurChapterPos,_tmpDurChapterTime,_tmpWordCount,_tmpCanUpdate,_tmpOrder,_tmpOriginOrder,_tmpVariable,_tmpReadConfig,_tmpSyncTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allBookUrlsWithName(): List<BookFolder> {
    val _sql: String = "SELECT name, bookUrl FROM books"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfName: Int = 0
        val _columnIndexOfBookUrl: Int = 1
        val _result: MutableList<BookFolder> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookFolder
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpBookUrl: String
          _tmpBookUrl = _stmt.getText(_columnIndexOfBookUrl)
          _item = BookFolder(_tmpName,_tmpBookUrl)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allBookCount(): Int {
    val _sql: String = "SELECT COUNT(*) FROM books"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun minOrder(): Int {
    val _sql: String = "select min(`order`) from books"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun has(bookUrl: String): Boolean {
    val _sql: String = "select exists(select 1 from books where bookUrl = ?)"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookUrl)
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun has(name: String, author: String): Boolean {
    val _sql: String = "select exists(select 1 from books where name = ? and author = ?)"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, name)
        _argIndex = 2
        _stmt.bindText(_argIndex, author)
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun hasFile(fileName: String): Boolean {
    val _sql: String = """
        |select exists(select 1 from books where type & 256 > 0 
        |        and (originName = ? or (origin != 'loc_book' and origin like '%' || ?)))
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, fileName)
        _argIndex = 2
        _stmt.bindText(_argIndex, fileName)
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upDurChapter(
    bookUrl: String,
    index: Int,
    pos: Int,
  ) {
    val _sql: String = "update books set durChapterIndex = ?, durChapterPos = ? where bookUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, index.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, pos.toLong())
        _argIndex = 3
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateProgress(
    bookUrl: String,
    durChapterIndex: Int,
    durChapterPos: Int,
    durChapterTime: Long,
    durChapterTitle: String?,
  ) {
    val _sql: String = """
        |update books set
        |            durChapterIndex = ?,
        |            durChapterPos = ?,
        |            durChapterTime = ?,
        |            durChapterTitle = ?,
        |            lastCheckCount = 0
        |            where bookUrl = ?
        """.trimMargin()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, durChapterIndex.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, durChapterPos.toLong())
        _argIndex = 3
        _stmt.bindLong(_argIndex, durChapterTime)
        _argIndex = 4
        if (durChapterTitle == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, durChapterTitle)
        }
        _argIndex = 5
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upSyncTime(bookUrl: String, syncTime: Long) {
    val _sql: String = "update books set syncTime = ? where bookUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, syncTime)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateReadConfig(bookUrl: String, readConfig: Book.ReadConfig?) {
    val _sql: String = "update books set readConfig = ? where bookUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: String? = __converters.readConfigToString(readConfig)
        if (_tmp == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, _tmp)
        }
        _argIndex = 2
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateLastCheckTime(
    bookUrl: String,
    lastCheckTime: Long,
    totalChapterNum: Int,
  ) {
    val _sql: String = "update books set lastCheckTime = ?, totalChapterNum = ? where bookUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, lastCheckTime)
        _argIndex = 2
        _stmt.bindLong(_argIndex, totalChapterNum.toLong())
        _argIndex = 3
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun updateTocInfo(
    bookUrl: String,
    totalChapterNum: Int,
    lastCheckTime: Long,
    lastCheckCount: Int,
    latestChapterTitle: String?,
    latestChapterTime: Long,
    durChapterTitle: String?,
  ) {
    val _sql: String = """
        |update books set
        |            totalChapterNum = ?,
        |            lastCheckTime = ?,
        |            lastCheckCount = ?,
        |            latestChapterTitle = ?,
        |            latestChapterTime = ?,
        |            durChapterTitle = ?
        |            where bookUrl = ?
        """.trimMargin()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, totalChapterNum.toLong())
        _argIndex = 2
        _stmt.bindLong(_argIndex, lastCheckTime)
        _argIndex = 3
        _stmt.bindLong(_argIndex, lastCheckCount.toLong())
        _argIndex = 4
        if (latestChapterTitle == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, latestChapterTitle)
        }
        _argIndex = 5
        _stmt.bindLong(_argIndex, latestChapterTime)
        _argIndex = 6
        if (durChapterTitle == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindText(_argIndex, durChapterTitle)
        }
        _argIndex = 7
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upOrder(bookUrl: String, order: Int) {
    val _sql: String = "update books set `order` = ? where bookUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, order.toLong())
        _argIndex = 2
        _stmt.bindText(_argIndex, bookUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun removeGroup(group: Long) {
    val _sql: String = "update books set `group` = `group` - ? where `group` & ? > 0"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, group)
        _argIndex = 2
        _stmt.bindLong(_argIndex, group)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteNotShelfBook() {
    val _sql: String = "delete from books where type & 1024 > 0"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
