package io.legado.app.data.dao

import androidx.room3.Dao
import androidx.room3.Delete
import androidx.room3.Insert
import androidx.room3.OnConflictStrategy
import androidx.room3.Query
import androidx.room3.Update
import io.legado.app.data.entities.HttpTTS
import kotlinx.coroutines.flow.Flow

@Dao
interface HttpTTSDao {

    @Query("select * from httpTTS order by name")
    suspend fun all(): List<HttpTTS>

    @Query("select * from httpTTS order by name")
    fun flowAll(): Flow<List<HttpTTS>>

    @Query("select count(*) from httpTTS")
    suspend fun count(): Int

    @Query("select * from httpTTS where id = :id")
    suspend fun get(id: Long): HttpTTS?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(vararg httpTTS: HttpTTS)

    @Delete
    suspend fun delete(vararg httpTTS: HttpTTS)

    @Query("delete from httpTTS where id < 0")
    suspend fun deleteDefault()
}
