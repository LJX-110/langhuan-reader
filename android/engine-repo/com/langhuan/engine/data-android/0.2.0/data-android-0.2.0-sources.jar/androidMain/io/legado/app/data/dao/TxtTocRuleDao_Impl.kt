package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.TxtTocRule
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class TxtTocRuleDao_Impl(
  __db: RoomDatabase,
) : TxtTocRuleDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfTxtTocRule: EntityInsertAdapter<TxtTocRule>

  private val __deleteAdapterOfTxtTocRule: EntityDeleteOrUpdateAdapter<TxtTocRule>

  private val __updateAdapterOfTxtTocRule: EntityDeleteOrUpdateAdapter<TxtTocRule>
  init {
    this.__db = __db
    this.__insertAdapterOfTxtTocRule = object : EntityInsertAdapter<TxtTocRule>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `txtTocRules` (`id`,`name`,`rule`,`example`,`serialNumber`,`enable`) VALUES (?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: TxtTocRule) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindText(3, entity.rule)
        val _tmpExample: String? = entity.example
        if (_tmpExample == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpExample)
        }
        statement.bindLong(5, entity.serialNumber.toLong())
        val _tmp: Int = if (entity.enable) 1 else 0
        statement.bindLong(6, _tmp.toLong())
      }
    }
    this.__deleteAdapterOfTxtTocRule = object : EntityDeleteOrUpdateAdapter<TxtTocRule>() {
      protected override fun createQuery(): String = "DELETE FROM `txtTocRules` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: TxtTocRule) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__updateAdapterOfTxtTocRule = object : EntityDeleteOrUpdateAdapter<TxtTocRule>() {
      protected override fun createQuery(): String = "UPDATE OR REPLACE `txtTocRules` SET `id` = ?,`name` = ?,`rule` = ?,`example` = ?,`serialNumber` = ?,`enable` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: TxtTocRule) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindText(3, entity.rule)
        val _tmpExample: String? = entity.example
        if (_tmpExample == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpExample)
        }
        statement.bindLong(5, entity.serialNumber.toLong())
        val _tmp: Int = if (entity.enable) 1 else 0
        statement.bindLong(6, _tmp.toLong())
        statement.bindLong(7, entity.id)
      }
    }
  }

  public override suspend fun insert(vararg rule: TxtTocRule): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfTxtTocRule.insert(_connection, rule)
  }

  public override suspend fun delete(vararg rule: TxtTocRule): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfTxtTocRule.handleMultiple(_connection, rule)
  }

  public override suspend fun update(vararg rule: TxtTocRule): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfTxtTocRule.handleMultiple(_connection, rule)
  }

  public override fun observeAll(): Flow<List<TxtTocRule>> {
    val _sql: String = "select * from txtTocRules order by serialNumber"
    return createFlow(__db, false, arrayOf("txtTocRules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfRule: Int = getColumnIndexOrThrow(_stmt, "rule")
        val _columnIndexOfExample: Int = getColumnIndexOrThrow(_stmt, "example")
        val _columnIndexOfSerialNumber: Int = getColumnIndexOrThrow(_stmt, "serialNumber")
        val _columnIndexOfEnable: Int = getColumnIndexOrThrow(_stmt, "enable")
        val _result: MutableList<TxtTocRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: TxtTocRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpRule: String
          _tmpRule = _stmt.getText(_columnIndexOfRule)
          val _tmpExample: String?
          if (_stmt.isNull(_columnIndexOfExample)) {
            _tmpExample = null
          } else {
            _tmpExample = _stmt.getText(_columnIndexOfExample)
          }
          val _tmpSerialNumber: Int
          _tmpSerialNumber = _stmt.getLong(_columnIndexOfSerialNumber).toInt()
          val _tmpEnable: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnable).toInt()
          _tmpEnable = _tmp != 0
          _item = TxtTocRule(_tmpId,_tmpName,_tmpRule,_tmpExample,_tmpSerialNumber,_tmpEnable)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(): List<TxtTocRule> {
    val _sql: String = "select * from txtTocRules order by serialNumber"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfRule: Int = getColumnIndexOrThrow(_stmt, "rule")
        val _columnIndexOfExample: Int = getColumnIndexOrThrow(_stmt, "example")
        val _columnIndexOfSerialNumber: Int = getColumnIndexOrThrow(_stmt, "serialNumber")
        val _columnIndexOfEnable: Int = getColumnIndexOrThrow(_stmt, "enable")
        val _result: MutableList<TxtTocRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: TxtTocRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpRule: String
          _tmpRule = _stmt.getText(_columnIndexOfRule)
          val _tmpExample: String?
          if (_stmt.isNull(_columnIndexOfExample)) {
            _tmpExample = null
          } else {
            _tmpExample = _stmt.getText(_columnIndexOfExample)
          }
          val _tmpSerialNumber: Int
          _tmpSerialNumber = _stmt.getLong(_columnIndexOfSerialNumber).toInt()
          val _tmpEnable: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnable).toInt()
          _tmpEnable = _tmp != 0
          _item = TxtTocRule(_tmpId,_tmpName,_tmpRule,_tmpExample,_tmpSerialNumber,_tmpEnable)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enabled(): List<TxtTocRule> {
    val _sql: String = "select * from txtTocRules where enable = 1 order by serialNumber"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfRule: Int = getColumnIndexOrThrow(_stmt, "rule")
        val _columnIndexOfExample: Int = getColumnIndexOrThrow(_stmt, "example")
        val _columnIndexOfSerialNumber: Int = getColumnIndexOrThrow(_stmt, "serialNumber")
        val _columnIndexOfEnable: Int = getColumnIndexOrThrow(_stmt, "enable")
        val _result: MutableList<TxtTocRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: TxtTocRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpRule: String
          _tmpRule = _stmt.getText(_columnIndexOfRule)
          val _tmpExample: String?
          if (_stmt.isNull(_columnIndexOfExample)) {
            _tmpExample = null
          } else {
            _tmpExample = _stmt.getText(_columnIndexOfExample)
          }
          val _tmpSerialNumber: Int
          _tmpSerialNumber = _stmt.getLong(_columnIndexOfSerialNumber).toInt()
          val _tmpEnable: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnable).toInt()
          _tmpEnable = _tmp != 0
          _item = TxtTocRule(_tmpId,_tmpName,_tmpRule,_tmpExample,_tmpSerialNumber,_tmpEnable)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun count(): Int {
    val _sql: String = "select count(*) from txtTocRules"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun `get`(id: Long): TxtTocRule? {
    val _sql: String = "select * from txtTocRules where id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfRule: Int = getColumnIndexOrThrow(_stmt, "rule")
        val _columnIndexOfExample: Int = getColumnIndexOrThrow(_stmt, "example")
        val _columnIndexOfSerialNumber: Int = getColumnIndexOrThrow(_stmt, "serialNumber")
        val _columnIndexOfEnable: Int = getColumnIndexOrThrow(_stmt, "enable")
        val _result: TxtTocRule?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpRule: String
          _tmpRule = _stmt.getText(_columnIndexOfRule)
          val _tmpExample: String?
          if (_stmt.isNull(_columnIndexOfExample)) {
            _tmpExample = null
          } else {
            _tmpExample = _stmt.getText(_columnIndexOfExample)
          }
          val _tmpSerialNumber: Int
          _tmpSerialNumber = _stmt.getLong(_columnIndexOfSerialNumber).toInt()
          val _tmpEnable: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnable).toInt()
          _tmpEnable = _tmp != 0
          _result = TxtTocRule(_tmpId,_tmpName,_tmpRule,_tmpExample,_tmpSerialNumber,_tmpEnable)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun minOrder(): Int {
    val _sql: String = "select ifNull(min(serialNumber), 0) from txtTocRules"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxOrder(): Int {
    val _sql: String = "select ifNull(max(serialNumber), 0) from txtTocRules"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteDefault() {
    val _sql: String = "delete from txtTocRules where id < 0"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
