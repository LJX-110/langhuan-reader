package io.legado.app.`data`.dao

import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.ReadRecord
import javax.`annotation`.processing.Generated
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class ReadRecordDao_Impl(
  __db: RoomDatabase,
) : ReadRecordDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfReadRecord: EntityInsertAdapter<ReadRecord>
  init {
    this.__db = __db
    this.__insertAdapterOfReadRecord = object : EntityInsertAdapter<ReadRecord>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `readRecord` (`bookName`,`day`,`startSec`,`endSec`) VALUES (?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ReadRecord) {
        statement.bindText(1, entity.bookName)
        statement.bindLong(2, entity.day.toLong())
        statement.bindLong(3, entity.startSec)
        statement.bindLong(4, entity.endSec)
      }
    }
  }

  public override suspend fun insert(vararg record: ReadRecord): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfReadRecord.insert(_connection, record)
  }

  public override suspend fun all(): List<ReadRecord> {
    val _sql: String = "select * from readRecord"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookName: Int = getColumnIndexOrThrow(_stmt, "bookName")
        val _columnIndexOfDay: Int = getColumnIndexOrThrow(_stmt, "day")
        val _columnIndexOfStartSec: Int = getColumnIndexOrThrow(_stmt, "startSec")
        val _columnIndexOfEndSec: Int = getColumnIndexOrThrow(_stmt, "endSec")
        val _result: MutableList<ReadRecord> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReadRecord
          val _tmpBookName: String
          _tmpBookName = _stmt.getText(_columnIndexOfBookName)
          val _tmpDay: Int
          _tmpDay = _stmt.getLong(_columnIndexOfDay).toInt()
          val _tmpStartSec: Long
          _tmpStartSec = _stmt.getLong(_columnIndexOfStartSec)
          val _tmpEndSec: Long
          _tmpEndSec = _stmt.getLong(_columnIndexOfEndSec)
          _item = ReadRecord(_tmpBookName,_tmpDay,_tmpStartSec,_tmpEndSec)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun clear() {
    val _sql: String = "delete from readRecord"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteByName(bookName: String) {
    val _sql: String = "delete from readRecord where bookName = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookName)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteByDay(day: Int) {
    val _sql: String = "delete from readRecord where day = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, day.toLong())
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
