package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.SourceFilterRule
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class SourceFilterRuleDao_Impl(
  __db: RoomDatabase,
) : SourceFilterRuleDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfSourceFilterRule: EntityInsertAdapter<SourceFilterRule>

  private val __deleteAdapterOfSourceFilterRule: EntityDeleteOrUpdateAdapter<SourceFilterRule>

  private val __updateAdapterOfSourceFilterRule: EntityDeleteOrUpdateAdapter<SourceFilterRule>
  init {
    this.__db = __db
    this.__insertAdapterOfSourceFilterRule = object : EntityInsertAdapter<SourceFilterRule>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `source_filter_rules` (`id`,`name`,`enabled`,`pattern`,`fields`,`scope`,`sortOrder`,`createTime`) VALUES (?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: SourceFilterRule) {
        statement.bindText(1, entity.id)
        statement.bindText(2, entity.name)
        val _tmp: Int = if (entity.enabled) 1 else 0
        statement.bindLong(3, _tmp.toLong())
        statement.bindText(4, entity.pattern)
        statement.bindText(5, entity.fields)
        statement.bindText(6, entity.scope)
        statement.bindLong(7, entity.order.toLong())
        statement.bindLong(8, entity.createTime)
      }
    }
    this.__deleteAdapterOfSourceFilterRule = object : EntityDeleteOrUpdateAdapter<SourceFilterRule>() {
      protected override fun createQuery(): String = "DELETE FROM `source_filter_rules` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: SourceFilterRule) {
        statement.bindText(1, entity.id)
      }
    }
    this.__updateAdapterOfSourceFilterRule = object : EntityDeleteOrUpdateAdapter<SourceFilterRule>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `source_filter_rules` SET `id` = ?,`name` = ?,`enabled` = ?,`pattern` = ?,`fields` = ?,`scope` = ?,`sortOrder` = ?,`createTime` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: SourceFilterRule) {
        statement.bindText(1, entity.id)
        statement.bindText(2, entity.name)
        val _tmp: Int = if (entity.enabled) 1 else 0
        statement.bindLong(3, _tmp.toLong())
        statement.bindText(4, entity.pattern)
        statement.bindText(5, entity.fields)
        statement.bindText(6, entity.scope)
        statement.bindLong(7, entity.order.toLong())
        statement.bindLong(8, entity.createTime)
        statement.bindText(9, entity.id)
      }
    }
  }

  public override suspend fun insert(vararg rules: SourceFilterRule): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfSourceFilterRule.insert(_connection, rules)
  }

  public override suspend fun delete(vararg rules: SourceFilterRule): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfSourceFilterRule.handleMultiple(_connection, rules)
  }

  public override suspend fun update(vararg rules: SourceFilterRule): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfSourceFilterRule.handleMultiple(_connection, rules)
  }

  public override suspend fun all(): List<SourceFilterRule> {
    val _sql: String = "SELECT * FROM source_filter_rules ORDER BY sortOrder, createTime"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfFields: Int = getColumnIndexOrThrow(_stmt, "fields")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCreateTime: Int = getColumnIndexOrThrow(_stmt, "createTime")
        val _result: MutableList<SourceFilterRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: SourceFilterRule
          val _tmpId: String
          _tmpId = _stmt.getText(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpFields: String
          _tmpFields = _stmt.getText(_columnIndexOfFields)
          val _tmpScope: String
          _tmpScope = _stmt.getText(_columnIndexOfScope)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpCreateTime: Long
          _tmpCreateTime = _stmt.getLong(_columnIndexOfCreateTime)
          _item = SourceFilterRule(_tmpId,_tmpName,_tmpEnabled,_tmpPattern,_tmpFields,_tmpScope,_tmpOrder,_tmpCreateTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enabled(): List<SourceFilterRule> {
    val _sql: String = "SELECT * FROM source_filter_rules WHERE enabled = 1 ORDER BY sortOrder, createTime"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfFields: Int = getColumnIndexOrThrow(_stmt, "fields")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCreateTime: Int = getColumnIndexOrThrow(_stmt, "createTime")
        val _result: MutableList<SourceFilterRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: SourceFilterRule
          val _tmpId: String
          _tmpId = _stmt.getText(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpFields: String
          _tmpFields = _stmt.getText(_columnIndexOfFields)
          val _tmpScope: String
          _tmpScope = _stmt.getText(_columnIndexOfScope)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpCreateTime: Long
          _tmpCreateTime = _stmt.getLong(_columnIndexOfCreateTime)
          _item = SourceFilterRule(_tmpId,_tmpName,_tmpEnabled,_tmpPattern,_tmpFields,_tmpScope,_tmpOrder,_tmpCreateTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<SourceFilterRule>> {
    val _sql: String = "SELECT * FROM source_filter_rules ORDER BY sortOrder, createTime"
    return createFlow(__db, false, arrayOf("source_filter_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfFields: Int = getColumnIndexOrThrow(_stmt, "fields")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCreateTime: Int = getColumnIndexOrThrow(_stmt, "createTime")
        val _result: MutableList<SourceFilterRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: SourceFilterRule
          val _tmpId: String
          _tmpId = _stmt.getText(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpFields: String
          _tmpFields = _stmt.getText(_columnIndexOfFields)
          val _tmpScope: String
          _tmpScope = _stmt.getText(_columnIndexOfScope)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpCreateTime: Long
          _tmpCreateTime = _stmt.getLong(_columnIndexOfCreateTime)
          _item = SourceFilterRule(_tmpId,_tmpName,_tmpEnabled,_tmpPattern,_tmpFields,_tmpScope,_tmpOrder,_tmpCreateTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowSearch(key: String): Flow<List<SourceFilterRule>> {
    val _sql: String = "SELECT * FROM source_filter_rules WHERE name LIKE ? OR pattern LIKE ? ORDER BY sortOrder, createTime"
    return createFlow(__db, false, arrayOf("source_filter_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _argIndex = 2
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfFields: Int = getColumnIndexOrThrow(_stmt, "fields")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCreateTime: Int = getColumnIndexOrThrow(_stmt, "createTime")
        val _result: MutableList<SourceFilterRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: SourceFilterRule
          val _tmpId: String
          _tmpId = _stmt.getText(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpFields: String
          _tmpFields = _stmt.getText(_columnIndexOfFields)
          val _tmpScope: String
          _tmpScope = _stmt.getText(_columnIndexOfScope)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpCreateTime: Long
          _tmpCreateTime = _stmt.getLong(_columnIndexOfCreateTime)
          _item = SourceFilterRule(_tmpId,_tmpName,_tmpEnabled,_tmpPattern,_tmpFields,_tmpScope,_tmpOrder,_tmpCreateTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun minOrder(): Int {
    val _sql: String = "SELECT IFNULL(MIN(sortOrder), 0) FROM source_filter_rules"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxOrder(): Int {
    val _sql: String = "SELECT IFNULL(MAX(sortOrder), 0) FROM source_filter_rules"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findById(id: String): SourceFilterRule? {
    val _sql: String = "SELECT * FROM source_filter_rules WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfFields: Int = getColumnIndexOrThrow(_stmt, "fields")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _columnIndexOfCreateTime: Int = getColumnIndexOrThrow(_stmt, "createTime")
        val _result: SourceFilterRule?
        if (_stmt.step()) {
          val _tmpId: String
          _tmpId = _stmt.getText(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpFields: String
          _tmpFields = _stmt.getText(_columnIndexOfFields)
          val _tmpScope: String
          _tmpScope = _stmt.getText(_columnIndexOfScope)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpCreateTime: Long
          _tmpCreateTime = _stmt.getLong(_columnIndexOfCreateTime)
          _result = SourceFilterRule(_tmpId,_tmpName,_tmpEnabled,_tmpPattern,_tmpFields,_tmpScope,_tmpOrder,_tmpCreateTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteAll() {
    val _sql: String = "DELETE FROM source_filter_rules"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
