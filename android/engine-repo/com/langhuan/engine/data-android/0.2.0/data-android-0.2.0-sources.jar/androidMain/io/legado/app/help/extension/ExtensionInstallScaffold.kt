package io.legado.app.help.extension

import io.legado.app.constant.AppLog
import io.legado.app.exception.NoStackTraceException
import io.legado.app.help.coroutine.IoDispatcher
import io.legado.app.help.extension.model.InstallStep
import io.legado.app.help.extension.model.MangaExtension
import io.legado.app.help.http.okHttpClient
import io.legado.app.utils.randomUUIDString
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import okhttp3.Request
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * 扩展安装包元信息。两端读取途径不同 (Android = PackageManager 查询; 桌面 = AXML 解析 +
 * apksig 校验), 但校验判据相同, 故先归一到本结构再进 [checkExtensionInstallable]。
 */
data class ExtensionApkInfo(
    val pkgName: String,
    val versionCode: Long,
    val isExtension: Boolean,
    /** 签名证书 SHA-256 小写 hex; 无签名或提取失败为空表。 */
    val signatures: List<String>,
)

/**
 * 覆盖安装校验 (两端单一事实来源): 必须是扩展包 / 不允许降级 / 新包必须已签名 /
 * 已装包签名必须可读且被新包完全覆盖 —— 已装包签名读取失败即拒绝, 不做空集放行。
 */
fun checkExtensionInstallable(incoming: ExtensionApkInfo, current: ExtensionApkInfo?) {
    check(incoming.isExtension) { "${incoming.pkgName} 不是扩展" }
    if (current == null) return
    check(incoming.versionCode >= current.versionCode) { "不允许降级安装" }
    check(incoming.signatures.isNotEmpty()) { "扩展未签名" }
    check(current.signatures.isNotEmpty() && incoming.signatures.containsAll(current.signatures)) {
        "与已安装扩展签名不一致"
    }
}

/** Android 包名契约: 至少两段, 每段字母开头, 仅字母/数字/下划线。 */
private val EXTENSION_PACKAGE_NAME = Regex("""[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+""")

fun isValidExtensionPackageName(pkgName: String): Boolean = EXTENSION_PACKAGE_NAME.matches(pkgName)

/**
 * 校验扩展包名。包名来自 apk manifest 或仓库索引, 直接参与扩展文件与 dex2jar 产物路径拼接,
 * 含路径分隔符或 `..` 的包名可把文件写到扩展目录之外, 故拼接前必须先过白名单 (两端共用本处)。
 */
fun requireValidExtensionPackageName(pkgName: String): String {
    if (!isValidExtensionPackageName(pkgName)) {
        throw NoStackTraceException("非法扩展包名: $pkgName")
    }
    return pkgName
}

/**
 * 版本名并入产物文件名前的净化: 非 [A-Za-z0-9._-] 字符替换为 '_'。版本名来自 apk manifest,
 * 无格式约束, 可含路径分隔与上跳序列。
 */
fun safeExtensionFileNameSegment(raw: String): String =
    raw.map { if (it.isLetterOrDigit() || it == '.' || it == '_' || it == '-') it else '_' }
        .joinToString("")

/**
 * 下载扩展 apk 到 [target] (进度按 1% 粒度回调); 失败抛异常, 由调用方收敛成安装错误。
 */
suspend fun downloadExtensionApk(url: String, target: File, onProgress: suspend (Int) -> Unit) {
    val request = Request.Builder().url(url).build()
    okHttpClient.newCall(request).execute().use { response ->
        if (!response.isSuccessful) {
            throw NoStackTraceException("下载失败 HTTP ${response.code}: $url")
        }
        val body = response.body
        val total = body.contentLength()
        body.byteStream().use { input ->
            target.outputStream().use { output ->
                val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
                var lastProgress = -1
                var written = 0L
                while (true) {
                    val read = input.read(buffer)
                    if (read == -1) break
                    output.write(buffer, 0, read)
                    written += read
                    if (total > 0) {
                        val progress = ((written * 100) / total).toInt()
                        if (progress != lastProgress) {
                            lastProgress = progress
                            onProgress(progress)
                        }
                    }
                }
            }
        }
    }
}

/**
 * 扩展安装脚手架 (JVM+Android 共用): 下载 apk 到临时文件 → 覆盖校验 → 平台落盘 → 触发重扫。
 * 下载/进度/取消/失败收敛与覆盖校验只有这一份实现 (两端各自实现曾导致签名严格度漂移);
 * 平台差异收敛在 [extensionDir]/[readApkInfo]/[readInstalledInfo]/[placeApk]/[onInstalled]。
 */
abstract class ExtensionInstallScaffold {

    private val installJobs = ConcurrentHashMap<String, Job>()

    /**
     * 扩展文件所在目录。落盘目标与下载临时件都在这棵目录下: 原子替换靠同卷改名, 临时件与目标
     * 必须同卷, 跨卷只剩整份复制一条路。
     */
    protected abstract fun extensionDir(): File

    /** 读取安装包元信息; 无法解析返回 null。 */
    protected abstract fun readApkInfo(file: File): ExtensionApkInfo?

    /** 读取已安装的同包扩展元信息; 未安装返回 null。 */
    protected abstract fun readInstalledInfo(pkgName: String): ExtensionApkInfo?

    /**
     * 校验通过后落盘; [replaced] 为 true 表示覆盖已有同包扩展。
     *
     * 覆盖必须原子替换 ([io.legado.app.utils.FileUtilsBase.replaceFileAtomically] 是这条机制的
     * 共享实现): 旧文件在新文件整份就位后才消失, 任一步失败旧扩展原样可用, 异常由 [install]
     * 收敛成 [InstallStep.Error]。
     */
    protected abstract fun placeApk(file: File, info: ExtensionApkInfo, replaced: Boolean)

    /** 落盘后触发重扫; 走安装广播的端无需覆写。 */
    protected open fun onInstalled(pkgName: String) {}

    /** 下载并安装; 同一扩展再次发起安装时取消进行中的任务, 收集方取消即中止。 */
    fun install(extension: MangaExtension.Available): Flow<InstallStep> {
        installJobs[extension.pkgName]?.cancel()
        return flow {
            val job = currentCoroutineContext()[Job] ?: error("安装流程必须在协程中收集")
            installJobs[extension.pkgName] = job
            var apkFile: File? = null
            try {
                requireValidExtensionPackageName(extension.pkgName)
                emit(InstallStep.Downloading)
                // 临时件名每次安装唯一, 本次安装覆盖不掉上次被强杀留下的那份, 只能在这里清
                discardInstallTemps(extensionDir(), extension.pkgName)
                val target = newInstallTempFile(extension.pkgName)
                apkFile = target
                downloadExtensionApk(extension.apkUrl, target) { emit(InstallStep.Progress(it)) }
                currentCoroutineContext().ensureActive()

                emit(InstallStep.Installing)
                val info = readApkInfo(target)
                    ?: throw NoStackTraceException("安装包无法解析: ${extension.pkgName}")
                val current = readInstalledInfo(info.pkgName)
                checkExtensionInstallable(info, current)
                placeApk(target, info, replaced = current != null)
                emit(InstallStep.Installed)
                onInstalled(info.pkgName)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // 界面只把安装状态拨回可重试, 失败原因只能从这里查
                AppLog.put("扩展安装失败: ${extension.pkgName}", e)
                emit(InstallStep.Error(e.message))
            } finally {
                installJobs.remove(extension.pkgName, job)
                apkFile?.delete()
                // 同包并发安装的另一份还在写时目录非空, 这次删除不生效, 也不影响那一份
                apkFile?.parentFile?.delete()
            }
        }.flowOn(IoDispatcher)
    }

    fun cancelInstall(pkgName: String) {
        installJobs[pkgName]?.cancel()
    }

    /**
     * 本次安装的下载临时件 (流程结束必删)。
     *
     * 唯一串取随机 UUID ([randomUUIDString]): 时间戳在同毫秒的两次安装上会重名, 纳秒跨进程不保证
     * 互异, 而这里要的是两次安装绝不共用同一条路径 —— 取消是协作式的, 上一次安装可能还停在这份
     * 文件上写着, 共用路径会互相截断, 把半截包交给落盘环节。
     */
    private fun newInstallTempFile(pkgName: String): File {
        val dir = installTempDirOf(extensionDir(), pkgName)
        dir.mkdirs()
        return File(dir, randomUUIDString() + INSTALL_TEMP_SUFFIX)
    }

    companion object {

        /** 安装临时件目录名 (在扩展文件目录内): 一个包一个目录, 一次安装一个临时件。 */
        private const val INSTALL_TEMP_DIR_NAME = "install-tmp"

        /**
         * 安装临时件后缀。临时件是整份 apk 内容, 落在扩展文件目录的子目录里: 扩展扫描只取扩展
         * 文件目录的直接文件, 临时件不会被当成已装扩展。
         */
        private const val INSTALL_TEMP_SUFFIX = ".apk"

        /**
         * 清掉 [extensionDir] 下 [pkgName] 的安装临时件: 卸载时清本包全部, 安装开始前清上次被强杀
         * 留下的。只按包名目录定位, 不碰其他包。
         */
        fun discardInstallTemps(extensionDir: File, pkgName: String) {
            installTempDirOf(extensionDir, pkgName).deleteRecursively()
            // 根目录空了就一并收掉 (还有别的包在装时删除不生效)
            installTempRootOf(extensionDir).delete()
        }

        private fun installTempRootOf(extensionDir: File): File =
            File(extensionDir, INSTALL_TEMP_DIR_NAME)

        private fun installTempDirOf(extensionDir: File, pkgName: String): File =
            File(installTempRootOf(extensionDir), pkgName)
    }
}
