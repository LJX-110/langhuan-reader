package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.RuleSub
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class RuleSubDao_Impl(
  __db: RoomDatabase,
) : RuleSubDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfRuleSub: EntityInsertAdapter<RuleSub>

  private val __deleteAdapterOfRuleSub: EntityDeleteOrUpdateAdapter<RuleSub>

  private val __updateAdapterOfRuleSub: EntityDeleteOrUpdateAdapter<RuleSub>
  init {
    this.__db = __db
    this.__insertAdapterOfRuleSub = object : EntityInsertAdapter<RuleSub>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `ruleSubs` (`id`,`name`,`url`,`type`,`customOrder`,`autoUpdate`,`update`) VALUES (?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: RuleSub) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindText(3, entity.url)
        statement.bindLong(4, entity.type.toLong())
        statement.bindLong(5, entity.customOrder.toLong())
        val _tmp: Int = if (entity.autoUpdate) 1 else 0
        statement.bindLong(6, _tmp.toLong())
        statement.bindLong(7, entity.update)
      }
    }
    this.__deleteAdapterOfRuleSub = object : EntityDeleteOrUpdateAdapter<RuleSub>() {
      protected override fun createQuery(): String = "DELETE FROM `ruleSubs` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: RuleSub) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__updateAdapterOfRuleSub = object : EntityDeleteOrUpdateAdapter<RuleSub>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `ruleSubs` SET `id` = ?,`name` = ?,`url` = ?,`type` = ?,`customOrder` = ?,`autoUpdate` = ?,`update` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: RuleSub) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindText(3, entity.url)
        statement.bindLong(4, entity.type.toLong())
        statement.bindLong(5, entity.customOrder.toLong())
        val _tmp: Int = if (entity.autoUpdate) 1 else 0
        statement.bindLong(6, _tmp.toLong())
        statement.bindLong(7, entity.update)
        statement.bindLong(8, entity.id)
      }
    }
  }

  public override suspend fun insert(vararg ruleSub: RuleSub): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfRuleSub.insert(_connection, ruleSub)
  }

  public override suspend fun delete(vararg ruleSub: RuleSub): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfRuleSub.handleMultiple(_connection, ruleSub)
  }

  public override suspend fun update(vararg ruleSub: RuleSub): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfRuleSub.handleMultiple(_connection, ruleSub)
  }

  public override suspend fun all(): List<RuleSub> {
    val _sql: String = "select * from ruleSubs order by customOrder"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfAutoUpdate: Int = getColumnIndexOrThrow(_stmt, "autoUpdate")
        val _columnIndexOfUpdate: Int = getColumnIndexOrThrow(_stmt, "update")
        val _result: MutableList<RuleSub> = mutableListOf()
        while (_stmt.step()) {
          val _item: RuleSub
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpAutoUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfAutoUpdate).toInt()
          _tmpAutoUpdate = _tmp != 0
          val _tmpUpdate: Long
          _tmpUpdate = _stmt.getLong(_columnIndexOfUpdate)
          _item = RuleSub(_tmpId,_tmpName,_tmpUrl,_tmpType,_tmpCustomOrder,_tmpAutoUpdate,_tmpUpdate)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<RuleSub>> {
    val _sql: String = "select * from ruleSubs order by customOrder"
    return createFlow(__db, false, arrayOf("ruleSubs")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfAutoUpdate: Int = getColumnIndexOrThrow(_stmt, "autoUpdate")
        val _columnIndexOfUpdate: Int = getColumnIndexOrThrow(_stmt, "update")
        val _result: MutableList<RuleSub> = mutableListOf()
        while (_stmt.step()) {
          val _item: RuleSub
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpType: Int
          _tmpType = _stmt.getLong(_columnIndexOfType).toInt()
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpAutoUpdate: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfAutoUpdate).toInt()
          _tmpAutoUpdate = _tmp != 0
          val _tmpUpdate: Long
          _tmpUpdate = _stmt.getLong(_columnIndexOfUpdate)
          _item = RuleSub(_tmpId,_tmpName,_tmpUrl,_tmpType,_tmpCustomOrder,_tmpAutoUpdate,_tmpUpdate)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
