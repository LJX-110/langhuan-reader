package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.Server
import javax.`annotation`.processing.Generated
import kotlin.IllegalArgumentException
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class ServerDao_Impl(
  __db: RoomDatabase,
) : ServerDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfServer: EntityInsertAdapter<Server>

  private val __deleteAdapterOfServer: EntityDeleteOrUpdateAdapter<Server>
  init {
    this.__db = __db
    this.__insertAdapterOfServer = object : EntityInsertAdapter<Server>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `servers` (`id`,`name`,`type`,`config`,`sortNumber`) VALUES (?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: Server) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindText(3, __TYPE_enumToString(entity.type))
        val _tmpConfig: String? = entity.config
        if (_tmpConfig == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpConfig)
        }
        statement.bindLong(5, entity.sortNumber.toLong())
      }
    }
    this.__deleteAdapterOfServer = object : EntityDeleteOrUpdateAdapter<Server>() {
      protected override fun createQuery(): String = "DELETE FROM `servers` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: Server) {
        statement.bindLong(1, entity.id)
      }
    }
  }

  public override suspend fun insert(vararg server: Server): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfServer.insert(_connection, server)
  }

  public override suspend fun delete(vararg server: Server): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfServer.handleMultiple(_connection, server)
  }

  public override fun observeAll(): Flow<List<Server>> {
    val _sql: String = "select * from servers order by sortNumber"
    return createFlow(__db, false, arrayOf("servers")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfConfig: Int = getColumnIndexOrThrow(_stmt, "config")
        val _columnIndexOfSortNumber: Int = getColumnIndexOrThrow(_stmt, "sortNumber")
        val _result: MutableList<Server> = mutableListOf()
        while (_stmt.step()) {
          val _item: Server
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpType: Server.TYPE
          _tmpType = __TYPE_stringToEnum(_stmt.getText(_columnIndexOfType))
          val _tmpConfig: String?
          if (_stmt.isNull(_columnIndexOfConfig)) {
            _tmpConfig = null
          } else {
            _tmpConfig = _stmt.getText(_columnIndexOfConfig)
          }
          val _tmpSortNumber: Int
          _tmpSortNumber = _stmt.getLong(_columnIndexOfSortNumber).toInt()
          _item = Server(_tmpId,_tmpName,_tmpType,_tmpConfig,_tmpSortNumber)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(): List<Server> {
    val _sql: String = "select * from servers order by sortNumber"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfConfig: Int = getColumnIndexOrThrow(_stmt, "config")
        val _columnIndexOfSortNumber: Int = getColumnIndexOrThrow(_stmt, "sortNumber")
        val _result: MutableList<Server> = mutableListOf()
        while (_stmt.step()) {
          val _item: Server
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpType: Server.TYPE
          _tmpType = __TYPE_stringToEnum(_stmt.getText(_columnIndexOfType))
          val _tmpConfig: String?
          if (_stmt.isNull(_columnIndexOfConfig)) {
            _tmpConfig = null
          } else {
            _tmpConfig = _stmt.getText(_columnIndexOfConfig)
          }
          val _tmpSortNumber: Int
          _tmpSortNumber = _stmt.getLong(_columnIndexOfSortNumber).toInt()
          _item = Server(_tmpId,_tmpName,_tmpType,_tmpConfig,_tmpSortNumber)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun `get`(id: Long): Server? {
    val _sql: String = "select * from servers where id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfType: Int = getColumnIndexOrThrow(_stmt, "type")
        val _columnIndexOfConfig: Int = getColumnIndexOrThrow(_stmt, "config")
        val _columnIndexOfSortNumber: Int = getColumnIndexOrThrow(_stmt, "sortNumber")
        val _result: Server?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpType: Server.TYPE
          _tmpType = __TYPE_stringToEnum(_stmt.getText(_columnIndexOfType))
          val _tmpConfig: String?
          if (_stmt.isNull(_columnIndexOfConfig)) {
            _tmpConfig = null
          } else {
            _tmpConfig = _stmt.getText(_columnIndexOfConfig)
          }
          val _tmpSortNumber: Int
          _tmpSortNumber = _stmt.getLong(_columnIndexOfSortNumber).toInt()
          _result = Server(_tmpId,_tmpName,_tmpType,_tmpConfig,_tmpSortNumber)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  private fun __TYPE_enumToString(_value: Server.TYPE): String = when (_value) {
    Server.TYPE.WEBDAV -> "WEBDAV"
  }

  private fun __TYPE_stringToEnum(_value: String): Server.TYPE = when (_value) {
    "WEBDAV" -> Server.TYPE.WEBDAV
    else -> throw IllegalArgumentException("Can't convert value to enum, unknown value: " + _value)
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
