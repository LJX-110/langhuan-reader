package io.legado.app.`data`

import androidx.room3.migration.Migration
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.execSQL
import javax.`annotation`.processing.Generated
import kotlin.Suppress

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class AppDatabase_AutoMigration_88_89_Impl : Migration {
  public constructor() : super(88, 89)

  public override suspend fun migrate(connection: SQLiteConnection) {
    connection.execSQL("DROP VIEW book_sources_part")
    connection.execSQL("ALTER TABLE `book_sources` ADD COLUMN `bookSourceIcon` TEXT DEFAULT NULL")
    connection.execSQL("""
        |CREATE VIEW `book_sources_part` AS select bookSourceUrl, bookSourceName, bookSourceGroup, customOrder, enabled, enabledExplore,
        |    (ifnull(trim(loginUrl), '') <> '' or ifnull(trim(loginUi), '') <> '') hasLoginUrl, lastUpdateTime, respondTime, weight,
        |    (ifnull(trim(exploreUrl), '') <> '') hasExploreUrl, bookSourceIcon
        |    from book_sources
        """.trimMargin())
  }
}
