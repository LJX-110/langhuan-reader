package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.appendPlaceholders
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performInTransactionSuspending
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.BookSource
import io.legado.app.`data`.entities.BookSourcePart
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlin.text.StringBuilder
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class BookSourceDao_Impl(
  __db: RoomDatabase,
) : BookSourceDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfBookSource: EntityInsertAdapter<BookSource>

  private val __deleteAdapterOfBookSource: EntityDeleteOrUpdateAdapter<BookSource>

  private val __updateAdapterOfBookSource: EntityDeleteOrUpdateAdapter<BookSource>
  init {
    this.__db = __db
    this.__insertAdapterOfBookSource = object : EntityInsertAdapter<BookSource>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `book_sources` (`bookSourceUrl`,`bookSourceName`,`bookSourceGroup`,`bookSourceType`,`bookUrlPattern`,`customOrder`,`enabled`,`enabledExplore`,`enabledReview`,`jsLib`,`enabledCookieJar`,`enableDangerousApi`,`concurrentRate`,`header`,`loginUrl`,`loginUi`,`loginCheckJs`,`coverDecodeJs`,`bookSourceComment`,`bookSourceIcon`,`variableComment`,`lastUpdateTime`,`respondTime`,`weight`,`exploreUrl`,`exploreScreen`,`exploreStyle`,`ruleExplore`,`searchUrl`,`ruleSearch`,`ruleBookInfo`,`ruleToc`,`ruleContent`,`ruleReview`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: BookSource) {
        statement.bindText(1, entity.bookSourceUrl)
        statement.bindText(2, entity.bookSourceName)
        val _tmpBookSourceGroup: String? = entity.bookSourceGroup
        if (_tmpBookSourceGroup == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpBookSourceGroup)
        }
        statement.bindLong(4, entity.bookSourceType.toLong())
        val _tmpBookUrlPattern: String? = entity.bookUrlPattern
        if (_tmpBookUrlPattern == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpBookUrlPattern)
        }
        statement.bindLong(6, entity.customOrder.toLong())
        val _tmp: Int = if (entity.enabled) 1 else 0
        statement.bindLong(7, _tmp.toLong())
        val _tmp_1: Int = if (entity.enabledExplore) 1 else 0
        statement.bindLong(8, _tmp_1.toLong())
        val _tmp_2: Int = if (entity.enabledReview) 1 else 0
        statement.bindLong(9, _tmp_2.toLong())
        val _tmpJsLib: String? = entity.jsLib
        if (_tmpJsLib == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpJsLib)
        }
        val _tmpEnabledCookieJar: Boolean? = entity.enabledCookieJar
        val _tmp_3: Int? = _tmpEnabledCookieJar?.let { if (it) 1 else 0 }
        if (_tmp_3 == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmp_3.toLong())
        }
        val _tmpEnableDangerousApi: Boolean? = entity.enableDangerousApi
        val _tmp_4: Int? = _tmpEnableDangerousApi?.let { if (it) 1 else 0 }
        if (_tmp_4 == null) {
          statement.bindNull(12)
        } else {
          statement.bindLong(12, _tmp_4.toLong())
        }
        val _tmpConcurrentRate: String? = entity.concurrentRate
        if (_tmpConcurrentRate == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpConcurrentRate)
        }
        val _tmpHeader: String? = entity.header
        if (_tmpHeader == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpHeader)
        }
        val _tmpLoginUrl: String? = entity.loginUrl
        if (_tmpLoginUrl == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpLoginUrl)
        }
        val _tmpLoginUi: String? = entity.loginUi
        if (_tmpLoginUi == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpLoginUi)
        }
        val _tmpLoginCheckJs: String? = entity.loginCheckJs
        if (_tmpLoginCheckJs == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpLoginCheckJs)
        }
        val _tmpCoverDecodeJs: String? = entity.coverDecodeJs
        if (_tmpCoverDecodeJs == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpCoverDecodeJs)
        }
        val _tmpBookSourceComment: String? = entity.bookSourceComment
        if (_tmpBookSourceComment == null) {
          statement.bindNull(19)
        } else {
          statement.bindText(19, _tmpBookSourceComment)
        }
        val _tmpBookSourceIcon: String? = entity.bookSourceIcon
        if (_tmpBookSourceIcon == null) {
          statement.bindNull(20)
        } else {
          statement.bindText(20, _tmpBookSourceIcon)
        }
        val _tmpVariableComment: String? = entity.variableComment
        if (_tmpVariableComment == null) {
          statement.bindNull(21)
        } else {
          statement.bindText(21, _tmpVariableComment)
        }
        statement.bindLong(22, entity.lastUpdateTime)
        statement.bindLong(23, entity.respondTime)
        statement.bindLong(24, entity.weight.toLong())
        val _tmpExploreUrl: String? = entity.exploreUrl
        if (_tmpExploreUrl == null) {
          statement.bindNull(25)
        } else {
          statement.bindText(25, _tmpExploreUrl)
        }
        val _tmpExploreScreen: String? = entity.exploreScreen
        if (_tmpExploreScreen == null) {
          statement.bindNull(26)
        } else {
          statement.bindText(26, _tmpExploreScreen)
        }
        statement.bindLong(27, entity.exploreStyle.toLong())
        val _tmpRuleExplore: String? = entity.ruleExplore
        if (_tmpRuleExplore == null) {
          statement.bindNull(28)
        } else {
          statement.bindText(28, _tmpRuleExplore)
        }
        val _tmpSearchUrl: String? = entity.searchUrl
        if (_tmpSearchUrl == null) {
          statement.bindNull(29)
        } else {
          statement.bindText(29, _tmpSearchUrl)
        }
        val _tmpRuleSearch: String? = entity.ruleSearch
        if (_tmpRuleSearch == null) {
          statement.bindNull(30)
        } else {
          statement.bindText(30, _tmpRuleSearch)
        }
        val _tmpRuleBookInfo: String? = entity.ruleBookInfo
        if (_tmpRuleBookInfo == null) {
          statement.bindNull(31)
        } else {
          statement.bindText(31, _tmpRuleBookInfo)
        }
        val _tmpRuleToc: String? = entity.ruleToc
        if (_tmpRuleToc == null) {
          statement.bindNull(32)
        } else {
          statement.bindText(32, _tmpRuleToc)
        }
        val _tmpRuleContent: String? = entity.ruleContent
        if (_tmpRuleContent == null) {
          statement.bindNull(33)
        } else {
          statement.bindText(33, _tmpRuleContent)
        }
        val _tmpRuleReview: String? = entity.ruleReview
        if (_tmpRuleReview == null) {
          statement.bindNull(34)
        } else {
          statement.bindText(34, _tmpRuleReview)
        }
      }
    }
    this.__deleteAdapterOfBookSource = object : EntityDeleteOrUpdateAdapter<BookSource>() {
      protected override fun createQuery(): String = "DELETE FROM `book_sources` WHERE `bookSourceUrl` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: BookSource) {
        statement.bindText(1, entity.bookSourceUrl)
      }
    }
    this.__updateAdapterOfBookSource = object : EntityDeleteOrUpdateAdapter<BookSource>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `book_sources` SET `bookSourceUrl` = ?,`bookSourceName` = ?,`bookSourceGroup` = ?,`bookSourceType` = ?,`bookUrlPattern` = ?,`customOrder` = ?,`enabled` = ?,`enabledExplore` = ?,`enabledReview` = ?,`jsLib` = ?,`enabledCookieJar` = ?,`enableDangerousApi` = ?,`concurrentRate` = ?,`header` = ?,`loginUrl` = ?,`loginUi` = ?,`loginCheckJs` = ?,`coverDecodeJs` = ?,`bookSourceComment` = ?,`bookSourceIcon` = ?,`variableComment` = ?,`lastUpdateTime` = ?,`respondTime` = ?,`weight` = ?,`exploreUrl` = ?,`exploreScreen` = ?,`exploreStyle` = ?,`ruleExplore` = ?,`searchUrl` = ?,`ruleSearch` = ?,`ruleBookInfo` = ?,`ruleToc` = ?,`ruleContent` = ?,`ruleReview` = ? WHERE `bookSourceUrl` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: BookSource) {
        statement.bindText(1, entity.bookSourceUrl)
        statement.bindText(2, entity.bookSourceName)
        val _tmpBookSourceGroup: String? = entity.bookSourceGroup
        if (_tmpBookSourceGroup == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpBookSourceGroup)
        }
        statement.bindLong(4, entity.bookSourceType.toLong())
        val _tmpBookUrlPattern: String? = entity.bookUrlPattern
        if (_tmpBookUrlPattern == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpBookUrlPattern)
        }
        statement.bindLong(6, entity.customOrder.toLong())
        val _tmp: Int = if (entity.enabled) 1 else 0
        statement.bindLong(7, _tmp.toLong())
        val _tmp_1: Int = if (entity.enabledExplore) 1 else 0
        statement.bindLong(8, _tmp_1.toLong())
        val _tmp_2: Int = if (entity.enabledReview) 1 else 0
        statement.bindLong(9, _tmp_2.toLong())
        val _tmpJsLib: String? = entity.jsLib
        if (_tmpJsLib == null) {
          statement.bindNull(10)
        } else {
          statement.bindText(10, _tmpJsLib)
        }
        val _tmpEnabledCookieJar: Boolean? = entity.enabledCookieJar
        val _tmp_3: Int? = _tmpEnabledCookieJar?.let { if (it) 1 else 0 }
        if (_tmp_3 == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmp_3.toLong())
        }
        val _tmpEnableDangerousApi: Boolean? = entity.enableDangerousApi
        val _tmp_4: Int? = _tmpEnableDangerousApi?.let { if (it) 1 else 0 }
        if (_tmp_4 == null) {
          statement.bindNull(12)
        } else {
          statement.bindLong(12, _tmp_4.toLong())
        }
        val _tmpConcurrentRate: String? = entity.concurrentRate
        if (_tmpConcurrentRate == null) {
          statement.bindNull(13)
        } else {
          statement.bindText(13, _tmpConcurrentRate)
        }
        val _tmpHeader: String? = entity.header
        if (_tmpHeader == null) {
          statement.bindNull(14)
        } else {
          statement.bindText(14, _tmpHeader)
        }
        val _tmpLoginUrl: String? = entity.loginUrl
        if (_tmpLoginUrl == null) {
          statement.bindNull(15)
        } else {
          statement.bindText(15, _tmpLoginUrl)
        }
        val _tmpLoginUi: String? = entity.loginUi
        if (_tmpLoginUi == null) {
          statement.bindNull(16)
        } else {
          statement.bindText(16, _tmpLoginUi)
        }
        val _tmpLoginCheckJs: String? = entity.loginCheckJs
        if (_tmpLoginCheckJs == null) {
          statement.bindNull(17)
        } else {
          statement.bindText(17, _tmpLoginCheckJs)
        }
        val _tmpCoverDecodeJs: String? = entity.coverDecodeJs
        if (_tmpCoverDecodeJs == null) {
          statement.bindNull(18)
        } else {
          statement.bindText(18, _tmpCoverDecodeJs)
        }
        val _tmpBookSourceComment: String? = entity.bookSourceComment
        if (_tmpBookSourceComment == null) {
          statement.bindNull(19)
        } else {
          statement.bindText(19, _tmpBookSourceComment)
        }
        val _tmpBookSourceIcon: String? = entity.bookSourceIcon
        if (_tmpBookSourceIcon == null) {
          statement.bindNull(20)
        } else {
          statement.bindText(20, _tmpBookSourceIcon)
        }
        val _tmpVariableComment: String? = entity.variableComment
        if (_tmpVariableComment == null) {
          statement.bindNull(21)
        } else {
          statement.bindText(21, _tmpVariableComment)
        }
        statement.bindLong(22, entity.lastUpdateTime)
        statement.bindLong(23, entity.respondTime)
        statement.bindLong(24, entity.weight.toLong())
        val _tmpExploreUrl: String? = entity.exploreUrl
        if (_tmpExploreUrl == null) {
          statement.bindNull(25)
        } else {
          statement.bindText(25, _tmpExploreUrl)
        }
        val _tmpExploreScreen: String? = entity.exploreScreen
        if (_tmpExploreScreen == null) {
          statement.bindNull(26)
        } else {
          statement.bindText(26, _tmpExploreScreen)
        }
        statement.bindLong(27, entity.exploreStyle.toLong())
        val _tmpRuleExplore: String? = entity.ruleExplore
        if (_tmpRuleExplore == null) {
          statement.bindNull(28)
        } else {
          statement.bindText(28, _tmpRuleExplore)
        }
        val _tmpSearchUrl: String? = entity.searchUrl
        if (_tmpSearchUrl == null) {
          statement.bindNull(29)
        } else {
          statement.bindText(29, _tmpSearchUrl)
        }
        val _tmpRuleSearch: String? = entity.ruleSearch
        if (_tmpRuleSearch == null) {
          statement.bindNull(30)
        } else {
          statement.bindText(30, _tmpRuleSearch)
        }
        val _tmpRuleBookInfo: String? = entity.ruleBookInfo
        if (_tmpRuleBookInfo == null) {
          statement.bindNull(31)
        } else {
          statement.bindText(31, _tmpRuleBookInfo)
        }
        val _tmpRuleToc: String? = entity.ruleToc
        if (_tmpRuleToc == null) {
          statement.bindNull(32)
        } else {
          statement.bindText(32, _tmpRuleToc)
        }
        val _tmpRuleContent: String? = entity.ruleContent
        if (_tmpRuleContent == null) {
          statement.bindNull(33)
        } else {
          statement.bindText(33, _tmpRuleContent)
        }
        val _tmpRuleReview: String? = entity.ruleReview
        if (_tmpRuleReview == null) {
          statement.bindNull(34)
        } else {
          statement.bindText(34, _tmpRuleReview)
        }
        statement.bindText(35, entity.bookSourceUrl)
      }
    }
  }

  public override suspend fun insert(vararg bookSource: BookSource): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfBookSource.insert(_connection, bookSource)
  }

  public override suspend fun delete(vararg bookSource: BookSource): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfBookSource.handleMultiple(_connection, bookSource)
  }

  public override suspend fun update(vararg bookSource: BookSource): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfBookSource.handleMultiple(_connection, bookSource)
  }

  public override suspend fun delete(bookSources: List<BookSourcePart>): Unit = performInTransactionSuspending(__db) {
    super@BookSourceDao_Impl.delete(bookSources)
  }

  public override suspend fun enable(enable: Boolean, bookSources: List<BookSourcePart>): Unit = performInTransactionSuspending(__db) {
    super@BookSourceDao_Impl.enable(enable, bookSources)
  }

  public override suspend fun enableExplore(enable: Boolean, bookSources: List<BookSourcePart>): Unit = performInTransactionSuspending(__db) {
    super@BookSourceDao_Impl.enableExplore(enable, bookSources)
  }

  public override suspend fun upOrder(bookSources: List<BookSourcePart>): Unit = performInTransactionSuspending(__db) {
    super@BookSourceDao_Impl.upOrder(bookSources)
  }

  public override suspend fun upGroup(bookSources: List<BookSourcePart>): Unit = performInTransactionSuspending(__db) {
    super@BookSourceDao_Impl.upGroup(bookSources)
  }

  public override fun flowAll(): Flow<List<BookSourcePart>> {
    val _sql: String = "select * from book_sources_part order by customOrder asc"
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowSearch(searchKey: String, enabled: Boolean?): Flow<List<BookSourcePart>> {
    val _sql: String = """
        |select bp.*
        |    from book_sources b join book_sources_part bp on b.bookSourceUrl = bp.bookSourceUrl
        |    where (? IS NULL OR b.enabled = ?)
        |    and (b.bookSourceName like '%' || ? || '%'
        |    or b.bookSourceGroup like '%' || ? || '%'
        |    or b.bookSourceUrl like '%' || ? || '%'
        |    or b.bookSourceComment like '%' || ? || '%')
        |    order by b.customOrder asc
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources", "book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int? = enabled?.let { if (it) 1 else 0 }
        if (_tmp == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, _tmp.toLong())
        }
        _argIndex = 2
        val _tmp_1: Int? = enabled?.let { if (it) 1 else 0 }
        if (_tmp_1 == null) {
          _stmt.bindNull(_argIndex)
        } else {
          _stmt.bindLong(_argIndex, _tmp_1.toLong())
        }
        _argIndex = 3
        _stmt.bindText(_argIndex, searchKey)
        _argIndex = 4
        _stmt.bindText(_argIndex, searchKey)
        _argIndex = 5
        _stmt.bindText(_argIndex, searchKey)
        _argIndex = 6
        _stmt.bindText(_argIndex, searchKey)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp_2 != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_3 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_4: Int
          _tmp_4 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_4 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_5: Int
          _tmp_5 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_5 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowGroupSearch(searchKey: String): Flow<List<BookSourcePart>> {
    val _sql: String = """
        |select * from book_sources_part 
        |        where bookSourceGroup = ?
        |        or bookSourceGroup like ? || ',%' 
        |        or bookSourceGroup like  '%,' || ?
        |        or bookSourceGroup like  '%,' || ? || ',%' 
        |       
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, searchKey)
        _argIndex = 2
        _stmt.bindText(_argIndex, searchKey)
        _argIndex = 3
        _stmt.bindText(_argIndex, searchKey)
        _argIndex = 4
        _stmt.bindText(_argIndex, searchKey)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowEnabled(enabled: Boolean): Flow<List<BookSourcePart>> {
    val _sql: String = "select * from book_sources_part where enabled = ? order by customOrder asc"
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = if (enabled) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp_1 != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_2 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_3 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_4: Int
          _tmp_4 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_4 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enabled(enabled: Boolean): List<BookSource> {
    val _sql: String = "select * from book_sources where enabled = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = if (enabled) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp_1 != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_2 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_3 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_4?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_5: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_5 = null
          } else {
            _tmp_5 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_5?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowExplore(enabled: Boolean): Flow<List<BookSourcePart>> {
    val _sql: String = """
        |select * from book_sources_part
        |        where enabledExplore = ? and hasExploreUrl = 1
        |        order by customOrder asc
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = if (enabled) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp_1 != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_2 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_3 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_4: Int
          _tmp_4 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_4 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowExplore(key: String): Flow<List<BookSourcePart>> {
    val _sql: String = """
        |select * from book_sources_part
        |        where enabledExplore = 1
        |        and hasExploreUrl = 1
        |        and (bookSourceGroup like '%' || ? || '%'
        |            or bookSourceName like '%' || ? || '%')
        |        order by customOrder asc
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _argIndex = 2
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowLogin(): Flow<List<BookSourcePart>> {
    val _sql: String = "select * from book_sources_part where hasLoginUrl = 1"
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowNoGroup(): Flow<List<BookSourcePart>> {
    val _sql: String = """
        |select * from book_sources_part 
        |        where bookSourceGroup is null or bookSourceGroup = '' or bookSourceGroup like '%未分组%'
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowGroupExplore(key: String): Flow<List<BookSourcePart>> {
    val _sql: String = """
        |select * from book_sources_part
        |        where enabledExplore = 1
        |        and hasExploreUrl = 1
        |        and (bookSourceGroup = ?
        |            or bookSourceGroup like ? || ',%'
        |            or bookSourceGroup like  '%,' || ?
        |            or bookSourceGroup like  '%,' || ? || ',%')
        |        order by customOrder asc
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources_part")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _argIndex = 2
        _stmt.bindText(_argIndex, key)
        _argIndex = 3
        _stmt.bindText(_argIndex, key)
        _argIndex = 4
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowGroupsUnProcessed(): Flow<List<String>> {
    val _sql: String = "select distinct bookSourceGroup from book_sources where trim(bookSourceGroup) <> ''"
    return createFlow(__db, false, arrayOf("book_sources")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowEnabledGroupsUnProcessed(): Flow<List<String>> {
    val _sql: String = """
        |select distinct bookSourceGroup from book_sources 
        |        where enabled = 1 and trim(bookSourceGroup) <> ''
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowExploreGroupsUnProcessed(): Flow<List<String>> {
    val _sql: String = """
        |select distinct bookSourceGroup from book_sources 
        |        where enabledExplore = 1 
        |        and trim(exploreUrl) <> '' 
        |        and trim(bookSourceGroup) <> ''
        |        order by customOrder
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_sources")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getByGroup(group: String): List<BookSource> {
    val _sql: String = """
        |select * from book_sources 
        |        where bookSourceGroup like '%' || ? || '%' order by customOrder asc
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, group)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getEnabledByGroup(group: String): List<BookSource> {
    val _sql: String = """
        |select * from book_sources
        |        where enabled = 1 
        |        and (bookSourceGroup = ?
        |            or bookSourceGroup like ? || ',%' 
        |            or bookSourceGroup like  '%,' || ?
        |            or bookSourceGroup like  '%,' || ? || ',%')
        |        order by customOrder asc
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, group)
        _argIndex = 2
        _stmt.bindText(_argIndex, group)
        _argIndex = 3
        _stmt.bindText(_argIndex, group)
        _argIndex = 4
        _stmt.bindText(_argIndex, group)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBookSourceAddBook(baseUrl: String): BookSource? {
    val _sql: String = "select * from book_sources where enabled = 1 and bookSourceUrl like ? || '%'"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, baseUrl)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: BookSource?
        if (_stmt.step()) {
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _result = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun hasBookUrlPattern(): List<BookSource> {
    val _sql: String = """
        |select b.* 
        |        from book_sources b
        |        where b.enabled = 1 
        |        and b.bookUrlPattern is not null 
        |        and trim(b.bookUrlPattern) <> ''
        |        order by b.customOrder
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun noGroup(): List<BookSource> {
    val _sql: String = "select * from book_sources where bookSourceGroup is null or bookSourceGroup = ''"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(): List<BookSource> {
    val _sql: String = "select * from book_sources order by customOrder asc"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allPart(): List<BookSourcePart> {
    val _sql: String = "select * from book_sources_part order by customOrder asc"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allEnabled(): List<BookSource> {
    val _sql: String = "select * from book_sources where enabled = 1 order by customOrder asc"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allTextEnabledPart(): List<BookSourcePart> {
    val _sql: String = """
        |select bp.*
        |        from book_sources b join book_sources_part bp on b.bookSourceUrl = bp.bookSourceUrl 
        |        where b.enabled = 1 and b.bookSourceType = 0 order by b.customOrder
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: MutableList<BookSourcePart> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookSourcePart
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _item = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allGroupsUnProcessed(): List<String> {
    val _sql: String = """
        |select distinct bookSourceGroup from book_sources 
        |        where trim(bookSourceGroup) <> ''
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allEnabledGroupsUnProcessed(): List<String> {
    val _sql: String = """
        |select distinct bookSourceGroup from book_sources 
        |        where enabled = 1 and trim(bookSourceGroup) <> ''
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBookSource(key: String): BookSource? {
    val _sql: String = "select * from book_sources where bookSourceUrl = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: BookSource?
        if (_stmt.step()) {
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _result = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBookSourcePart(key: String): BookSourcePart? {
    val _sql: String = "select * from book_sources_part where bookSourceUrl = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfHasLoginUrl: Int = getColumnIndexOrThrow(_stmt, "hasLoginUrl")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfHasExploreUrl: Int = getColumnIndexOrThrow(_stmt, "hasExploreUrl")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _result: BookSourcePart?
        if (_stmt.step()) {
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpHasLoginUrl: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfHasLoginUrl).toInt()
          _tmpHasLoginUrl = _tmp_2 != 0
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpHasExploreUrl: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfHasExploreUrl).toInt()
          _tmpHasExploreUrl = _tmp_3 != 0
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          _result = BookSourcePart(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpHasLoginUrl,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpHasExploreUrl,_tmpBookSourceIcon)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getBookSources(urls: List<String>): List<BookSource> {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("select * from book_sources where bookSourceUrl in (")
    val _inputSize: Int = urls.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in urls) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        val _columnIndexOfBookSourceUrl: Int = getColumnIndexOrThrow(_stmt, "bookSourceUrl")
        val _columnIndexOfBookSourceName: Int = getColumnIndexOrThrow(_stmt, "bookSourceName")
        val _columnIndexOfBookSourceGroup: Int = getColumnIndexOrThrow(_stmt, "bookSourceGroup")
        val _columnIndexOfBookSourceType: Int = getColumnIndexOrThrow(_stmt, "bookSourceType")
        val _columnIndexOfBookUrlPattern: Int = getColumnIndexOrThrow(_stmt, "bookUrlPattern")
        val _columnIndexOfCustomOrder: Int = getColumnIndexOrThrow(_stmt, "customOrder")
        val _columnIndexOfEnabled: Int = getColumnIndexOrThrow(_stmt, "enabled")
        val _columnIndexOfEnabledExplore: Int = getColumnIndexOrThrow(_stmt, "enabledExplore")
        val _columnIndexOfEnabledReview: Int = getColumnIndexOrThrow(_stmt, "enabledReview")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfCoverDecodeJs: Int = getColumnIndexOrThrow(_stmt, "coverDecodeJs")
        val _columnIndexOfBookSourceComment: Int = getColumnIndexOrThrow(_stmt, "bookSourceComment")
        val _columnIndexOfBookSourceIcon: Int = getColumnIndexOrThrow(_stmt, "bookSourceIcon")
        val _columnIndexOfVariableComment: Int = getColumnIndexOrThrow(_stmt, "variableComment")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _columnIndexOfRespondTime: Int = getColumnIndexOrThrow(_stmt, "respondTime")
        val _columnIndexOfWeight: Int = getColumnIndexOrThrow(_stmt, "weight")
        val _columnIndexOfExploreUrl: Int = getColumnIndexOrThrow(_stmt, "exploreUrl")
        val _columnIndexOfExploreScreen: Int = getColumnIndexOrThrow(_stmt, "exploreScreen")
        val _columnIndexOfExploreStyle: Int = getColumnIndexOrThrow(_stmt, "exploreStyle")
        val _columnIndexOfRuleExplore: Int = getColumnIndexOrThrow(_stmt, "ruleExplore")
        val _columnIndexOfSearchUrl: Int = getColumnIndexOrThrow(_stmt, "searchUrl")
        val _columnIndexOfRuleSearch: Int = getColumnIndexOrThrow(_stmt, "ruleSearch")
        val _columnIndexOfRuleBookInfo: Int = getColumnIndexOrThrow(_stmt, "ruleBookInfo")
        val _columnIndexOfRuleToc: Int = getColumnIndexOrThrow(_stmt, "ruleToc")
        val _columnIndexOfRuleContent: Int = getColumnIndexOrThrow(_stmt, "ruleContent")
        val _columnIndexOfRuleReview: Int = getColumnIndexOrThrow(_stmt, "ruleReview")
        val _result: MutableList<BookSource> = mutableListOf()
        while (_stmt.step()) {
          val _item_1: BookSource
          val _tmpBookSourceUrl: String
          _tmpBookSourceUrl = _stmt.getText(_columnIndexOfBookSourceUrl)
          val _tmpBookSourceName: String
          _tmpBookSourceName = _stmt.getText(_columnIndexOfBookSourceName)
          val _tmpBookSourceGroup: String?
          if (_stmt.isNull(_columnIndexOfBookSourceGroup)) {
            _tmpBookSourceGroup = null
          } else {
            _tmpBookSourceGroup = _stmt.getText(_columnIndexOfBookSourceGroup)
          }
          val _tmpBookSourceType: Int
          _tmpBookSourceType = _stmt.getLong(_columnIndexOfBookSourceType).toInt()
          val _tmpBookUrlPattern: String?
          if (_stmt.isNull(_columnIndexOfBookUrlPattern)) {
            _tmpBookUrlPattern = null
          } else {
            _tmpBookUrlPattern = _stmt.getText(_columnIndexOfBookUrlPattern)
          }
          val _tmpCustomOrder: Int
          _tmpCustomOrder = _stmt.getLong(_columnIndexOfCustomOrder).toInt()
          val _tmpEnabled: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnabled).toInt()
          _tmpEnabled = _tmp != 0
          val _tmpEnabledExplore: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfEnabledExplore).toInt()
          _tmpEnabledExplore = _tmp_1 != 0
          val _tmpEnabledReview: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfEnabledReview).toInt()
          _tmpEnabledReview = _tmp_2 != 0
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp_3: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp_3 = null
          } else {
            _tmp_3 = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp_3?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_4: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_4 = null
          } else {
            _tmp_4 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_4?.let { it != 0 }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpCoverDecodeJs: String?
          if (_stmt.isNull(_columnIndexOfCoverDecodeJs)) {
            _tmpCoverDecodeJs = null
          } else {
            _tmpCoverDecodeJs = _stmt.getText(_columnIndexOfCoverDecodeJs)
          }
          val _tmpBookSourceComment: String?
          if (_stmt.isNull(_columnIndexOfBookSourceComment)) {
            _tmpBookSourceComment = null
          } else {
            _tmpBookSourceComment = _stmt.getText(_columnIndexOfBookSourceComment)
          }
          val _tmpBookSourceIcon: String?
          if (_stmt.isNull(_columnIndexOfBookSourceIcon)) {
            _tmpBookSourceIcon = null
          } else {
            _tmpBookSourceIcon = _stmt.getText(_columnIndexOfBookSourceIcon)
          }
          val _tmpVariableComment: String?
          if (_stmt.isNull(_columnIndexOfVariableComment)) {
            _tmpVariableComment = null
          } else {
            _tmpVariableComment = _stmt.getText(_columnIndexOfVariableComment)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          val _tmpRespondTime: Long
          _tmpRespondTime = _stmt.getLong(_columnIndexOfRespondTime)
          val _tmpWeight: Int
          _tmpWeight = _stmt.getLong(_columnIndexOfWeight).toInt()
          val _tmpExploreUrl: String?
          if (_stmt.isNull(_columnIndexOfExploreUrl)) {
            _tmpExploreUrl = null
          } else {
            _tmpExploreUrl = _stmt.getText(_columnIndexOfExploreUrl)
          }
          val _tmpExploreScreen: String?
          if (_stmt.isNull(_columnIndexOfExploreScreen)) {
            _tmpExploreScreen = null
          } else {
            _tmpExploreScreen = _stmt.getText(_columnIndexOfExploreScreen)
          }
          val _tmpExploreStyle: Int
          _tmpExploreStyle = _stmt.getLong(_columnIndexOfExploreStyle).toInt()
          val _tmpRuleExplore: String?
          if (_stmt.isNull(_columnIndexOfRuleExplore)) {
            _tmpRuleExplore = null
          } else {
            _tmpRuleExplore = _stmt.getText(_columnIndexOfRuleExplore)
          }
          val _tmpSearchUrl: String?
          if (_stmt.isNull(_columnIndexOfSearchUrl)) {
            _tmpSearchUrl = null
          } else {
            _tmpSearchUrl = _stmt.getText(_columnIndexOfSearchUrl)
          }
          val _tmpRuleSearch: String?
          if (_stmt.isNull(_columnIndexOfRuleSearch)) {
            _tmpRuleSearch = null
          } else {
            _tmpRuleSearch = _stmt.getText(_columnIndexOfRuleSearch)
          }
          val _tmpRuleBookInfo: String?
          if (_stmt.isNull(_columnIndexOfRuleBookInfo)) {
            _tmpRuleBookInfo = null
          } else {
            _tmpRuleBookInfo = _stmt.getText(_columnIndexOfRuleBookInfo)
          }
          val _tmpRuleToc: String?
          if (_stmt.isNull(_columnIndexOfRuleToc)) {
            _tmpRuleToc = null
          } else {
            _tmpRuleToc = _stmt.getText(_columnIndexOfRuleToc)
          }
          val _tmpRuleContent: String?
          if (_stmt.isNull(_columnIndexOfRuleContent)) {
            _tmpRuleContent = null
          } else {
            _tmpRuleContent = _stmt.getText(_columnIndexOfRuleContent)
          }
          val _tmpRuleReview: String?
          if (_stmt.isNull(_columnIndexOfRuleReview)) {
            _tmpRuleReview = null
          } else {
            _tmpRuleReview = _stmt.getText(_columnIndexOfRuleReview)
          }
          _item_1 = BookSource(_tmpBookSourceUrl,_tmpBookSourceName,_tmpBookSourceGroup,_tmpBookSourceType,_tmpBookUrlPattern,_tmpCustomOrder,_tmpEnabled,_tmpEnabledExplore,_tmpEnabledReview,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpConcurrentRate,_tmpHeader,_tmpLoginUrl,_tmpLoginUi,_tmpLoginCheckJs,_tmpCoverDecodeJs,_tmpBookSourceComment,_tmpBookSourceIcon,_tmpVariableComment,_tmpLastUpdateTime,_tmpRespondTime,_tmpWeight,_tmpExploreUrl,_tmpExploreScreen,_tmpExploreStyle,_tmpRuleExplore,_tmpSearchUrl,_tmpRuleSearch,_tmpRuleBookInfo,_tmpRuleToc,_tmpRuleContent,_tmpRuleReview)
          _result.add(_item_1)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allCount(): Int {
    val _sql: String = "select count(*) from book_sources"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun minOrder(): Int {
    val _sql: String = "select min(customOrder) from book_sources"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxOrder(): Int {
    val _sql: String = "select max(customOrder) from book_sources"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun hasDuplicateOrder(): Boolean {
    val _sql: String = """
        |select exists (select 1 
        |        from book_sources group by customOrder having count(customOrder) > 1)
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun delete(key: String) {
    val _sql: String = "delete from book_sources where bookSourceUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteIn(keys: List<String>) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("delete from book_sources where bookSourceUrl in (")
    val _inputSize: Int = keys.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        for (_item: String in keys) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enable(bookSourceUrl: String, enable: Boolean) {
    val _sql: String = "update book_sources set enabled = ? where bookSourceUrl = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = if (enable) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        _argIndex = 2
        _stmt.bindText(_argIndex, bookSourceUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enableIn(urls: List<String>, enable: Boolean) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("update book_sources set enabled = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" where bookSourceUrl in (")
    val _inputSize: Int = urls.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = if (enable) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        _argIndex = 2
        for (_item: String in urls) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enableExploreIn(urls: List<String>, enable: Boolean) {
    val _stringBuilder: StringBuilder = StringBuilder()
    _stringBuilder.append("update book_sources set enabledExplore = ")
    _stringBuilder.append("?")
    _stringBuilder.append(" where bookSourceUrl in (")
    val _inputSize: Int = urls.size
    appendPlaceholders(_stringBuilder, _inputSize)
    _stringBuilder.append(")")
    val _sql: String = _stringBuilder.toString()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        val _tmp: Int = if (enable) 1 else 0
        _stmt.bindLong(_argIndex, _tmp.toLong())
        _argIndex = 2
        for (_item: String in urls) {
          _stmt.bindText(_argIndex, _item)
          _argIndex++
        }
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upOrder(bookSourceUrl: String, customOrder: Int) {
    val _sql: String = """
        |update book_sources
        |        set customOrder = ? where bookSourceUrl = ?
        """.trimMargin()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, customOrder.toLong())
        _argIndex = 2
        _stmt.bindText(_argIndex, bookSourceUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun shiftCustomOrder(offset: Int) {
    val _sql: String = "update book_sources set customOrder = customOrder + ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, offset.toLong())
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun upGroup(bookSourceUrl: String, bookSourceGroup: String) {
    val _sql: String = """
        |update book_sources 
        |        set bookSourceGroup = ? where bookSourceUrl = ?
        """.trimMargin()
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, bookSourceGroup)
        _argIndex = 2
        _stmt.bindText(_argIndex, bookSourceUrl)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
