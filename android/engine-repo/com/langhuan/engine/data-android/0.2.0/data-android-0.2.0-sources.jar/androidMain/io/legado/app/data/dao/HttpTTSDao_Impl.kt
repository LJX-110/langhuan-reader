package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.HttpTTS
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class HttpTTSDao_Impl(
  __db: RoomDatabase,
) : HttpTTSDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfHttpTTS: EntityInsertAdapter<HttpTTS>

  private val __deleteAdapterOfHttpTTS: EntityDeleteOrUpdateAdapter<HttpTTS>
  init {
    this.__db = __db
    this.__insertAdapterOfHttpTTS = object : EntityInsertAdapter<HttpTTS>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `httpTTS` (`id`,`name`,`url`,`contentType`,`concurrentRate`,`loginUrl`,`loginUi`,`header`,`jsLib`,`enabledCookieJar`,`enableDangerousApi`,`loginCheckJs`,`lastUpdateTime`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: HttpTTS) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        statement.bindText(3, entity.url)
        val _tmpContentType: String? = entity.contentType
        if (_tmpContentType == null) {
          statement.bindNull(4)
        } else {
          statement.bindText(4, _tmpContentType)
        }
        val _tmpConcurrentRate: String? = entity.concurrentRate
        if (_tmpConcurrentRate == null) {
          statement.bindNull(5)
        } else {
          statement.bindText(5, _tmpConcurrentRate)
        }
        val _tmpLoginUrl: String? = entity.loginUrl
        if (_tmpLoginUrl == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpLoginUrl)
        }
        val _tmpLoginUi: String? = entity.loginUi
        if (_tmpLoginUi == null) {
          statement.bindNull(7)
        } else {
          statement.bindText(7, _tmpLoginUi)
        }
        val _tmpHeader: String? = entity.header
        if (_tmpHeader == null) {
          statement.bindNull(8)
        } else {
          statement.bindText(8, _tmpHeader)
        }
        val _tmpJsLib: String? = entity.jsLib
        if (_tmpJsLib == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpJsLib)
        }
        val _tmpEnabledCookieJar: Boolean? = entity.enabledCookieJar
        val _tmp: Int? = _tmpEnabledCookieJar?.let { if (it) 1 else 0 }
        if (_tmp == null) {
          statement.bindNull(10)
        } else {
          statement.bindLong(10, _tmp.toLong())
        }
        val _tmpEnableDangerousApi: Boolean? = entity.enableDangerousApi
        val _tmp_1: Int? = _tmpEnableDangerousApi?.let { if (it) 1 else 0 }
        if (_tmp_1 == null) {
          statement.bindNull(11)
        } else {
          statement.bindLong(11, _tmp_1.toLong())
        }
        val _tmpLoginCheckJs: String? = entity.loginCheckJs
        if (_tmpLoginCheckJs == null) {
          statement.bindNull(12)
        } else {
          statement.bindText(12, _tmpLoginCheckJs)
        }
        statement.bindLong(13, entity.lastUpdateTime)
      }
    }
    this.__deleteAdapterOfHttpTTS = object : EntityDeleteOrUpdateAdapter<HttpTTS>() {
      protected override fun createQuery(): String = "DELETE FROM `httpTTS` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: HttpTTS) {
        statement.bindLong(1, entity.id)
      }
    }
  }

  public override suspend fun insert(vararg httpTTS: HttpTTS): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfHttpTTS.insert(_connection, httpTTS)
  }

  public override suspend fun delete(vararg httpTTS: HttpTTS): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfHttpTTS.handleMultiple(_connection, httpTTS)
  }

  public override suspend fun all(): List<HttpTTS> {
    val _sql: String = "select * from httpTTS order by name"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfContentType: Int = getColumnIndexOrThrow(_stmt, "contentType")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _result: MutableList<HttpTTS> = mutableListOf()
        while (_stmt.step()) {
          val _item: HttpTTS
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpContentType: String?
          if (_stmt.isNull(_columnIndexOfContentType)) {
            _tmpContentType = null
          } else {
            _tmpContentType = _stmt.getText(_columnIndexOfContentType)
          }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp = null
          } else {
            _tmp = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_1: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_1?.let { it != 0 }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          _item = HttpTTS(_tmpId,_tmpName,_tmpUrl,_tmpContentType,_tmpConcurrentRate,_tmpLoginUrl,_tmpLoginUi,_tmpHeader,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpLoginCheckJs,_tmpLastUpdateTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<HttpTTS>> {
    val _sql: String = "select * from httpTTS order by name"
    return createFlow(__db, false, arrayOf("httpTTS")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfContentType: Int = getColumnIndexOrThrow(_stmt, "contentType")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _result: MutableList<HttpTTS> = mutableListOf()
        while (_stmt.step()) {
          val _item: HttpTTS
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpContentType: String?
          if (_stmt.isNull(_columnIndexOfContentType)) {
            _tmpContentType = null
          } else {
            _tmpContentType = _stmt.getText(_columnIndexOfContentType)
          }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp = null
          } else {
            _tmp = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_1: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_1?.let { it != 0 }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          _item = HttpTTS(_tmpId,_tmpName,_tmpUrl,_tmpContentType,_tmpConcurrentRate,_tmpLoginUrl,_tmpLoginUi,_tmpHeader,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpLoginCheckJs,_tmpLastUpdateTime)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun count(): Int {
    val _sql: String = "select count(*) from httpTTS"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun `get`(id: Long): HttpTTS? {
    val _sql: String = "select * from httpTTS where id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfUrl: Int = getColumnIndexOrThrow(_stmt, "url")
        val _columnIndexOfContentType: Int = getColumnIndexOrThrow(_stmt, "contentType")
        val _columnIndexOfConcurrentRate: Int = getColumnIndexOrThrow(_stmt, "concurrentRate")
        val _columnIndexOfLoginUrl: Int = getColumnIndexOrThrow(_stmt, "loginUrl")
        val _columnIndexOfLoginUi: Int = getColumnIndexOrThrow(_stmt, "loginUi")
        val _columnIndexOfHeader: Int = getColumnIndexOrThrow(_stmt, "header")
        val _columnIndexOfJsLib: Int = getColumnIndexOrThrow(_stmt, "jsLib")
        val _columnIndexOfEnabledCookieJar: Int = getColumnIndexOrThrow(_stmt, "enabledCookieJar")
        val _columnIndexOfEnableDangerousApi: Int = getColumnIndexOrThrow(_stmt, "enableDangerousApi")
        val _columnIndexOfLoginCheckJs: Int = getColumnIndexOrThrow(_stmt, "loginCheckJs")
        val _columnIndexOfLastUpdateTime: Int = getColumnIndexOrThrow(_stmt, "lastUpdateTime")
        val _result: HttpTTS?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpUrl: String
          _tmpUrl = _stmt.getText(_columnIndexOfUrl)
          val _tmpContentType: String?
          if (_stmt.isNull(_columnIndexOfContentType)) {
            _tmpContentType = null
          } else {
            _tmpContentType = _stmt.getText(_columnIndexOfContentType)
          }
          val _tmpConcurrentRate: String?
          if (_stmt.isNull(_columnIndexOfConcurrentRate)) {
            _tmpConcurrentRate = null
          } else {
            _tmpConcurrentRate = _stmt.getText(_columnIndexOfConcurrentRate)
          }
          val _tmpLoginUrl: String?
          if (_stmt.isNull(_columnIndexOfLoginUrl)) {
            _tmpLoginUrl = null
          } else {
            _tmpLoginUrl = _stmt.getText(_columnIndexOfLoginUrl)
          }
          val _tmpLoginUi: String?
          if (_stmt.isNull(_columnIndexOfLoginUi)) {
            _tmpLoginUi = null
          } else {
            _tmpLoginUi = _stmt.getText(_columnIndexOfLoginUi)
          }
          val _tmpHeader: String?
          if (_stmt.isNull(_columnIndexOfHeader)) {
            _tmpHeader = null
          } else {
            _tmpHeader = _stmt.getText(_columnIndexOfHeader)
          }
          val _tmpJsLib: String?
          if (_stmt.isNull(_columnIndexOfJsLib)) {
            _tmpJsLib = null
          } else {
            _tmpJsLib = _stmt.getText(_columnIndexOfJsLib)
          }
          val _tmpEnabledCookieJar: Boolean?
          val _tmp: Int?
          if (_stmt.isNull(_columnIndexOfEnabledCookieJar)) {
            _tmp = null
          } else {
            _tmp = _stmt.getLong(_columnIndexOfEnabledCookieJar).toInt()
          }
          _tmpEnabledCookieJar = _tmp?.let { it != 0 }
          val _tmpEnableDangerousApi: Boolean?
          val _tmp_1: Int?
          if (_stmt.isNull(_columnIndexOfEnableDangerousApi)) {
            _tmp_1 = null
          } else {
            _tmp_1 = _stmt.getLong(_columnIndexOfEnableDangerousApi).toInt()
          }
          _tmpEnableDangerousApi = _tmp_1?.let { it != 0 }
          val _tmpLoginCheckJs: String?
          if (_stmt.isNull(_columnIndexOfLoginCheckJs)) {
            _tmpLoginCheckJs = null
          } else {
            _tmpLoginCheckJs = _stmt.getText(_columnIndexOfLoginCheckJs)
          }
          val _tmpLastUpdateTime: Long
          _tmpLastUpdateTime = _stmt.getLong(_columnIndexOfLastUpdateTime)
          _result = HttpTTS(_tmpId,_tmpName,_tmpUrl,_tmpContentType,_tmpConcurrentRate,_tmpLoginUrl,_tmpLoginUi,_tmpHeader,_tmpJsLib,_tmpEnabledCookieJar,_tmpEnableDangerousApi,_tmpLoginCheckJs,_tmpLastUpdateTime)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun deleteDefault() {
    val _sql: String = "delete from httpTTS where id < 0"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
