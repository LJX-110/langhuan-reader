package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.BookGroup
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class BookGroupDao_Impl(
  __db: RoomDatabase,
) : BookGroupDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfBookGroup: EntityInsertAdapter<BookGroup>

  private val __deleteAdapterOfBookGroup: EntityDeleteOrUpdateAdapter<BookGroup>

  private val __updateAdapterOfBookGroup: EntityDeleteOrUpdateAdapter<BookGroup>
  init {
    this.__db = __db
    this.__insertAdapterOfBookGroup = object : EntityInsertAdapter<BookGroup>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `book_groups` (`groupId`,`groupName`,`cover`,`order`,`enableRefresh`,`show`,`bookSort`) VALUES (?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: BookGroup) {
        statement.bindLong(1, entity.groupId)
        statement.bindText(2, entity.groupName)
        val _tmpCover: String? = entity.cover
        if (_tmpCover == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpCover)
        }
        statement.bindLong(4, entity.order.toLong())
        val _tmp: Int = if (entity.enableRefresh) 1 else 0
        statement.bindLong(5, _tmp.toLong())
        val _tmp_1: Int = if (entity.show) 1 else 0
        statement.bindLong(6, _tmp_1.toLong())
        statement.bindLong(7, entity.bookSort.toLong())
      }
    }
    this.__deleteAdapterOfBookGroup = object : EntityDeleteOrUpdateAdapter<BookGroup>() {
      protected override fun createQuery(): String = "DELETE FROM `book_groups` WHERE `groupId` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: BookGroup) {
        statement.bindLong(1, entity.groupId)
      }
    }
    this.__updateAdapterOfBookGroup = object : EntityDeleteOrUpdateAdapter<BookGroup>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `book_groups` SET `groupId` = ?,`groupName` = ?,`cover` = ?,`order` = ?,`enableRefresh` = ?,`show` = ?,`bookSort` = ? WHERE `groupId` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: BookGroup) {
        statement.bindLong(1, entity.groupId)
        statement.bindText(2, entity.groupName)
        val _tmpCover: String? = entity.cover
        if (_tmpCover == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpCover)
        }
        statement.bindLong(4, entity.order.toLong())
        val _tmp: Int = if (entity.enableRefresh) 1 else 0
        statement.bindLong(5, _tmp.toLong())
        val _tmp_1: Int = if (entity.show) 1 else 0
        statement.bindLong(6, _tmp_1.toLong())
        statement.bindLong(7, entity.bookSort.toLong())
        statement.bindLong(8, entity.groupId)
      }
    }
  }

  public override suspend fun insert(vararg bookGroup: BookGroup): Unit = performSuspending(__db, false, true) { _connection ->
    __insertAdapterOfBookGroup.insert(_connection, bookGroup)
  }

  public override suspend fun delete(vararg bookGroup: BookGroup): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfBookGroup.handleMultiple(_connection, bookGroup)
  }

  public override suspend fun update(vararg bookGroup: BookGroup): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfBookGroup.handleMultiple(_connection, bookGroup)
  }

  public override suspend fun getByID(id: Long): BookGroup? {
    val _sql: String = "select * from book_groups where groupId = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfGroupName: Int = getColumnIndexOrThrow(_stmt, "groupName")
        val _columnIndexOfCover: Int = getColumnIndexOrThrow(_stmt, "cover")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfEnableRefresh: Int = getColumnIndexOrThrow(_stmt, "enableRefresh")
        val _columnIndexOfShow: Int = getColumnIndexOrThrow(_stmt, "show")
        val _columnIndexOfBookSort: Int = getColumnIndexOrThrow(_stmt, "bookSort")
        val _result: BookGroup?
        if (_stmt.step()) {
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpGroupName: String
          _tmpGroupName = _stmt.getText(_columnIndexOfGroupName)
          val _tmpCover: String?
          if (_stmt.isNull(_columnIndexOfCover)) {
            _tmpCover = null
          } else {
            _tmpCover = _stmt.getText(_columnIndexOfCover)
          }
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpEnableRefresh: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnableRefresh).toInt()
          _tmpEnableRefresh = _tmp != 0
          val _tmpShow: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfShow).toInt()
          _tmpShow = _tmp_1 != 0
          val _tmpBookSort: Int
          _tmpBookSort = _stmt.getLong(_columnIndexOfBookSort).toInt()
          _result = BookGroup(_tmpGroupId,_tmpGroupName,_tmpCover,_tmpOrder,_tmpEnableRefresh,_tmpShow,_tmpBookSort)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowAll(): Flow<List<BookGroup>> {
    val _sql: String = "SELECT * FROM book_groups ORDER BY `order`"
    return createFlow(__db, false, arrayOf("book_groups")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfGroupName: Int = getColumnIndexOrThrow(_stmt, "groupName")
        val _columnIndexOfCover: Int = getColumnIndexOrThrow(_stmt, "cover")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfEnableRefresh: Int = getColumnIndexOrThrow(_stmt, "enableRefresh")
        val _columnIndexOfShow: Int = getColumnIndexOrThrow(_stmt, "show")
        val _columnIndexOfBookSort: Int = getColumnIndexOrThrow(_stmt, "bookSort")
        val _result: MutableList<BookGroup> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookGroup
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpGroupName: String
          _tmpGroupName = _stmt.getText(_columnIndexOfGroupName)
          val _tmpCover: String?
          if (_stmt.isNull(_columnIndexOfCover)) {
            _tmpCover = null
          } else {
            _tmpCover = _stmt.getText(_columnIndexOfCover)
          }
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpEnableRefresh: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnableRefresh).toInt()
          _tmpEnableRefresh = _tmp != 0
          val _tmpShow: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfShow).toInt()
          _tmpShow = _tmp_1 != 0
          val _tmpBookSort: Int
          _tmpBookSort = _stmt.getLong(_columnIndexOfBookSort).toInt()
          _item = BookGroup(_tmpGroupId,_tmpGroupName,_tmpCover,_tmpOrder,_tmpEnableRefresh,_tmpShow,_tmpBookSort)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowShow(): Flow<List<BookGroup>> {
    val _sql: String = """
        |
        |        with const as (SELECT sum(groupId) sumGroupId FROM book_groups where groupId > 0)
        |        SELECT book_groups.* FROM book_groups join const
        |        where show > 0
        |        and (
        |            (groupId >= 0  and exists (select 1 from books where `group` & book_groups.groupId > 0))
        |            or groupId = -1
        |            or (groupId = -2 and exists (select 1 from books where type & 256 > 0))
        |            or (groupId = -11 and exists (select 1 from books where type & 16 > 0))
        |            or (groupId = -4
        |                and exists (
        |                    select 1 from books
        |                    where const.sumGroupId & `group` = 0
        |                )
        |            )
        |        )
        |        ORDER BY `order`
        """.trimMargin()
    return createFlow(__db, false, arrayOf("book_groups", "books")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfGroupName: Int = getColumnIndexOrThrow(_stmt, "groupName")
        val _columnIndexOfCover: Int = getColumnIndexOrThrow(_stmt, "cover")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfEnableRefresh: Int = getColumnIndexOrThrow(_stmt, "enableRefresh")
        val _columnIndexOfShow: Int = getColumnIndexOrThrow(_stmt, "show")
        val _columnIndexOfBookSort: Int = getColumnIndexOrThrow(_stmt, "bookSort")
        val _result: MutableList<BookGroup> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookGroup
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpGroupName: String
          _tmpGroupName = _stmt.getText(_columnIndexOfGroupName)
          val _tmpCover: String?
          if (_stmt.isNull(_columnIndexOfCover)) {
            _tmpCover = null
          } else {
            _tmpCover = _stmt.getText(_columnIndexOfCover)
          }
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpEnableRefresh: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnableRefresh).toInt()
          _tmpEnableRefresh = _tmp != 0
          val _tmpShow: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfShow).toInt()
          _tmpShow = _tmp_1 != 0
          val _tmpBookSort: Int
          _tmpBookSort = _stmt.getLong(_columnIndexOfBookSort).toInt()
          _item = BookGroup(_tmpGroupId,_tmpGroupName,_tmpCover,_tmpOrder,_tmpEnableRefresh,_tmpShow,_tmpBookSort)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowSelect(): Flow<List<BookGroup>> {
    val _sql: String = "SELECT * FROM book_groups where groupId >= 0 ORDER BY `order`"
    return createFlow(__db, false, arrayOf("book_groups")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfGroupName: Int = getColumnIndexOrThrow(_stmt, "groupName")
        val _columnIndexOfCover: Int = getColumnIndexOrThrow(_stmt, "cover")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfEnableRefresh: Int = getColumnIndexOrThrow(_stmt, "enableRefresh")
        val _columnIndexOfShow: Int = getColumnIndexOrThrow(_stmt, "show")
        val _columnIndexOfBookSort: Int = getColumnIndexOrThrow(_stmt, "bookSort")
        val _result: MutableList<BookGroup> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookGroup
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpGroupName: String
          _tmpGroupName = _stmt.getText(_columnIndexOfGroupName)
          val _tmpCover: String?
          if (_stmt.isNull(_columnIndexOfCover)) {
            _tmpCover = null
          } else {
            _tmpCover = _stmt.getText(_columnIndexOfCover)
          }
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpEnableRefresh: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnableRefresh).toInt()
          _tmpEnableRefresh = _tmp != 0
          val _tmpShow: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfShow).toInt()
          _tmpShow = _tmp_1 != 0
          val _tmpBookSort: Int
          _tmpBookSort = _stmt.getLong(_columnIndexOfBookSort).toInt()
          _item = BookGroup(_tmpGroupId,_tmpGroupName,_tmpCover,_tmpOrder,_tmpEnableRefresh,_tmpShow,_tmpBookSort)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun idsSum(): Long {
    val _sql: String = "SELECT sum(groupId) FROM book_groups where groupId >= 0"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Long
        if (_stmt.step()) {
          val _tmp: Long
          _tmp = _stmt.getLong(0)
          _result = _tmp
        } else {
          _result = 0L
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxOrder(): Int {
    val _sql: String = "SELECT MAX(`order`) FROM book_groups where groupId >= 0"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(): List<BookGroup> {
    val _sql: String = "SELECT * FROM book_groups ORDER BY `order`"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfGroupId: Int = getColumnIndexOrThrow(_stmt, "groupId")
        val _columnIndexOfGroupName: Int = getColumnIndexOrThrow(_stmt, "groupName")
        val _columnIndexOfCover: Int = getColumnIndexOrThrow(_stmt, "cover")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "order")
        val _columnIndexOfEnableRefresh: Int = getColumnIndexOrThrow(_stmt, "enableRefresh")
        val _columnIndexOfShow: Int = getColumnIndexOrThrow(_stmt, "show")
        val _columnIndexOfBookSort: Int = getColumnIndexOrThrow(_stmt, "bookSort")
        val _result: MutableList<BookGroup> = mutableListOf()
        while (_stmt.step()) {
          val _item: BookGroup
          val _tmpGroupId: Long
          _tmpGroupId = _stmt.getLong(_columnIndexOfGroupId)
          val _tmpGroupName: String
          _tmpGroupName = _stmt.getText(_columnIndexOfGroupName)
          val _tmpCover: String?
          if (_stmt.isNull(_columnIndexOfCover)) {
            _tmpCover = null
          } else {
            _tmpCover = _stmt.getText(_columnIndexOfCover)
          }
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          val _tmpEnableRefresh: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfEnableRefresh).toInt()
          _tmpEnableRefresh = _tmp != 0
          val _tmpShow: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfShow).toInt()
          _tmpShow = _tmp_1 != 0
          val _tmpBookSort: Int
          _tmpBookSort = _stmt.getLong(_columnIndexOfBookSort).toInt()
          _item = BookGroup(_tmpGroupId,_tmpGroupName,_tmpCover,_tmpOrder,_tmpEnableRefresh,_tmpShow,_tmpBookSort)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun canAddGroup(): Boolean {
    val _sql: String = "select count(*) < 64 from book_groups where groupId >= 0 or groupId == -9223372036854775808"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Boolean
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp != 0
        } else {
          _result = false
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getGroupNames(id: Long): List<String> {
    val _sql: String = "select groupName from book_groups where groupId > 0 and (groupId & ?) > 0"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun enableGroup(groupId: Long) {
    val _sql: String = "update book_groups set show = 1 where groupId = ?"
    return performSuspending(__db, false, true) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, groupId)
        _stmt.step()
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
