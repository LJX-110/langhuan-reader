package io.legado.app.`data`.dao

import androidx.room3.EntityDeleteOrUpdateAdapter
import androidx.room3.EntityInsertAdapter
import androidx.room3.RoomDatabase
import androidx.room3.coroutines.createFlow
import androidx.room3.util.getColumnIndexOrThrow
import androidx.room3.util.performSuspending
import androidx.sqlite.SQLiteStatement
import io.legado.app.`data`.entities.ReplaceRule
import javax.`annotation`.processing.Generated
import kotlin.Boolean
import kotlin.Int
import kotlin.Long
import kotlin.String
import kotlin.Suppress
import kotlin.Unit
import kotlin.collections.List
import kotlin.collections.MutableList
import kotlin.collections.mutableListOf
import kotlin.reflect.KClass
import kotlinx.coroutines.flow.Flow

@Generated(value = ["androidx.room3.RoomProcessor"])
@Suppress(names = ["UNCHECKED_CAST", "DEPRECATION", "REDUNDANT_PROJECTION", "REMOVAL", "MemberExtensionConflict"])
internal class ReplaceRuleDao_Impl(
  __db: RoomDatabase,
) : ReplaceRuleDao {
  private val __db: RoomDatabase

  private val __insertAdapterOfReplaceRule: EntityInsertAdapter<ReplaceRule>

  private val __deleteAdapterOfReplaceRule: EntityDeleteOrUpdateAdapter<ReplaceRule>

  private val __updateAdapterOfReplaceRule: EntityDeleteOrUpdateAdapter<ReplaceRule>
  init {
    this.__db = __db
    this.__insertAdapterOfReplaceRule = object : EntityInsertAdapter<ReplaceRule>() {
      protected override fun createQuery(): String = "INSERT OR REPLACE INTO `replace_rules` (`id`,`name`,`group`,`pattern`,`replacement`,`scope`,`scopeTitle`,`scopeContent`,`excludeScope`,`isEnabled`,`isRegex`,`timeoutMillisecond`,`sortOrder`) VALUES (nullif(?, 0),?,?,?,?,?,?,?,?,?,?,?,?)"

      protected override fun bind(statement: SQLiteStatement, entity: ReplaceRule) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        val _tmpGroup: String? = entity.group
        if (_tmpGroup == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpGroup)
        }
        statement.bindText(4, entity.pattern)
        statement.bindText(5, entity.replacement)
        val _tmpScope: String? = entity.scope
        if (_tmpScope == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpScope)
        }
        val _tmp: Int = if (entity.scopeTitle) 1 else 0
        statement.bindLong(7, _tmp.toLong())
        val _tmp_1: Int = if (entity.scopeContent) 1 else 0
        statement.bindLong(8, _tmp_1.toLong())
        val _tmpExcludeScope: String? = entity.excludeScope
        if (_tmpExcludeScope == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpExcludeScope)
        }
        val _tmp_2: Int = if (entity.isEnabled) 1 else 0
        statement.bindLong(10, _tmp_2.toLong())
        val _tmp_3: Int = if (entity.isRegex) 1 else 0
        statement.bindLong(11, _tmp_3.toLong())
        statement.bindLong(12, entity.timeoutMillisecond)
        statement.bindLong(13, entity.order.toLong())
      }
    }
    this.__deleteAdapterOfReplaceRule = object : EntityDeleteOrUpdateAdapter<ReplaceRule>() {
      protected override fun createQuery(): String = "DELETE FROM `replace_rules` WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: ReplaceRule) {
        statement.bindLong(1, entity.id)
      }
    }
    this.__updateAdapterOfReplaceRule = object : EntityDeleteOrUpdateAdapter<ReplaceRule>() {
      protected override fun createQuery(): String = "UPDATE OR ABORT `replace_rules` SET `id` = ?,`name` = ?,`group` = ?,`pattern` = ?,`replacement` = ?,`scope` = ?,`scopeTitle` = ?,`scopeContent` = ?,`excludeScope` = ?,`isEnabled` = ?,`isRegex` = ?,`timeoutMillisecond` = ?,`sortOrder` = ? WHERE `id` = ?"

      protected override fun bind(statement: SQLiteStatement, entity: ReplaceRule) {
        statement.bindLong(1, entity.id)
        statement.bindText(2, entity.name)
        val _tmpGroup: String? = entity.group
        if (_tmpGroup == null) {
          statement.bindNull(3)
        } else {
          statement.bindText(3, _tmpGroup)
        }
        statement.bindText(4, entity.pattern)
        statement.bindText(5, entity.replacement)
        val _tmpScope: String? = entity.scope
        if (_tmpScope == null) {
          statement.bindNull(6)
        } else {
          statement.bindText(6, _tmpScope)
        }
        val _tmp: Int = if (entity.scopeTitle) 1 else 0
        statement.bindLong(7, _tmp.toLong())
        val _tmp_1: Int = if (entity.scopeContent) 1 else 0
        statement.bindLong(8, _tmp_1.toLong())
        val _tmpExcludeScope: String? = entity.excludeScope
        if (_tmpExcludeScope == null) {
          statement.bindNull(9)
        } else {
          statement.bindText(9, _tmpExcludeScope)
        }
        val _tmp_2: Int = if (entity.isEnabled) 1 else 0
        statement.bindLong(10, _tmp_2.toLong())
        val _tmp_3: Int = if (entity.isRegex) 1 else 0
        statement.bindLong(11, _tmp_3.toLong())
        statement.bindLong(12, entity.timeoutMillisecond)
        statement.bindLong(13, entity.order.toLong())
        statement.bindLong(14, entity.id)
      }
    }
  }

  public override suspend fun insert(vararg replaceRule: ReplaceRule): List<Long> = performSuspending(__db, false, true) { _connection ->
    val _result: List<Long> = __insertAdapterOfReplaceRule.insertAndReturnIdsList(_connection, replaceRule)
    _result
  }

  public override suspend fun delete(vararg replaceRules: ReplaceRule): Unit = performSuspending(__db, false, true) { _connection ->
    __deleteAdapterOfReplaceRule.handleMultiple(_connection, replaceRules)
  }

  public override suspend fun update(vararg replaceRules: ReplaceRule): Unit = performSuspending(__db, false, true) { _connection ->
    __updateAdapterOfReplaceRule.handleMultiple(_connection, replaceRules)
  }

  public override fun flowAll(): Flow<List<ReplaceRule>> {
    val _sql: String = "SELECT * FROM replace_rules ORDER BY sortOrder ASC"
    return createFlow(__db, false, arrayOf("replace_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowSearch(key: String): Flow<List<ReplaceRule>> {
    val _sql: String = "SELECT * FROM replace_rules where `group` like ? or name like ? ORDER BY sortOrder ASC"
    return createFlow(__db, false, arrayOf("replace_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        _argIndex = 2
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowGroupSearch(key: String): Flow<List<ReplaceRule>> {
    val _sql: String = "SELECT * FROM replace_rules where `group` like ? ORDER BY sortOrder ASC"
    return createFlow(__db, false, arrayOf("replace_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, key)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowGroupsUnProcessed(): Flow<List<String>> {
    val _sql: String = "select `group` from replace_rules where `group` is not null and `group` <> ''"
    return createFlow(__db, false, arrayOf("replace_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override fun flowNoGroup(): Flow<List<ReplaceRule>> {
    val _sql: String = "select * from replace_rules where `group` is null or trim(`group`) = '' or trim(`group`) like '%未分组%'"
    return createFlow(__db, false, arrayOf("replace_rules")) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun minOrder(): Int {
    val _sql: String = "SELECT MIN(sortOrder) FROM replace_rules"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun maxOrder(): Int {
    val _sql: String = "SELECT MAX(sortOrder) FROM replace_rules"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: Int
        if (_stmt.step()) {
          val _tmp: Int
          _tmp = _stmt.getLong(0).toInt()
          _result = _tmp
        } else {
          _result = 0
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun all(): List<ReplaceRule> {
    val _sql: String = "SELECT * FROM replace_rules ORDER BY sortOrder ASC"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun allGroupsUnProcessed(): List<String> {
    val _sql: String = "select distinct `group` from replace_rules where trim(`group`) <> ''"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _result: MutableList<String> = mutableListOf()
        while (_stmt.step()) {
          val _item: String
          _item = _stmt.getText(0)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findById(id: Long): ReplaceRule? {
    val _sql: String = "SELECT * FROM replace_rules WHERE id = ?"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindLong(_argIndex, id)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: ReplaceRule?
        if (_stmt.step()) {
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _result = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
        } else {
          _result = null
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findEnabledByContentScope(name: String, origin: String): List<ReplaceRule> {
    val _sql: String = """
        |SELECT * FROM replace_rules WHERE isEnabled = 1 and scopeContent = 1
        |        AND (scope LIKE '%' || ? || '%' or scope LIKE '%' || ? || '%' or scope is null or scope = '')
        |        and (excludeScope is null or (excludeScope not LIKE '%' || ? || '%' and excludeScope not LIKE '%' || ? || '%'))
        |        order by sortOrder
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, name)
        _argIndex = 2
        _stmt.bindText(_argIndex, origin)
        _argIndex = 3
        _stmt.bindText(_argIndex, name)
        _argIndex = 4
        _stmt.bindText(_argIndex, origin)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun findEnabledByTitleScope(name: String, origin: String): List<ReplaceRule> {
    val _sql: String = """
        |SELECT * FROM replace_rules WHERE isEnabled = 1 and scopeTitle = 1
        |        AND (scope LIKE '%' || ? || '%' or scope LIKE '%' || ? || '%' or scope is null or scope = '')
        |        and (excludeScope is null or (excludeScope not LIKE '%' || ? || '%' and excludeScope not LIKE '%' || ? || '%'))
        |        order by sortOrder
        """.trimMargin()
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, name)
        _argIndex = 2
        _stmt.bindText(_argIndex, origin)
        _argIndex = 3
        _stmt.bindText(_argIndex, name)
        _argIndex = 4
        _stmt.bindText(_argIndex, origin)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun getByGroup(group: String): List<ReplaceRule> {
    val _sql: String = "select * from replace_rules where `group` like '%' || ? || '%'"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        var _argIndex: Int = 1
        _stmt.bindText(_argIndex, group)
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public override suspend fun noGroup(): List<ReplaceRule> {
    val _sql: String = "select * from replace_rules where `group` is null or `group` = ''"
    return performSuspending(__db, true, false) { _connection ->
      val _stmt: SQLiteStatement = _connection.prepare(_sql)
      try {
        val _columnIndexOfId: Int = getColumnIndexOrThrow(_stmt, "id")
        val _columnIndexOfName: Int = getColumnIndexOrThrow(_stmt, "name")
        val _columnIndexOfGroup: Int = getColumnIndexOrThrow(_stmt, "group")
        val _columnIndexOfPattern: Int = getColumnIndexOrThrow(_stmt, "pattern")
        val _columnIndexOfReplacement: Int = getColumnIndexOrThrow(_stmt, "replacement")
        val _columnIndexOfScope: Int = getColumnIndexOrThrow(_stmt, "scope")
        val _columnIndexOfScopeTitle: Int = getColumnIndexOrThrow(_stmt, "scopeTitle")
        val _columnIndexOfScopeContent: Int = getColumnIndexOrThrow(_stmt, "scopeContent")
        val _columnIndexOfExcludeScope: Int = getColumnIndexOrThrow(_stmt, "excludeScope")
        val _columnIndexOfIsEnabled: Int = getColumnIndexOrThrow(_stmt, "isEnabled")
        val _columnIndexOfIsRegex: Int = getColumnIndexOrThrow(_stmt, "isRegex")
        val _columnIndexOfTimeoutMillisecond: Int = getColumnIndexOrThrow(_stmt, "timeoutMillisecond")
        val _columnIndexOfOrder: Int = getColumnIndexOrThrow(_stmt, "sortOrder")
        val _result: MutableList<ReplaceRule> = mutableListOf()
        while (_stmt.step()) {
          val _item: ReplaceRule
          val _tmpId: Long
          _tmpId = _stmt.getLong(_columnIndexOfId)
          val _tmpName: String
          _tmpName = _stmt.getText(_columnIndexOfName)
          val _tmpGroup: String?
          if (_stmt.isNull(_columnIndexOfGroup)) {
            _tmpGroup = null
          } else {
            _tmpGroup = _stmt.getText(_columnIndexOfGroup)
          }
          val _tmpPattern: String
          _tmpPattern = _stmt.getText(_columnIndexOfPattern)
          val _tmpReplacement: String
          _tmpReplacement = _stmt.getText(_columnIndexOfReplacement)
          val _tmpScope: String?
          if (_stmt.isNull(_columnIndexOfScope)) {
            _tmpScope = null
          } else {
            _tmpScope = _stmt.getText(_columnIndexOfScope)
          }
          val _tmpScopeTitle: Boolean
          val _tmp: Int
          _tmp = _stmt.getLong(_columnIndexOfScopeTitle).toInt()
          _tmpScopeTitle = _tmp != 0
          val _tmpScopeContent: Boolean
          val _tmp_1: Int
          _tmp_1 = _stmt.getLong(_columnIndexOfScopeContent).toInt()
          _tmpScopeContent = _tmp_1 != 0
          val _tmpExcludeScope: String?
          if (_stmt.isNull(_columnIndexOfExcludeScope)) {
            _tmpExcludeScope = null
          } else {
            _tmpExcludeScope = _stmt.getText(_columnIndexOfExcludeScope)
          }
          val _tmpIsEnabled: Boolean
          val _tmp_2: Int
          _tmp_2 = _stmt.getLong(_columnIndexOfIsEnabled).toInt()
          _tmpIsEnabled = _tmp_2 != 0
          val _tmpIsRegex: Boolean
          val _tmp_3: Int
          _tmp_3 = _stmt.getLong(_columnIndexOfIsRegex).toInt()
          _tmpIsRegex = _tmp_3 != 0
          val _tmpTimeoutMillisecond: Long
          _tmpTimeoutMillisecond = _stmt.getLong(_columnIndexOfTimeoutMillisecond)
          val _tmpOrder: Int
          _tmpOrder = _stmt.getLong(_columnIndexOfOrder).toInt()
          _item = ReplaceRule(_tmpId,_tmpName,_tmpGroup,_tmpPattern,_tmpReplacement,_tmpScope,_tmpScopeTitle,_tmpScopeContent,_tmpExcludeScope,_tmpIsEnabled,_tmpIsRegex,_tmpTimeoutMillisecond,_tmpOrder)
          _result.add(_item)
        }
        _result
      } finally {
        _stmt.close()
      }
    }
  }

  public companion object {
    public fun getRequiredColumnConverters(): List<KClass<*>> = emptyList()

    public fun getRequiredDaoReturnTypeConverters(): List<KClass<*>> = emptyList()
  }
}
