package io.legado.app.model.audio

/**
 * 音频播放控制器抽象 (KMP commonMain)。
 *
 * 对标 [io.legado.app.help.tts.HttpTtsPlayer]: 仅描述"控制底层播放器 + 查询状态"所需
 * 的最小能力, 不暴露平台特定类型 (Media3 `Player` / ExoPlayer / AVPlayer)。
 *
 * # 各平台实现
 * - app: `ExoPlayerAudioPlayController`, 包装 Media3 `ExoPlayer`
 *   (`app/src/main/java/io/legado/app/model/audio/`)
 * - desktop: `DesktopAudioPlayController`, 包装 mediamp-mpv 的 `DesktopAudioPlayer`
 *   (`desktop/src/main/kotlin/io/legado/desktop/audio/`)
 * - ios: `IosAvAudioPlayController`, 包装 AVPlayer (`data/src/iosMain/`)
 * - ohos: `OhosAvAudioPlayController`, 包装鸿蒙 AVPlayer (`data/src/ohosMain/`)
 *
 * # 设计原则
 * - 仅描述播放/暂停/seek/速率/状态查询, 不暴露 `setMediaItem` —— MediaItem 构造
 *   依赖 Media3 / AnalyzeUrl.getMediaItem (app 专属), 由 Service 直接调 ExoPlayer
 *   完成, 不经本接口
 * - 状态变化统一通过 [AudioPlayControllerListener], 避免平台 listener 类型泄漏
 *   (Media3 `Player.Listener` → 本接口)
 * - 状态常量值与 Media3 `Player.STATE_*` 对齐, 便于 app actual 直接透传
 *
 * 模式参考 [io.legado.app.help.tts.HttpTtsPlayer]。
 */
interface AudioPlayController {

    /** 是否正在播放。 */
    val isPlaying: Boolean

    /** 总时长 (毫秒), 未知时为 0 (与 Media3 `Player.getDuration` 一致)。 */
    val duration: Long

    /** 当前播放位置 (毫秒)。 */
    val currentPosition: Long

    /**
     * 已缓冲到的**绝对**时间点 (毫秒, 不是缓冲时长), 供进度条缓冲层绘制。
     *
     * 口径以 ExoPlayer `bufferedPosition` 为准: 桌面读 mpv `demuxer-cache-time`;
     * iOS 取 `loadedTimeRanges` 各段 end 的最大值; 鸿蒙用 AVPlayer CACHED_DURATION
     * 加当前位置。取不到时给 0 (缓冲层不绘制), 不要拿 duration 或已播位置顶替 ——
     * 那会画出一条永远铺满 / 恒等于播放进度的假缓冲条。
     */
    val bufferedPosition: Long

    /** 播放状态, 取值为 [STATE_IDLE] / [STATE_BUFFERING] / [STATE_READY] / [STATE_ENDED]。 */
    val playbackState: Int

    /** 播放/暂停就绪标志 (Media3 `playWhenReady` 语义)。 */
    var playWhenReady: Boolean

    /** 播放状态回调 (对标 Media3 `Player.Listener`)。 */
    var listener: AudioPlayControllerListener?

    /** 开始/恢复播放。 */
    fun play()

    /** 暂停播放。 */
    fun pause()

    /** 停止播放并清空状态 (但不释放资源)。 */
    fun stop()

    /** 跳转到指定位置 (毫秒)。 */
    fun seekTo(position: Long)

    /** 设置播放速率 (1.0 = 正常速度)。 */
    fun setPlaybackSpeed(speed: Float)

    /**
     * 准备播放 (装载媒体), 完成后触发 [AudioPlayControllerListener.onPlaybackStateChanged]。
     *
     * 挂起直到装载落定, 且随调用方协程取消 —— 装载的所有权归会话的起播 job, 会话终结
     * (或换章) 时在途装载随之作废, 不会留下"无人认领但仍在出声"的引擎。
     */
    suspend fun prepare()

    /** 释放底层资源。 */
    fun release()

    companion object {
        /** 对应 Media3 `Player.STATE_IDLE`。 */
        const val STATE_IDLE = 1

        /** 对应 Media3 `Player.STATE_BUFFERING`。 */
        const val STATE_BUFFERING = 2

        /** 对应 Media3 `Player.STATE_READY`。 */
        const val STATE_READY = 3

        /** 对应 Media3 `Player.STATE_ENDED`。 */
        const val STATE_ENDED = 4
    }
}

/**
 * 音频播放状态回调 (KMP 版, 对标 Media3 `Player.Listener`)。
 *
 * 各平台实现把平台 listener 适配为本接口回调。
 * app 端 [ExoPlayerAudioPlayController] 实现 `Player.Listener`,
 * 在 `onPlaybackStateChanged` / `onPlayerError` 中转发到本接口。
 */
interface AudioPlayControllerListener {

    /** 播放状态变化, [state] 取值见 [AudioPlayController] 的状态常量。 */
    fun onPlaybackStateChanged(state: Int) {}

    /** 播放或网络出错, [error] 为平台原始异常 (Media3 `PlaybackException` 等)。 */
    fun onPlayerError(error: Throwable) {}
}
