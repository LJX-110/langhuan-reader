package io.legado.app.model.webBook

import io.legado.app.constant.AppConst
import io.legado.app.constant.AppLog
import io.legado.app.data.AppDbProviders
import io.legado.app.data.entities.Book
import io.legado.app.data.entities.BookChapter
import io.legado.app.data.entities.BookListPage
import io.legado.app.data.entities.BookSource
import io.legado.app.data.entities.ReviewPage
import io.legado.app.data.entities.rule.ReviewRule
import io.legado.app.exception.NoStackTraceException
import io.legado.app.help.IntentDataProviders
import io.legado.app.help.http.StrResponse
import io.legado.app.help.source.SourceDebugLoggers
import io.legado.app.model.analyzeRule.AnalyzeRuleFactories
import io.legado.app.model.analyzeRule.AnalyzeUrlCore
import io.legado.app.model.analyzeRule.AnalyzeUrlFactories
import io.legado.app.model.analyzeRule.RuleData
import io.legado.app.model.analyzeRule.UrlOptionSerializer
import io.legado.app.utils.NetworkUtils
import io.legado.app.utils.RuleRegexes
import io.legado.app.utils.decodeOrNull
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/**
 * 列表翻页游标: 页码 + 上一页解析出的下一页地址。
 *
 * 发现页/单源搜索页与主页无限流共用同一份翻页裁决 (对照 app 端 ExploreShowViewModel.explore):
 * - 配了"下一页地址"规则的源直接请求上一页解析出的地址, 未配置/取不到时回落到页码模板;
 * - 从第 2 页起, 去重后列表不再增长即认定为到底 (源忽略页码时不会反复请求同一页)。
 */
class BookListPager {

    /** 下一次请求的页码 (1-based)。 */
    var page: Int = 1
        private set

    /** 上一页解析出的下一页地址 (null = 按页码模板翻页)。 */
    var nextPageUrl: String? = null
        private set

    /** 是否还有下一页 (重载第 1 页后、本次请求出结果前为 true)。 */
    var hasNextPage: Boolean = true
        private set

    /** 重载第 1 页: 页码、下一页地址、到底标记一并复位。 */
    fun reset() {
        page = 1
        nextPageUrl = null
        hasNextPage = true
    }

    /**
     * 提交一页结果并推进游标。
     *
     * @param result 本页解析结果 (下一页地址 + 是否还有下一页)
     * @param prevSize 本页合并去重前的条数
     * @param curSize 本页合并去重后的条数
     */
    fun advance(result: BookListPage, prevSize: Int, curSize: Int) {
        hasNextPage = result.hasNextPage && (page == 1 || curSize > prevSize)
        nextPageUrl = result.nextPageUrl
        page++
    }
}

/**
 * webBook 编排层入口。
 *
 * 从 app 下沉到 shared jvmAndAndroidMain, 现下沉到 commonMain。
 * - appDb (app 端单例) → AppDbProviders.get() provider 间接
 * - IntentData.source = ... → IntentDataProviders.get().setSource(...) provider 间接
 * - AnalyzeRule → AnalyzeRuleFactories.create (各端注册工厂返回平台子类补全 JsExtensions 面, 未注册端裸 AnalyzeRuleCore)
 * - AnalyzeUrl → AnalyzeUrlCore (app 端 AnalyzeUrl 继承 AnalyzeUrlCore, 调用方传 AnalyzeUrl 实例向上转型)
 * - Debug.log(key, msg, state) → SourceDebugLoggers.impl?.log(key, msg, state)
 * - parseBoolean/parseRulePrefix → 已抽到 WebBookRuleUtils (BookList/BookReview 已迁移)
 *
 * 包名保持 io.legado.app.model.webBook, app 端调用方 import 零改动。
 */
object WebBook {

    /** 书源 URL 匹配规则的单次匹配上限 (毫秒), 与替换规则默认超时同口径。 */
    private const val RULE_REGEX_TIMEOUT = 3000L

    /**
     * 搜索和发现
     */
    suspend fun getBookListAwait(
        bookSource: BookSource,
        key: String,
        page: Int? = 1,
        filter: ((name: String, author: String) -> Boolean)? = null,
        shouldBreak: ((size: Int) -> Boolean)? = null,
        isSearch: Boolean = true,
        onUrlResolved: ((AnalyzeUrlCore) -> Unit)? = null,
        selectedOptions: Map<String, String>? = null,
        pluginFilters: PluginFilterSession? = null,
        nextPageUrl: String? = null,
    ): BookListPage {
        // 插件虚拟源无规则可解析, 命中即转交委派 (搜索走 isSearch=true, 发现走 isSearch=false;
        // 发现路径的 key 即 exploreUrl 分类的 url 段, 交委派自行分派取数面;
        // pluginFilters 是页面会话筛选实例, 两条路径均透传)
        PluginSourceDelegates.resolve(bookSource)?.let { delegate ->
            return if (isSearch) delegate.getBookListAwait(bookSource, key, page ?: 1, pluginFilters)
            else delegate.getExploreAwait(bookSource, key, page ?: 1, pluginFilters)
        }
        var url = key
        if (isSearch) {
            if (bookSource.searchUrl.isNullOrBlank()) throw NoStackTraceException("搜索url不能为空")
            else url = bookSource.searchUrl!!
        }
        // 上一页解析出的下一页地址优先 (配置了下一页地址规则的源不再按页码拼地址)
        if (!nextPageUrl.isNullOrBlank()) url = nextPageUrl
        val ruleData = RuleData()
        val variables = buildMap<AppConst.JsVarName, Any> {
            if (isSearch) put(AppConst.JsVarName.KEY, key)
            if (page != null) put(AppConst.JsVarName.PAGE, page)
        }
        val analyzeUrl = AnalyzeUrlFactories.create(
            rawUrl = url,
            baseUrl = bookSource.bookSourceUrl,
            source = bookSource,
            ruleData = ruleData,
            coroutineContext = currentCoroutineContext(),
            selectedOptions = selectedOptions,
            variables = variables
        )
        onUrlResolved?.invoke(analyzeUrl)
        val res = checkLogin(analyzeUrl, bookSource)
        return BookList.analyzeBookList(
            bookSource = bookSource,
            ruleData = ruleData,
            analyzeUrl = analyzeUrl,
            baseUrl = res.url,
            body = res.body,
            isSearch = isSearch,
            isRedirect = checkRedirect(bookSource, res),
            filter = filter,
            shouldBreak = shouldBreak,
        )
    }

    /**
     * 书籍信息
     */
    suspend fun getBookInfoAwait(
        bookSource: BookSource,
        book: Book,
        canReName: Boolean = true,
    ): Book {
        PluginSourceDelegates.resolve(bookSource)?.let {
            return it.getBookInfoAwait(bookSource, book, canReName)
        }
        if (!book.infoHtml.isNullOrEmpty()) {
            BookInfo.analyzeBookInfo(
                bookSource = bookSource,
                book = book,
                baseUrl = book.bookUrl,
                redirectUrl = book.bookUrl,
                body = book.infoHtml,
                canReName = canReName
            )
        } else {
            val analyzeUrl = AnalyzeUrlFactories.create(
                rawUrl = book.bookUrl,
                baseUrl = bookSource.bookSourceUrl,
                source = bookSource,
                ruleData = book,
                coroutineContext = currentCoroutineContext()
            )
            val res = checkLogin(analyzeUrl, bookSource)
            checkRedirect(bookSource, res)
            BookInfo.analyzeBookInfo(
                bookSource = bookSource,
                book = book,
                baseUrl = book.bookUrl,
                redirectUrl = res.url,
                body = res.body,
                canReName = canReName
            )
        }
        return book
    }

    /**
     * 按书籍地址找认领它的书源 (零网络, 不抓取):
     * - 地址带 UrlOption 段时只按其中的 `origin` 取源 (没写 origin 就不认领, 分支结构与原版一致);
     * - 否则先取同 baseUrl 且允许添加书籍的源, 再按各源 `bookUrlPattern` 整段匹配
     *   (经 [RuleRegexes] 带时间上限: 模式串来自书源, 每次重新编译在 native 端会递归爆栈)。
     *
     * @return null = 地址格式不对, 或没有任何书源认领
     */
    suspend fun matchBookSourceByUrl(bookUrl: String): BookSource? =
        matchBookSourceByUrl(bookUrl, NetworkUtils.getBaseUrl(bookUrl))

    /** 已算好 baseUrl 的版本, 供调用方与自己的 baseUrl 解析合为一次。 */
    private suspend fun matchBookSourceByUrl(bookUrl: String, baseUrl: String?): BookSource? {
        baseUrl ?: return null
        val urlMatch = AnalyzeUrlCore.paramPattern.find(bookUrl)
        return if (urlMatch != null) {
            // 对齐原版 GSON.fromJsonObject<AnalyzeUrl.UrlOption>(...).getOrNull()
            // decodeOrNull 走宽松策略 (流式状态机容错单引号及非标语法)
            val opt = decodeOrNull(
                UrlOptionSerializer,
                bookUrl.substring(urlMatch.range.last + 1)
            )
            opt?.origin?.let {
                AppDbProviders.get().bookSourceDao.getBookSource(it)
            }
        } else AppDbProviders.get().bookSourceDao.getBookSourceAddBook(baseUrl)
            ?: AppDbProviders.get().bookSourceDao.hasBookUrlPattern().find { source ->
                val pattern = source.bookUrlPattern ?: return@find false
                RuleRegexes.get().matchesEntire(
                    bookUrl, pattern, multiline = false, timeout = RULE_REGEX_TIMEOUT
                )
            }
    }

    /**
     * 按书籍地址抓书详情 (未上架, 不写库)。
     *
     * @param matchedSource 调用方已经认领到的书源 ([matchBookSourceByUrl] 的结果); 传入时不再
     *   重算认领 (避免同一个地址连做两次 DB 查询 + `bookUrlPattern` 匹配)
     * @throws NoStackTraceException 地址已在书架、格式不对、无书源认领或拓取失败
     */
    suspend fun getBookInfoByUrlAwait(bookUrl: String, matchedSource: BookSource? = null): Book{
        if(AppDbProviders.get().bookDao.has(bookUrl)) throw NoStackTraceException("已在书架")
        val baseUrl = NetworkUtils.getBaseUrl(bookUrl)
            ?: throw NoStackTraceException("书籍地址格式不对")
        val source = matchedSource ?: matchBookSourceByUrl(bookUrl, baseUrl)
        // 原版把"没匹配到书源"和"抓取失败"一起裹进 catch-all, 两者都报"未找到匹配书源",
        // 且 source 为 null 时是 `source!!` 抛 NPE 被顺带吞掉。这里把两种失败分开:
        // 真没书源仍报原文案, 抓取失败上报真实原因, 否则用户看到的提示与实际问题无关。
        if (source == null) {
            AppLog.put("添加网址未匹配到书源 $bookUrl (baseUrl=$baseUrl)")
            throw NoStackTraceException("未找到匹配书源")
        }
        IntentDataProviders.get().setSource(source)
        val book = Book(
            bookUrl = bookUrl,
            type = source.getBookType(),
            origin = source.bookSourceUrl,
            originName = source.bookSourceName
        )
        try {
            return getBookInfoAwait(source, book)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // 取消可能被 JS/网络链路换壳, 类型判断拦不住, 补查协程状态后再记错
            currentCoroutineContext().ensureActive()
            AppLog.put("添加网址抓取失败 $bookUrl 书源=${source.bookSourceName}", e)
            throw e
        }
    }

    suspend fun getChapterListAwait(
        bookSource: BookSource,
        book: Book,
        runPerJs: Boolean = false
    ): Result<List<BookChapter>> {
        // 守卫在 runPreUpdateJs 之前: 虚拟插件源无 JS/规则, 目录直接由委派映射
        PluginSourceDelegates.resolve(bookSource)?.let {
            return it.getChapterListAwait(bookSource, book)
        }
        return runCatching {
            if (runPerJs) {
                runPreUpdateJs(bookSource, book).getOrThrow()
            }
            val tocRule = bookSource.tocRule
            val isSingleChapter = tocRule.chapterList.isNullOrBlank()
            if (isSingleChapter) {
                SourceDebugLoggers.impl?.log(bookSource.bookSourceUrl, "⇒目录规则为空,作为单章节书籍处理")
                val chapterList = arrayListOf(
                    BookChapter(
                        bookUrl = book.bookUrl,
                        title = "共一章",
                        url = book.tocUrl
                    )
                )
                return@runCatching BookChapterList.updateBook(book, chapterList)
            } else if (book.bookUrl == book.tocUrl && !book.tocHtml.isNullOrEmpty()) {
                BookChapterList.analyzeChapterList(
                    bookSource = bookSource,
                    book = book,
                    baseUrl = book.tocUrl,
                    body = book.tocHtml
                )
            } else {
                val analyzeUrl = AnalyzeUrlFactories.create(
                    rawUrl = book.tocUrl,
                    baseUrl = book.bookUrl,
                    source = bookSource,
                    ruleData = book,
                    coroutineContext = currentCoroutineContext()
                )
                val res = checkLogin(analyzeUrl, bookSource)
                checkRedirect(bookSource, res)
                BookChapterList.analyzeChapterList(
                    bookSource = bookSource,
                    book = book,
                    baseUrl = book.tocUrl,
                    redirectUrl = res.url,
                    body = res.body
                )
            }
        }.onFailure {
            currentCoroutineContext().ensureActive()
        }
    }

    /**
     * 章节内容
     */
    suspend fun getContentAwait(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter,
        nextChapterUrl: String? = null,
        needSave: Boolean = true
    ): String {
        PluginSourceDelegates.resolve(bookSource)?.let {
            return it.getContentAwait(bookSource, book, bookChapter)
        }
        if (bookSource.contentRule.content.isNullOrEmpty()) {
            SourceDebugLoggers.impl?.log(bookSource.bookSourceUrl, "⇒正文规则为空,使用章节链接:${bookChapter.url}")
            return bookChapter.url
        }
        if (bookChapter.isVolume && bookChapter.url.startsWith(bookChapter.title)) {
            SourceDebugLoggers.impl?.log(bookSource.bookSourceUrl, "⇒一级目录正文不解析规则")
            return bookChapter.tag ?: ""
        }
        val chapterUrl = bookChapter.getAbsoluteURL(book)
        return if (bookChapter.url == book.bookUrl && !book.tocHtml.isNullOrEmpty()) {
            BookContent.analyzeContent(
                bookSource = bookSource,
                book = book,
                bookChapter = bookChapter,
                baseUrl = chapterUrl,
                redirectUrl = chapterUrl,
                body = book.tocHtml,
                nextChapterUrl = nextChapterUrl,
                needSave = needSave
            )
        } else {
            val analyzeUrl = AnalyzeUrlFactories.create(
                rawUrl = chapterUrl,
                baseUrl = book.tocUrl,
                source = bookSource,
                ruleData = book,
                chapter = bookChapter,
                coroutineContext = currentCoroutineContext()
            )
            val res = checkLogin(analyzeUrl, bookSource)
            checkRedirect(bookSource, res)
            BookContent.analyzeContent(
                bookSource = bookSource,
                book = book,
                bookChapter = bookChapter,
                baseUrl = chapterUrl,
                redirectUrl = res.url,
                body = res.body,
                nextChapterUrl = nextChapterUrl,
                needSave = needSave
            )
        }
    }

    /**
     * 获取段评列表
     * paragraphIndex: 0=章节级评论，>=1=正文第 N 段
     * page: 段评分页号（书源用 {{page}} 引用）
     * sort: 排序方式，0=最热，1=最新（书源用 {{sort}} 引用）
     */
    suspend fun getReviewListAwait(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter?,
        paragraphIndex: Int,
        page: Int = 1,
        sort: Int = 0,
    ): Result<ReviewPage> = fetchReviewPage(
        bookSource, book, bookChapter,
        urlRuleSelector = { it.reviewUrl to "reviewUrl 为空" },
        variables = mapOf(
            AppConst.JsVarName.PARAGRAPH_INDEX to paragraphIndex,
            AppConst.JsVarName.SORT to sort,
            AppConst.JsVarName.PAGE to page,
        )
    )

    /**
     * 获取某条段评的回复列表
     * reviewRule.replyListUrl 与 reviewUrl 同样走 AnalyzeUrl，
     * 书源用 @js:/<js></js> 写动态 URL，可访问 paragraphIndex / reviewId 变量。
     * 复用 reviewList/avatarRule 等同一套解析规则。
     */
    suspend fun getReviewRepliesAwait(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter?,
        paragraphIndex: Int,
        reviewId: String,
        page: Int = 1,
    ): Result<ReviewPage> = fetchReviewPage(
        bookSource, book, bookChapter,
        urlRuleSelector = { it.replyListUrl to "书源未配置回复列表URL规则" },
        variables = mapOf(
            AppConst.JsVarName.PARAGRAPH_INDEX to paragraphIndex,
            AppConst.JsVarName.REVIEW_ID to reviewId,
            AppConst.JsVarName.PAGE to page,
        )
    )

    private suspend fun fetchReviewPage(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter?,
        urlRuleSelector: (ReviewRule) -> Pair<String?, String>,
        variables: Map<AppConst.JsVarName, Any>,
    ): Result<ReviewPage> = runCatching {
        if (bookSource.ruleReview.isNullOrEmpty()) {
            throw NoStackTraceException("书源未配置段评规则")
        }
        val reviewRule = bookSource.reviewRule
        val (rawUrl, missingMsg) = urlRuleSelector(reviewRule)
        if (rawUrl.isNullOrBlank()) throw NoStackTraceException(missingMsg)
        val baseUrl = bookChapter?.getAbsoluteURL(book) ?: book.bookUrl
        val analyzeUrl = AnalyzeUrlFactories.create(
            rawUrl = rawUrl,
            baseUrl = baseUrl,
            source = bookSource,
            ruleData = book,
            chapter = bookChapter,
            coroutineContext = currentCoroutineContext(),
            variables = variables
        )
        val res = checkLogin(analyzeUrl, bookSource)
        checkRedirect(bookSource, res)
        BookReview.analyzeReviewList(
            bookSource = bookSource,
            book = book,
            bookChapter = bookChapter,
            baseUrl = baseUrl,
            redirectUrl = res.url,
            body = res.body,
            reviewRule = reviewRule,
            variables = variables
        )
    }.onFailure {
        currentCoroutineContext().ensureActive()
    }

    /**
     * 获取章节内每段段评数 map
     */
    suspend fun getReviewCountAwait(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter,
    ): Result<Map<Int, Int>> = runCatching {
        if (bookSource.ruleReview.isNullOrEmpty()) {
            throw NoStackTraceException("书源未配置段评规则")
        }
        val reviewRule = bookSource.reviewRule
        val countRule = reviewRule.reviewCountRule
            ?: return@runCatching emptyMap<Int, Int>()
        val analyzeRule = AnalyzeRuleFactories.create(book, bookSource).apply {
            chapter = bookChapter
            setBaseUrl(bookChapter.getAbsoluteURL(book))
            coroutineContext = currentCoroutineContext()
        }
        analyzeRule.setContent("")
        val res = analyzeRule.evalJS(countRule)
        BookReview.analyzeReviewCount(bookSource, res)
    }.onFailure {
        currentCoroutineContext().ensureActive()
    }

    /**
     * 执行一个段评动作规则（点赞/点踩/回复/删除）
     * 规则是 JS：变量包含 paragraphIndex / reviewId（可空）/ selected（点赞点踩用，当前态）/ content（回复用）。
     * 返回规则执行结果（书源可返回字符串作为错误提示，正常成功时通常无返回值）。
     */
    suspend fun evalReviewActionAwait(
        bookSource: BookSource,
        book: Book,
        bookChapter: BookChapter?,
        rule: String,
        paragraphIndex: Int,
        reviewId: String? = null,
        contentText: String? = null,
        selected: Boolean? = null,
    ): Result<Any?> = runCatching {
        val variables =
            mutableMapOf<AppConst.JsVarName, Any>(AppConst.JsVarName.PARAGRAPH_INDEX to paragraphIndex)
        reviewId?.let { variables[AppConst.JsVarName.REVIEW_ID] = it }
        selected?.let { variables[AppConst.JsVarName.SELECTED] = it }
        val analyzeRule = AnalyzeRuleFactories.create(book, bookSource).apply {
            chapter = bookChapter
            setBaseUrl(bookChapter?.getAbsoluteURL(book) ?: book.bookUrl)
            coroutineContext = currentCoroutineContext()
            this.variables = variables
        }
        analyzeRule.evalJS(rule, contentText)
    }.onFailure {
        currentCoroutineContext().ensureActive()
    }

    /**
     * 精准搜索
     */
    suspend fun preciseSearchAwait(
        bookSource: BookSource,
        name: String,
        author: String,
    ): Result<Book> {
        return runCatching {
            currentCoroutineContext().ensureActive()
            getBookListAwait(
                bookSource, name,
                filter = { fName, fAuthor -> fName == name && fAuthor == author },
                shouldBreak = { it > 0 },
                pluginFilters = pluginFilterSessionOf(bookSource),
            ).books.firstOrNull()?.let { searchBook ->
                currentCoroutineContext().ensureActive()
                return@runCatching searchBook.toBook()
            }
            throw NoStackTraceException("未搜索到 $name($author) 书籍")
        }.onFailure {
            currentCoroutineContext().ensureActive()
        }
    }

    suspend fun runPreUpdateJs(bookSource: BookSource, book: Book): Result<Unit> {
        return runCatching {
            val preUpdateJs = bookSource.tocRule.preUpdateJs
            if (!preUpdateJs.isNullOrBlank()) {
                AnalyzeRuleFactories.create(book, bookSource, true).apply {
                    coroutineContext = currentCoroutineContext()
                }.evalJS(preUpdateJs)
            }
        }.onFailure {
            currentCoroutineContext().ensureActive()
            AppLog.put("执行preUpdateJs规则失败 书源:${bookSource.bookSourceName}", it)
        }
    }

    private suspend fun checkLogin(analyzeUrl: AnalyzeUrlCore, bookSource: BookSource) : StrResponse{
        var tmp: Throwable? = null
        var res = try {
                analyzeUrl.getStrResponseAwait()
            }catch (e: Throwable){
                tmp = e
                null
            }
        try{
            //检测书源是否已登录
            bookSource.loginCheckJs.let {
                if (!it.isNullOrBlank()) {
                    res = analyzeUrl.evalJS(it, res) as StrResponse
                }
            }

        }catch (e: Throwable){
            throw tmp ?: e
        }
        return res ?: throw tmp!!
    }

    /**
     * 检测重定向
     */
    private fun checkRedirect(bookSource: BookSource, response: StrResponse) : Boolean {
        response.raw.priorResponse?.let {
            if (it.isRedirect) {
                SourceDebugLoggers.impl?.log(bookSource.bookSourceUrl, "≡检测到重定向(${it.code})")
                SourceDebugLoggers.impl?.log(bookSource.bookSourceUrl, "┌重定向后地址")
                SourceDebugLoggers.impl?.log(bookSource.bookSourceUrl, "└${response.url}")
                return true
            }
        }
        return false
    }

}
