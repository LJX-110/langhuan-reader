package io.legado.app.utils

import io.legado.app.constant.AppLog
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.KSerializer
import kotlinx.serialization.SerializationException
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.serializer

/**
 * Gson 兼容层: 保留 app 模块原有 GSON API 表面, 内部转发到 kotlinx-serialization。
 *
 * - [GSON]/[GSONStrict]: 别名, 复用 shared 模块的 [KS_JSON]/[KS_JSON_STRICT] 实例
 * - [toJson]/[fromJsonObject]/[fromJsonArray]: 扩展函数, 复刻原 GsonExtensions.shared.kt 的语义
 *
 * 注意: 这是过渡兼容层, 新代码应直接使用 KS_JSON.encodeToString / decodeOrNull / decodeListWithFallbackOrNull。
 *
 * 本文件仅含纯 Kotlin / KMP 标准库依赖, 可下沉 commonMain;
 * 涉及 java.io.OutputStream/Reader/Writer 的流式重载在 jvmAndAndroidMain
 * (见 GsonStreamExtensions.kt)。
 */

// GSON 别名, 让 `import io.legado.app.utils.GSON` + `GSON.xxx` 继续工作
val GSON: Json get() = KS_JSON
val GSONStrict: Json get() = KS_JSON_STRICT

/**
 * 复刻 Gson.toJson(obj): String, 处理任意类型 (包括 Any/Any?/List<*>/Map<*,*>/@Serializable 类)。
 *
 * 非 inline: 使用 [Any?.toJsonElement] 运行时查找 serializer, 避免 reified T 推断失败
 * (如 `MutableMap<String, Any>` 场景)。
 */
fun Json.toJson(obj: Any?): String = obj.toJsonElement().toString()

/**
 * 导出文件用的 JSON 格式: 原版 Gson `setPrettyPrinting()` 的形制 (2 空格缩进 + `": "` 分隔)。
 */
@OptIn(ExperimentalSerializationApi::class)
private val exportJsonFormat = Json {
    prettyPrint = true
    prettyPrintIndent = "  "
}

/** [JsonElement] 按导出形制序列化。 */
fun exportJsonText(element: JsonElement): String =
    exportJsonFormat.encodeToString(JsonElement.serializer(), element)

/**
 * 导出文件用的 JSON 文本 (任意对象, 经 [toJsonElement] 转换后按导出形制输出)。
 *
 * 只对齐缩进形制; 字段取舍仍走既有 kotlinx 兼容层 (等于默认值的字段省略、null 字段显式写出),
 * 与原版 Gson 的这两项差异属仓库既有的序列化迁移差异, 不在本入口处理。
 */
fun Any?.toExportJsonText(): String = exportJsonText(toJsonElement())

/** 复刻原 GsonExtensions.shared.kt 的 fromJsonObject<T>(json): Result<T>, 接受 String? */
inline fun <reified T> Json.fromJsonObject(json: String?): Result<T> = runCatching {
    if (json.isNullOrEmpty()) throw SerializationException("json is null or empty")
    decodeFromString<T>(json)
}

/** 复刻原 GsonExtensions.shared.kt 的 fromJsonArray<T>(json): Result<List<T>>, 接受 String? */
inline fun <reified T> Json.fromJsonArray(json: String?): Result<List<T>> = runCatching {
    if (json.isNullOrEmpty()) throw SerializationException("json is null or empty")
    decodeFromString<List<T>>(json)
}

/**
 * 任意对象转 [JsonElement], 供 [ReturnData.toJsonString] 等 Gson 反射序列化场景使用。
 *
 * 复刻 Gson.toJson(obj) 对常见类型的处理:
 * - null/JsonElement/String/Boolean/Number: 对应 JsonPrimitive
 * - ByteArray: Base64 编码字符串 (对齐 Gson 默认行为)
 * - List/Map: 递归处理元素
 * - @Serializable 类: 用运行时 [KClass.serializer] 查找编译器生成的 serializer
 * - 其他: 降级为 toString() 并记 [AppLog] (降级产物是不可反序列化的垃圾 JSON, 必须可见)
 *
 * Base64 编码: 原 android.util.Base64.encodeToString(this, NO_WRAP) 为标准字母表+padding+不换行,
 * 复用 shared 模块 [EncoderUtils.base64Encode] (默认 NO_WRAP flags, 内部走 kotlin.io.encoding.Base64.Default)。
 */
@OptIn(ExperimentalSerializationApi::class, kotlinx.serialization.InternalSerializationApi::class)
@Suppress("UNCHECKED_CAST")
fun Any?.toJsonElement(): JsonElement = when (this) {
    null -> JsonNull
    is JsonElement -> this
    is String -> JsonPrimitive(this)
    is Boolean -> JsonPrimitive(this)
    is Number -> JsonPrimitive(this)
    is ByteArray -> JsonPrimitive(EncoderUtils.base64Encode(this))
    is List<*> -> JsonArray(this.map { it.toJsonElement() })
    is Map<*, *> -> JsonObject(this.entries.associate { it.key.toString() to it.value.toJsonElement() })
    else -> try {
        val serializer = this::class.serializer() as KSerializer<Any>
        KS_JSON.encodeToJsonElement(serializer, this)
    } catch (e: SerializationException) {
        // 非 @Serializable 类型: 降级为 toString() 字符串写进 JSON。该降级会产出
        // ["Entity(toString)..."] 这类不可反序列化的垃圾 (如 ReadRecord 曾导致的
        // 备份恢复 JsonDecodingException), 必须显式记日志, 不能再静默吞掉。
        AppLog.put(
            "Gson 兼容层: 非 @Serializable 类型 ${this::class.simpleName} " +
                "降级为 toString() 序列化, 生成的 JSON 可能无法反序列化", e
        )
        JsonPrimitive(this.toString())
    }
}
