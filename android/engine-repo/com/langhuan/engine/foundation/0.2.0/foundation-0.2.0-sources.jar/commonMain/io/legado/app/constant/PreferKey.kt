package io.legado.app.constant

@Suppress("ConstPropertyName")
object PreferKey {
    const val language = "language"
    const val fontScale = "fontScale"
    const val themeMode = "themeMode"
    const val userAgent = "userAgent"
    const val showUnread = "showUnread"
    const val bookGroupStyle = "bookGroupStyle"
    const val useDefaultCover = "useDefaultCover"
    const val coverShowName = "coverShowName"
    const val coverShowAuthor = "coverShowAuthor"
    const val coverShowNameN = "coverShowNameN"
    const val coverShowAuthorN = "coverShowAuthorN"
    const val remoteServerId = "remoteServerId"
    const val hideStatusBar = "hideStatusBar"
    const val clickActionTL = "clickActionTopLeft"
    const val clickActionTC = "clickActionTopCenter"
    const val clickActionTR = "clickActionTopRight"
    const val clickActionML = "clickActionMiddleLeft"
    const val clickActionMC = "clickActionMiddleCenter"
    const val clickActionMR = "clickActionMiddleRight"
    const val clickActionBL = "clickActionBottomLeft"
    const val clickActionBC = "clickActionBottomCenter"
    const val clickActionBR = "clickActionBottomRight"
    const val hideNavigationBar = "hideNavigationBar"
    const val precisionSearch = "precisionSearch"
    // 搜索范围 / 搜索分组: AppConfig 中直接用字符串字面量, 这里补常量供 Desktop 端使用
    const val searchScope = "searchScope"
    const val searchGroup = "searchGroup"
    const val readAloudByPage = "readAloudByPage"
    const val ttsEngine = "appTtsEngine"
    const val ttsFollowSys = "ttsFollowSys"
    const val ttsSpeechRate = "ttsSpeechRate"
    const val prevKeys = "prevKeyCodes"
    const val nextKeys = "nextKeyCodes"
    const val showDiscovery = "showDiscovery"
    const val showHome = "showHome"
    const val bottomNavItemOrder = "bottomNavItemOrder"
    const val bookshelfLayout = "bookshelfLayout"
    const val bookshelfFixedWidthMode = "bookshelfFixedWidthMode"
    const val bookshelfGridWidth = "bookshelfGridWidth"
    const val bookshelfSort = "bookshelfSort"
    const val bookExportFileName = "bookExportFileName"

    const val bookImportFileName = "bookImportFileName"
    const val episodeExportFileName = "episodeExportFileName"
    const val recordLog = "recordLog"
    const val processText = "process_text"
    const val cleanCache = "cleanCache"
    const val saveTabPosition = "saveTabPosition"
    const val fontFolder = "fontFolder"
    const val restoreIgnore = "restoreIgnore"
    const val threadCount = "threadCount"
    const val webPort = "webPort"
    const val keepLight = "keep_light"
    const val webService = "webService"
    const val webDavUrl = "web_dav_url"
    const val webDavAccount = "web_dav_account"
    const val webDavPassword = "web_dav_password"
    const val webDavDir = "webDavDir"
    const val enableCustomExport = "enableCustomExport"
    const val exportToWebDav = "webDavCacheBackup"
    const val exportNoChapterName = "exportNoChapterName"
    const val exportType = "exportType"
    const val changeSourceCheckAuthor = "changeSourceCheckAuthor"
    const val changeSourceLoadToc = "changeSourceLoadToc"
    const val changeSourceLoadInfo = "changeSourceLoadInfo"
    const val changeSourceLoadWordCount = "changeSourceLoadWordCount"
    const val chineseConverterType = "chineseConverterType"
    const val launcherIcon = "launcherIcon"
    const val shareLayout = "shareLayout"
    const val comicStyleSelect = "comicStyleSelect"
    const val readStyleSelect = "readStyleSelect"
    const val systemTypefaces = "system_typefaces"
    const val textFullJustify = "textFullJustify"
    const val textBottomJustify = "textBottomJustify"

    /** 段首标点悬挂（CSS Text 4 §8.5.3 第三方案 hanging alignment / clreq 6.3.2 段首缩进条）。 */
    const val hangFirstPunctuation = "hangFirstPunctuation"
    const val autoReadSpeed = "autoReadSpeed"
    const val barElevation = "barElevation"
    const val defaultCover = "defaultCover"
    const val defaultCoverDark = "defaultCoverDark"
    const val replaceEnableDefault = "replaceEnableDefault"
    const val autoChangeSource = "autoChangeSource"
    const val importKeepName = "importKeepName"
    const val importKeepGroup = "importKeepGroup"
    const val screenOrientation = "screenOrientation"
    const val syncBookProgress = "syncBookProgress"
    const val syncBookProgressPlus = "syncBookProgressPlus"
    const val cronet = "Cronet"
    const val bitmapCacheSize = "bitmapCacheSize"
    const val preDownloadNum = "preDownloadNum"
    const val mangaPreDownloadNum = "mangaPreDownloadNum"
    const val mangaAutoPageSpeed = "mangaAutoPageSpeed"
    const val mangaFooterConfig = "mangaFooterConfig"
    const val enableMangaHorizontalScroll = "enableMangaHorizontalScroll"
    const val hideMangaTitle = "hideMangaTitle"
    const val mangaColorFilter = "mangaColorFilter"
    const val enableMangaGray = "enableMangaGray"
    const val enableMangaGifAutoNext = "enableMangaGifAutoNext"
    const val autoRefresh = "auto_refresh"
    const val autoCheckUpdate = "autoCheckUpdate"
    const val exportCharset = "exportCharset"
    const val exportUseReplace = "exportUseReplace"
    //const val expandTextMenu = "expandTextMenu"
    const val doublePageHorizontal = "doubleHorizontalPage"
    const val readUrlOpenInBrowser = "readUrlInBrowser"
    const val defaultBookTreeUri = "defaultBookTreeUri"
    const val uploadRule = "uploadRule"
    const val tocUiUseReplace = "tocUiUseReplace"
    const val tocCountWords = "tocCountWords"
    const val enableReadRecord = "enableReadRecord"
    const val localBookImportSort = "localBookImportSort"
    const val enableWelcome = "enableWelcome"
    const val welcomeImage = "welcomeImagePath"
    const val welcomeImageDark = "welcomeImagePathDark"
    const val welcomeShowText = "welcomeShowText"
    const val welcomeShowTextDark = "welcomeShowTextDark"
    const val welcomeShowIcon = "welcomeShowIcon"
    const val welcomeShowIconDark = "welcomeShowIconDark"
    const val welcomeShowTime = "welcomeShowTime"
    const val pageTouchSlop = "pageTouchSlop"
    const val showAddToShelfAlert = "showAddToShelfAlert"
    const val bookInfoDeleteAlert = "bookInfoDeleteAlert"
    const val ignoreAudioFocus = "ignoreAudioFocus"

    /**
     * 动态文本辉光。开启后安卓端会关掉 DSP audio offload 以拿到 PCM (后台听书不再省电),
     * 与 [audioEdgeGlow] 任一个开启都需要 PCM。
     */
    const val audioEnergyGlow = "audioEnergyGlow"

    /**
     * 播放页边缘光效。安卓端与 [audioEnergyGlow] 同等: 需要 PCM 才能按频段起伏,
     * 两个开关都关才开省电解码。
     */
    const val audioEdgeGlow = "audioEdgeGlow"

    /** 上面两个辉光开关的默认值 (读取处统一引用它, 不各写一遍字面量) */
    const val audioGlowDefault = true
    const val progressBarBehavior = "progressBarBehavior"
    const val sourceEditMaxLine = "sourceEditMaxLine"
    const val ttsTimer = "ttsTimer"
    const val webDavDeviceName = "webDavDeviceName"
    const val webServiceWakeLock = "webServiceWakeLock"
    const val audioPlayWakeLock = "audioPlayWakeLock"
    const val publishLyric = "publishLyric"
    const val readAloudWakeLock = "readAloudWakeLock"
    const val showLastUpdateTime = "showLastUpdateTime"
    const val showWaitUpCount = "showWaitUpCount"

    /**
     * 书源管理列表是否显示行首书源图标 (默认显示)。
     *
     * 与其它显示类开关 (showLastUpdateTime / enableReadRecord / hideMangaTitle 等) 同一份
     * 默认偏好存储: 随配置备份走, 换机恢复后档位保持; 备份忽略清单 (主题/封面等按需忽略项)
     * 不含本键。
     */
    const val showSourceIcon = "showSourceIcon"
    const val clearWebViewData = "clearWebViewData"
    const val onlyLatestBackup = "onlyLatestBackup"
    const val shrinkDatabase = "shrinkDatabase"
    const val batchChangeSourceDelay = "batchChangeSourceDelay"
    const val defaultHomePage = "defaultHomePage"
    const val bookshelfListShowKind = "bookshelfListShowKind"
    const val bookshelfListShowIntro = "bookshelfListShowIntro"
    const val bookshelfListIntroLines = "bookshelfListIntroLines"
    const val bookshelfCoverHeight = "bookshelfCoverHeight"
    const val searchLayout = "searchLayout"
    const val bottomBarHeight = "bottomBarHeight"
    const val bottomBarIconSize = "bottomBarIconSize"
    const val bottomBarLabelMode = "bottomBarLabelMode"
    const val bookshelfShowGroupCount = "bookshelfShowGroupCount"
    const val importKeepEnable = "importKeepEnable"
    const val previewImageByClick = "previewImageByClick"
    const val recordHeapDump = "recordHeapDump"
    const val updateToVariant = "updateToVariant"
    const val streamReadAloudAudio = "streamReadAloudAudio"
    const val pauseReadAloudWhilePhoneCalls = "pauseReadAloudWhilePhoneCalls"
    const val readAloudByMediaButton = "readAloudByMediaButton"
    const val devFeat = "devFeat"
    const val bookInfoHorizontalLayout = "bookInfoHorizontalLayout"
    const val disableMangaPageAnim = "disableMangaPageAnim"
    const val autoCheckNewBackup = "autoCheckNewBackup"

    const val cPrimary = "colorPrimary"
    const val cAccent = "colorAccent"
    const val cBackground = "colorBackground"
    const val cBBackground = "colorBottomBackground"
    const val bgImage = "backgroundImage"
    const val bgImageBlurring = "backgroundImageBlurring"

    const val cNPrimary = "colorPrimaryNight"
    const val cNAccent = "colorAccentNight"
    const val cNBackground = "colorBackgroundNight"
    const val cNBBackground = "colorBottomBackgroundNight"
    const val bgImageN = "backgroundImageNight"
    const val bgImageNBlurring = "backgroundImageNightBlurring"

    // 莫奈取色自动跟随壁纸开关 (Android 12+): 行为模式开关, 非主题色/背景图载荷, 不入 themePrefKeys
    const val monetWallpaperFollow = "monetWallpaperFollow"
    const val showReadTitleAddition = "showReadTitleAddition"
    const val contentSelectSpeakMod = "contentReadAloudMod"

    // 桌面端窗口状态记忆 (位置/尺寸/是否最大化)
    const val windowX = "desktopWindowX"
    const val windowY = "desktopWindowY"
    const val windowWidth = "desktopWindowWidth"
    const val windowHeight = "desktopWindowHeight"
    const val windowMaximized = "desktopWindowMaximized"

    /**
     * 关闭主窗口时是否缩小到托盘 (false = 退出程序)。
     *
     * 键不存在 = 用户尚未选择过, 首次关闭时弹询问框; 设置页开关与询问框读写同一个键,
     * 任一处选定过就不再询问。
     */
    const val closeToTray = "desktopCloseToTray"

    /**
     * 预测式返回跟手 (仅 Android 消费): 打开时返回手势跟手、且返回统一由根层 + 统一返回链接管,
     * 关闭时回到各页面自己注册的按键式返回回调 (与本改动前一致)。
     */
    const val predictiveBack = "predictiveBack"
}
